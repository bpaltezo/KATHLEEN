<!-- Start Left menu area -->
    <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <br>
            <div class="sidebar-header">
                <a href="./"><img class="main-logo" src="../images/logo.png" alt="" width="75" height="75" /></a>
                <strong><a href="./"><img src="../images/logo.png" alt="" width="40" height="40" /></a></strong>
            </div>
            <br><br><hr>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li>
                            <a title="Go to Home" href="./" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-chalkboard fa-1x iblue"></i> &nbsp;Panel
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Manage Accounts" href="accounts.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-id-badge fa-1x iblue"></i> &nbsp;&nbsp;Accounts
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Manage Lessons" href="lessons.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-print iblue"></i> &nbsp;&nbsp;Printables
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Manage Quizes" href="quiz.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-file-medical-alt iblue"></i> &nbsp; Quizes
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Manage Tutorials" href="tutorials.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-play-circle iblue"></i> &nbsp;Tutorials
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Manage Tutorials" href="sections.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-users iblue"></i> &nbsp;Sections
                                </span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </nav>
    </div>
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="#"><img class="main-logo" src="../img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="background:#3E24B9;">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
                                                    <i class="educate-icon educate-nav"></i>
                                                </button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        
                                    </div>
                                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                                
                                                <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle bell"><i class="educate-icon educate-bell" aria-hidden="true"></i>
                                                    <?php
                                                        if(isset($_SESSION['badge']) && $_SESSION['badge'] == ""){
                                                            echo $updatecount;    
                                                        }else{
                                                            echo '<span class="indicator-ms"></span>';
                                                        }
                                                    ?>
                                                    <div role="menu" class="notification-author dropdown-menu animated zoomIn">
                                                        <div class="notification-single-top">
                                                            <h1>Notifications</h1>
                                                        </div>
                                                        <ul class="notification-menu">
                                                            <?php
                                                                echo $logupdates;
                                                            ?>
                                                        </ul>
                                                        <div class="notification-single-top">
                                                            <h1></h1>
                                                        </div>
                                                        <ul class="notification-menu">
                                                            <?php
                                                                echo $quizupdates;
                                                            ?>
                                                        </ul>
                                                        <div class="notification-view">
                                                            <a href="#">View All Notification</a>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="nav-item">
                                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                                            <img src="../images/logo.png" alt="" />
                                                            <span class="admin-name">Administrator</span>
                                                            <i class="fa fa-angle-down edu-icon edu-down-arrow"></i>
                                                        </a>
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                        <li><a href="./"><span class="fas fa-hospital author-log-ic"></span>My Panel</a>
                                                        </li>
                                                        <li><a href="settings.php"><span class="fas fa-cog author-log-ic"></span>Admin Settings</a>
                                                        </li>
                                                        <li><a href="../logout.php"><span class="fas fa-power-off author-log-ic"></span>Log Out</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           