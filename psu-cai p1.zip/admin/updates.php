<?php

	function GetUpdates($user){

    	$conn = mysqli_connect("localhost", "root", "", "cai_it4");

  $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
  $display = mysql_fetch_array($query);

  /////////////////////////////////////////////////////////////////////////FACULTY
  $updateCount = 0;
  $updater = "";

  //LOGS
  $sql = "SELECT * FROM logs  ORDER BY id DESC LIMIT 20";
  $res = $conn->query($sql);

  $logupdates = "";

  while($row = $res->fetch_assoc()){

    $loggerid = $row['memberid'];

    if($loggerid != $display['member_id'] && $row["timein"] != ""){

        $sqlx = "SELECT * FROM members WHERE member_id='$loggerid' ";
        $resx = $conn->query($sqlx);

        $Lname = "";
        $Limg = "";

        while($rowx = $resx->fetch_assoc()){$Lname=$rowx['firstname']." ".$rowx['lastname']; $Limg=$rowx['image'];}

        $logupdates .= '<li>
                  <a href="#">
                    <div class="notification-icon">
                      <i class="fas fa-user-clock aria-hidden="true"></i>
                    </div>
                    <div class="notification-content">
                      <span class="notification-date">'.$row['datein'].'</span>
                      <h2>'.$Lname.'</h2>
                      <p> Has logged in to the system. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <i> '.time_elapsed_string($row['timein']).'</i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    </div>
                  </a>
               </li>';

        $updateCount++;

    }else if($loggerid != $display['member_id'] && $row["timein"] == ""){

      $sqlx = "SELECT * FROM members WHERE member_id='$loggerid' ";
        $resx = $conn->query($sqlx);

        $Lname = "";
        $Limg = "";

        while($rowx = $resx->fetch_assoc()){$Lname=$rowx['firstname']." ".$rowx['lastname']; $Limg=$rowx['image'];}

        $logupdates .= '<li>
                  <a href="#">
                    <div class="notification-icon">
                      <i class="fas fa-user-clock aria-hidden="true"></i>
                    </div>
                    <div class="notification-content">
                      <span class="notification-date">'.$row['dateout'].'</span>
                      <h2>'.$Lname.'</h2>
                      <p>Has logged out from the system. <i>&nbsp;&nbsp;&nbsp;&nbsp; '.time_elapsed_string($row['logout']).'</i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    </div>
                  </a>
               </li>';

        $updateCount++;

    }

  }

  $sql3 = "SELECT * FROM updates ";
  $res3 = $conn->query($sql3);

  $quizupdates = "";

  while($row2 = $res3->fetch_assoc()){
            
    $sqlx2 = "SELECT * FROM members WHERE member_id=".$row2['member_id'];
    $resx2 = $conn->query($sqlx2);

    $Lname2 = "";

    while($rowx2 = $resx2->fetch_assoc()){
      $Lname2=$rowx2['firstname']." ".$rowx2['lastname']; $Limg2=$rowx2['image'];
    }

    $icon = "";

    if($row2['status'] == "Has taken a quiz"){
        $icon = '<i class="fas fa-edit aria-hidden="true"></i>';
    }else if($row2['status'] == "Added a new lesson"){
        $icon = '<i class="fas fa-laptop-code aria-hidden="true"></i>';
    }else if($row2['status'] == "Added a new quiz"){
        $icon = '<i class="fas fa-newspaper aria-hidden="true"></i>';
    }

    $date = explode(" ", $row2['dt']);
    $md = $date[1]." ".$date[2];

    $quizupdates .= '<li>
                  <a href="#">
                    <div class="notification-icon">'.$icon.'</div>
                    <div class="notification-content">
                      <span class="notification-date">'.$md.'</span>
                      <h2>'.$Lname2.'</h2>
                      <p>'.$row2['status'].'<span style="color:#fff;">...............................</span> <i>'.time_elapsed_string($row2['dt']).'</i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    </div>
                  </a>
               </li>';

    $updateCount++;

  }

  $updater = '<span class="badge badge-notif">'.$updateCount.'</span>';

  if($updateCount == 0) $updates = "<p class='text-center'>No new notifications</p>";

  $result = Array();

  $result[] = $logupdates;
  $result[] = $quizupdates;
  $result[] = $updater;

  return $result;

    }

?>