<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>

<?php

  include("../session/DBConnection.php");
    require_once("../includes/session.php"); 
    require_once("../includes/connection.php");
  include "functions.php";

    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $current_lesson = $display['current_lesson'];
    $current_quiz = $display['current_quiz'];
    $fullname = $name." ".$lastname;

    if($pix == ""){$pix = SetProfileByGender($display['gender']);}

?>

  <title>Admin - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

  <?php include "links.php"; ?>
  
</head>
<body style="">

<?php
    include "updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include ('header.php'); ?>

<br>
<div class="breadcome-area">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="breadcome-list">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <a href="#" class="addtutorial" data-toggle="modal" data-target="#MX">
                <button class="btn btn-primary">
                  <i class="fas fa-plus-circle"></i>
                  New Tutorial
                </button>
              </a>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <ul class="breadcome-menu">
                <li><span class="bread-blod">Computer Aided Instruction</span> / Admin</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container-fluid">
  <div class="panel-body">
    <div class="row">
      <h3>&nbsp;&nbsp;All Tutorials</h3>
      <div class="col-lg-12">

        <?php 
          
          if(isset($_GET['upload']) && $_GET['upload'] == "success"){
            
            CreateAlert("Success!", "Added Successfully", "style1", "fa-check");
          
          }else if(isset($_GET['file']) && $_GET['upload'] == "303"){
            
            CreateAlert("Oops!", "The file already exist.", "style3", "fa-exclamation-triangle");

          }else if(isset($_GET['upload']) && $_GET['upload'] == "404"){
            
            CreateAlert("Oops!", "The file you selected is invalid.", "style4", "fa-exclamation-triangle");

          }else if(isset($_GET['file']) && $_GET['upload'] == "505"){
            
            CreateAlert("Oops!", "Saving to database failed!", "style2", "fa-exclamation-triangle");

          }

        ?>
      </div>
    </div>
    <br>
    <div class="row">
      <div class="col-lg-12">
         <br>
        <?php 

          if(isset($_GET['remove'])){
            if(RemoveTutorial($_GET['id'])){
              CreateAlert("Success!", "Removed Successfully", "style1", "fa-check");
            }else{
              CreateAlert("Oops!", "Unable to remove the file. Please try again.", "style4", "fa-exclamation-triangle");
            }
          }

          $tutorials = LoadTutorials();
          if($tutorials == ""){
            echo "There are no tutorials created.";
          }else{
            echo $tutorials;
          }

        ?>
         
      </div>
    </div>
  </div>
</div>

<div id="MX" class="modal modal-edu-general default-popup-PrimaryModal fade" role="dialog" style="display: none;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-close-area modal-close-df">
        <a class="close" data-dismiss="modal" href="#"><i class="fas fa-times"></i></a>
      </div>

      <form action="upload.php" method="post" enctype="multipart/form-data">
      <div class="modal-body text-left">
        
        <label style="float: left;">Enter Title</label>
        <input type="text" name="title" class="form-control" placeholder="Title" autocomplete="off" required>
        <br>
        <label style="float: left;">Select the file</label>
        <div class="form-group-inner">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="file-upload-inner ts-forms">
                <div class="input prepend-big-btn">
                  <label class="icon-right" for="prepend-big-btn">
                    <i class="fa fa-download"></i>
                  </label>
                  <div class="file-button">
                    Browse
                    <input type="file" name="file" onchange="document.getElementById('ph').value = this.value;" required accept="video/*">
                  </div>
                  <input type="text" id="ph" placeholder="no file selected" autocomplete="off">
                </div>
              </div>
            </div>
          </div>
        </div>
        <br>
        <input type="hidden" name="subject" value="tutorial">
      </div>
      <div class="modal-footer">
        <button data-dismiss="modal" class="btn btn-default">Cancel</button>
        <button type="submit" class="btn btn-primary">Proceed</button>
      </div>
    </form>

    </div>
  </div>
</div>

<?php include "footer.php"; ?>

<script type="text/javascript">
  
  window.onload = function(){

    $(".addtutorial").on("click", function(){
      $("#uploadvideofile").click();
    });

    $("#file").on("change", function(){
      //$("#uploadForm").submit();
      console.log(this.value);
    });

  }

</script>