<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>

<?php

	include("../session/DBConnection.php");
    require_once("../includes/session.php"); 
    require_once("../includes/connection.php");
	include "functions.php";

    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $current_lesson = $display['current_lesson'];
    $current_quiz = $display['current_quiz'];
    $fullname = $name." ".$lastname;

    if($pix == ""){$pix = SetProfileByGender($display['gender']);}

?>


<?php

    if(isset($_POST['confirm'])){
        ConfirmAccount($_POST['id']);
    }

    if(isset($_POST['remove'])){
        DeleteAccount($_POST['id']);
    }

?>

	<title>Admin - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

	<?php include "links.php"; ?>
	
</head>
<body style="">

<?php
    include "updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include ('header.php'); ?>

<br>
<div class="breadcome-area">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="breadcome-list">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <a href="../student_reg.php">
              	<button class="btn btn-primary">
              		<i class="fas fa-plus-square"></i>
              		Create Student Account
              	</button>
              </a>
              <a href="../instruc_reg.php">
              	<button class="btn btn-warning">
              		<i class="fas fa-plus-square"></i>
              		Create Faculty Account
              	</button>
              </a>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <ul class="breadcome-menu">
                <li><span class="bread-blod">Computer Aided Instruction</span> / Admin</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<br><br><br>
<div class="container-fluid">
	<div class="panel-body">
    	<div class="row">
    		<div class="col-lg-12">
    			<div class="row">
    				<div class="col-lg-12">
    					<h3 class="text-center">Manage Accounts</h3>
    				</div>
    			</div>
    			<br>
                <table width="100%" class="table table-striped table-bordered table-hover" id="mytable">
                    <thead>
                        <tr>
							              <td><b>Accout Type</b></td>
                            <td><b>Username</b></td>
                            <td><b>Password</b></td>
              							<td><b>Name</b></td>
                            <td><b>Email</b></td>
							              <td><b>Action</b></td>
                        </tr>
                    </thead>
                    <tbody style="font-size:9pt;">
<?php

	$conn = mysqli_connect("localhost", "root", "", "cai_it4");

	$sql = "SELECT * FROM members WHERE type != 'Admin' AND confirmation='1' ";
	$res = $conn->query($sql);

	$result = "";

	while($row = $res->fetch_assoc()){
		$result .= "<tr>";
		$result .= "<td>".$row['type']."</td>";
        $result .= "<td>".$row['username']."</td>";
        $result .= "<td>".$row['password']."</td>";
		$result .= "<td>".ucfirst($row['firstname'])." ".ucfirst($row['lastname'])."</td>";
		$result .= "<td>".$row['email']."</td>";
        $result .= "<td>
            <form method='post' action='accounts.php'>
                <input type='hidden' name='remove' value='1' />
                <input type='hidden' name='id' value='".$row['member_id']."' />
                <button type='submit' class='btn btn-danger'><i class='fas fa-user-alt-slash'></i> Remove</button>
            </form>
        </td>";
		$result .= "</tr>";
	}

	 if($result == ""){
    	echo "<tr><td colspan='8' class='text-center'>There is no accounts to manage</td></tr>";
    }else{
    	echo $result;
    }

?>
                    </tbody>
                </table>
            </div>
   		</div>
    </div>
</div>

<?php include "footer.php"; ?>