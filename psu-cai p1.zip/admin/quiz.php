<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>

<?php

  include("../session/DBConnection.php");
    require_once("../includes/session.php"); 
    require_once("../includes/connection.php");
  include "functions.php";

    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $current_lesson = $display['current_lesson'];
    $current_quiz = $display['current_quiz'];
    $fullname = $name." ".$lastname;

    if($pix == ""){$pix = SetProfileByGender($display['gender']);}

?>

  <title>Admin - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

  <?php include "links.php"; ?>
  
</head>
<body style="">

<?php
    include "updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>

<?php include ('header.php'); ?>

<br>
<div class="breadcome-area">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="breadcome-list">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <ul class="breadcome-menu">
                <li><span class="bread-blod">Computer Aided Instruction</span> / Admin</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php 
  
  if(isset($_GET['add'])){
    
    include "quiz_add.php";

  }else if(isset($_GET['view'])){

    include "../quiz_view.php";
  
  }else if(isset($_GET['edit'])){

    include "../quiz_edit.php";

  }else if(isset($_GET['delete'])){

    $conn = mysqli_connect("localhost", "root", "", "cai_it4");

    $id = $_GET['delete'];
    $sqlx = "SELECT * FROM questions WHERE quiz_id='$id'";
    $resx = $conn->query($sqlx);

    while($row = $resx->fetch_assoc()){
      $sql = "DELETE FROM answers WHERE questions_id=".$row['questions_id'];
      $res = $conn->query($sql);
    }

    $sql2 = "DELETE FROM questions WHERE quiz_id=".$_GET['delete'];
    $sql3 = "DELETE FROM quiz WHERE quiz_id=".$_GET['delete'];

    $res2 = $conn->query($sql2);
    $res3 = $conn->query($sql3);

  }else if(!isset($_GET['add']) && !isset($_GET['view']) && !isset($_GET['edit']) && !isset($_GET['pos'])){

     echo '<div class="courses-area">
            <div class="container-fluid">
              <div class="row">';
  }

?>

<?php

  if(!isset($_GET['view']) && !isset($_GET['add']) && !isset($_GET['edit']) && !isset($_GET['pos'])){

    echo '<div class="product-status">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="product-status-wrap">
              <h4>All Quizes</h4>
              <div class="add-product">
                <a class="Primary mg-b-10" href="quiz.php?add=1"><i class="fas fa-calendar-plus"></i> New Quiz</a>
              </div>
              <div class="asset-inner">
                <table>
                  <thead>
                    <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Total Items</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>';
                    
    $query = mysql_query("SELECT * FROM quiz") or die (mysql_error());

    $count = 0;
    while($row = mysql_fetch_array($query)){
      echo "<tr><td>".$row['pos']."</td>";
      echo "<td>".$row['quiz_title']."</td>";
      echo "<td>".$row['item_student']."</td>";
      echo '<td>
              <a href="quiz.php?view='.$row['quiz_id'].'"><button data-toggle="tooltip" title="Preview this quiz" class="pd-setting-ed"><i class="fas fa-eye" aria-hidden="true"></i></button></a>
              <a style="display:none;" href="quiz.php?delete='.$row['quiz_id'].'"><button data-toggle="tooltip" title="Delete this quiz" class="pd-setting-ed"><i class="fas fa-trash" aria-hidden="true"></i></button></a>
            </td>';
      echo "</tr>";
      $count++;
    }

    if($count == 0) echo "<tr><td colspan='8'><center>You have no quizes to manage</center></td></tr>";
                    
    echo '</tbody>
                </table>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>';
   
  }

?>

<?php
  if(!isset($_GET['view']) && !isset($_GET['add']) && !isset($_GET['edit'])) echo "</div></div></div>";
?>

<br><br>

<?php include "footer.php"; ?>
