    
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
  	<link rel="shortcut icon" type="image/x-icon" href="../images/favicon2.ico">
    
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../fonts/fa/css/all.css">
    <script type="text/javascript" src="../fonts/fa/js/all.js"></script>
    <link rel="stylesheet" href="../css/owl.carousel.css">
    <link rel="stylesheet" href="../css/owl.theme.css">
    <link rel="stylesheet" href="../css/owl.transitions.css">
    <link rel="stylesheet" href="../css/animate.css">
    <link rel="stylesheet" href="../css/normalize.css">
    <link rel="stylesheet" href="../css/meanmenu.min.css">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/modals.css">
    <link rel="stylesheet" href="../css/form/all-type-forms.css">
    <link rel="stylesheet" href="../css/educate-custon-icon.css">
    <link rel="stylesheet" href="../css/morrisjs/morris.css">
    <link rel="stylesheet" href="../css/scrollbar/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="../css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="../css/metisMenu/metisMenu-vertical.css">
    <link rel="stylesheet" href="../css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="../css/calendar/fullcalendar.print.min.css">
    <link rel="stylesheet" href="../css/editor/select2.css">
    <link rel="stylesheet" href="../css/editor/datetimepicker.css">
    <link rel="stylesheet" href="../css/editor/bootstrap-editable.css">
    <link rel="stylesheet" href="../css/editor/x-editor-style.css">
    <link rel="stylesheet" href="../css/data-table/bootstrap-table.css">
    <link rel="stylesheet" href="../css/data-table/bootstrap-editable.css">
    <link href="../js/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
	<link href="../js/datatables-responsive/dataTables.responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/alerts.css">
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <script src="../js/vendor/modernizr-2.8.3.min.js"></script>

    <style type="text/css">
     
    .thumbnail video{
        width: 100%;
        cursor:pointer;
    }

    .thumbnail video:hover{
        background:orange;
    }

    .thumbnail2{
        cursor:pointer;
        text-align: center;
        border: 0.5px solid #223345;
        padding:15px;
        margin: 5px;
        border-radius: 5px;
    }

    .thumbnail2:hover{
        border: 1px solid orange;
        color:orange;
    }

    .badge{
        background-color:rgba(255,0,0,0.9);
        margin-top:-25px;
        margin-left:-18px;
    }
    
    </style>
   