<?php

	$sql = "SELECT * FROM topics WHERE prof='$fullname'";
	$res = $conn->query($sql);

	$options = "";
	$count = 0;
	$quizes = array();
	$topicIds = array();

	while($row = $res->fetch_assoc()){
							
		$options .= "<option value='".$count."'>".$row['topic_name']."</option>";
		$topicID = $row['topic_id'];
						
		$sql2 = "SELECT * FROM quiz WHERE topic_id='$topicID' ";
		$res2 = $conn->query($sql2);

		$topicIds[] = $topicID;
		$totalquiz = 0;
		
		$quizestemp = null;

		while($row2 = $res2->fetch_assoc()){
			$totalquiz++;
			$quizestemp = $totalquiz;
		}

		if($totalquiz == 0){
			$quizestemp = $totalquiz;
		}

		$quizes[] = $quizestemp;
		$count++;
	}

?>

<div class="product-status">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-1"></div>
			<div class="col-lg-5">
				<p>Quiz Title</p>
				<input type="text" name="qtitle" class="form-control qtitle" autocomplete="off"><br>
			</div>
			<div class="col-lg-5">
				<p>Number of Questions</p>
				<input type="number" min="1" max="50" name="qnum" id="qnum" class="form-control qnum">
			</div>
		</div>
		<div class="row">
			<div class="col-lg-1"></div>
			<div class="col-lg-5">
				<button type="button" class="btn btn-default" onclick="generateQuestions()">
					<i class="fas fa-spinner fa-spin"></i> Generate</button>
				<br>
			</div>
			<div class="col-lg-5" style="display: none;">
				<p>Time Limit per Question (sec)</p>
				<input type="number" min="1" max="80" name="qnum" id="qnum" class="form-control qtime"><br>
			</div>
			<input type="hidden" name="qtopicid" class="qtopicid" />
		</div>

		<br>
		<hr>
		<br>
		
		<div id="q" style="display: none;">
		<div class="row">
			<div class="col-lg-1"></div>
			<div class="col-lg-8">
					<p id="qindicator"></p>
			</div>
			<div class="col-lg-2">
				<select name="qtype" class="form-control qtype" onchange="set(this.value)">
					<option value="-1">Select Type</option>
					<option value="1">Multiple Choice</option>
					<option value="2">Identification</option>
					<option value="3">True or False</option>
				</select>
			</div>
		</div>

		<!-- 	MULTIPLE CHOICE		-->
		<div id="mc" style="display: none;">
		<div class="row" id="qp">
			<div class="col-lg-1"></div>
			<div class="col-lg-10">
				<p>Enter question</p>
				<textarea class="form-control qq1" name="question" spellcheck="on" rows="3"></textarea>
				<br>
				<div class="row">
					<div class="col-lg-3"><input type="text" class="form-control c1" name="mca1" placeholder=" Choice A" ></div>
					<div class="col-lg-3"><input type="text" class="form-control c2" name="mca2" placeholder=" Choice B" ></div>
					<div class="col-lg-3"><input type="text" class="form-control c3" name="mca3" placeholder=" Choice C" ></div>
					<div class="col-lg-3"><input type="text" class="form-control c4" name="mca4" placeholder=" Choice D" ></div>
				</div>
			</div>
		</div>
		<br>
		<div class="row" id="qans">
			<div class="col-lg-1"></div>
			<div class="col-lg-6">
				<p>Answer</p>
				<textarea class="form-control qans1" name="qans"></textarea>
			</div>
		</div>

		<br>
		<div class="row">
			<div class="col-lg-1"></div>
			<div class="col-lg-3">
				<button class="btn btn-primary form-control insertBtn">Insert</button>
			</div>
			<div class="col-lg-3">
				<button class="btn btn-default form-control resettBtn">Reset</button>
			</div>
		</div>
		</div>
		<!-- 	MULTIPLE CHOICE		-->

		<!-- 	IDENTIFICATION		-->
		<div id="iden" style="display: none;">
		<div class="row" id="qp">
			<div class="col-lg-1"></div>
			<div class="col-lg-10">
				<p>Enter question</p>
				<textarea class="form-control qq2" name="question" spellcheck="on" rows="3"></textarea>
				<br>
			</div>
		</div>
		<br>
		<div class="row" id="qans">
			<div class="col-lg-1"></div>
			<div class="col-lg-6">
				<p>Answer</p>
				<textarea class="form-control qans2" name="qans"></textarea>
			</div>
		</div>

		<br>
		<div class="row">
			<div class="col-lg-1"></div>
			<div class="col-lg-3">
				<button class="btn btn-primary form-control insertBtn">Insert</button>
			</div>
			<div class="col-lg-3">
				<button class="btn btn-default form-control resettBtn">Reset</button>
			</div>
		</div>
		</div>
		<!-- 	IDENTIFICATION		-->

		<!-- 	TRUE OR FALSE		-->
		<div id="tf" style="display: none;">
		<div class="row" id="qp">
			<div class="col-lg-1"></div>
			<div class="col-lg-10">
				<p>Enter question</p>
				<textarea class="form-control qq3" name="question" spellcheck="on" rows="3"></textarea>
				<br>
			</div>
		</div>
		<br>
		<div class="row" id="qans">
			<div class="col-lg-1"></div>
			<div class="col-lg-6">
				<p>Answer</p>
				<select class="form-control qans3" name="qans">
					<option>True</option>
					<option>False</option>
				</select>
			</div>
		</div>

		<br>
		<div class="row">
			<div class="col-lg-1"></div>
			<div class="col-lg-3">
				<button class="btn btn-primary form-control insertBtn">Insert</button>
			</div>
			<div class="col-lg-3">
				<button class="btn btn-default form-control resettBtn">Reset</button>
			</div>
		</div>
		</div>
		<!-- 	TRUE OR FALSE		-->

		</div>

	</div>
</div>

<script type="text/javascript">
	
	var totalq = 0;
	var ID = "";

	function generateQuestions(){

		var t = $(".qtitle").val();
		var tm = $(".qtime").val();
		var n = $("#qnum").val();
		var tot = $(".qtotal").val();
		var tid = $(".qtopicid").val();

		if(n > 0 && t != "" && n <= 50){

			$.post("quiz_add_func.php", {
				
				title: t,
				desc: "",
				time: tm,
				num: n,
				total: tot,
				topicid: tid,
				fac: ""

			}, function(data, status){

				if(data){
					$("#q").show();
					$("#qindicator").html("Questions created: <b>"+totalq+"/"+n+"</b>");	
					ID = data;
				}

			});

		}else if(n > 50){
			alert("Number of questions exceeded! You can only save up to 50 questions");
		}else{
			alert("Please complete all required fields.");
		}
	
	}

	function set(type){

		if(type == "1"){
			if($("#iden").show()) $("#iden").hide();
			if($("#tf").show()) $("#tf").hide();
			$("#mc").show();
		}

		if(type == "2"){
			if($("#mc").show()) $("#mc").hide();
			if($("#tf").show()) $("#tf").hide();
			$("#iden").show();
		}

		if(type == "3"){
			if($("#iden").show()) $("#iden").hide();
			if($("#mc").show()) $("#mc").hide();
			$("#tf").show();
		}

	}

	window.onload = function(){

		$(".insertBtn").on("click", function(){

			var q = "";
			var a = "";
			var mc = false;

			if($(".qtype").val() == "1"){
				q = $(".qq1").val();
				a = $(".qans1").val();
				mc = true;
			}else if ($(".qtype").val() == "2"){
				q = $(".qq2").val();
				a = $(".qans2").val();
			}else if ($(".qtype").val() == "3"){
				q = $(".qq3").val();
				a = $(".qans3").val();
			}

			$.post("quiz_add_func2.php", {
				
				title: $(".qtitle").val(),
				id: ID,
				q: q,
				type: $(".qtype").val(),
				c1: (mc) ? $(".c1").val() : "",
				c2: (mc) ? $(".c2").val() : "",
				c3: (mc) ? $(".c3").val() : "",
				c4: (mc) ? $(".c4").val() : "",
				ans: a

			}, function(data, status){

				console.log(data)

				var i = $("#qnum").val();

				if(data){
					//alert(data);
					reset();
					totalq = data;
					$("#qindicator").html("Questions created: <b>"+data+"/"+i+"</b>");
					
					if(data == i){
						alert("Quiz added successfully!");
						$("#q").hide();
					}
				}

			});		

		});

		$(".resettBtn").on("click", function(){

			reset();
		
		});

		function reset(){
			$(".qq1").val("");
			$(".qq2").val("");
			$(".qq3").val("");
			$(".c1").val("");
			$(".c2").val("");
			$(".c3").val("");
			$(".c4").val("");
			$(".qans1").val("");
			$(".qans2").val("");
			$(".qans3").val("");
		}

	}

	function filterTopic(idx, data, id){
		console.log(data[idx]);
		document.getElementsByClassName("qtotal")[0].value = data[idx];
		document.getElementsByClassName("qtopicid")[0].value = id[idx];
	}

</script>