<?php

	/***********************************************************************************/
    //ACCOUNTS
    
    function ConfirmAccount($id){

    	$conn = mysqli_connect("localhost", "root", "", "cai_it4");

    	$sql = "UPDATE members SET confirmation='1' WHERE member_id='$id' ";
        $res = $conn->query($sql);

        header("Location: ./");
    }

    function DeleteAccount($id){

    	$conn = mysqli_connect("localhost", "root", "", "cai_it4");

    	$query = mysql_query("SELECT * FROM members WHERE member_id = '$id'") or die (mysql_error()); 
        $display = mysql_fetch_array($query);

        $fullname = $display['firstname']." ".$display['lastname'];
        $groupkey = $display["group_key"];
        $type = $display["type"];

        $profsql = "SELECT * FROM chapters WHERE prof = '$fullname'"; 
        $chapters = $conn->query($profsql);

        while ($row = $chapters->fetch_assoc()) {
            $sql4 = "DELETE FROM chapters WHERE id=".$row['id'];
            $res4 = $conn->query($sql4);   
        }

        $profsql2 = "SELECT * FROM topics WHERE prof = '$fullname'"; 
        $topics = $conn->query($profsql2);

        while ($row = $topics->fetch_assoc()) {
            $sql4 = "DELETE FROM topics WHERE topic_id=".$row['topic_id'];
            $res4 = $conn->query($sql4);
        }

        $profsql3 = "SELECT * FROM quiz WHERE faculty_name = '$fullname'"; 
        $quizes = $conn->query($profsql3);

        while ($row = $quizes->fetch_assoc()) {
            $sql4 = "DELETE FROM quiz WHERE quiz_id=".$row['quiz_id'];
            $res4 = $conn->query($sql4);
        }

        if($type == "Faculty"){
          $sql = "UPDATE groups SET faculty_name='' WHERE group_key='$groupkey'";
          $res = $conn->query($sql);
        }

        $sql = "DELETE FROM logs WHERE memberid='$id'";
        $res = $conn->query($sql);

        $sql2 = "DELETE FROM updates WHERE member_id='$id'";
        $res2 = $conn->query($sql2);

        $sql3 = "DELETE FROM messages WHERE recipient=".$display['email'];
        $res3 = $conn->query($sql3);

        $sql6 = "DELETE FROM grades WHERE stud_id='$id'";
        $res6 = $conn->query($sql6);

        $sql7 = "DELETE FROM results WHERE quizzer_name=".$fullname;
        $res7 = $conn->query($sql7);

        $sql8 = "DELETE FROM members WHERE member_id='$id' ";
        $res8 = $conn->query($sql8);

        header("Location: accounts.php");

    }
    //ACCOUNTS
    /***********************************************************************************/

	function time_elapsed_string($datetime, $full = false) {

        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }

    function GenerateKey(){
      
      $key = uniqid();
      $finalkey = $key[0].$key[1].$key[2].$key[3].$key[4].$key[5];
    
      $conn = mysqli_connect("localhost", "root", "", "cai_it4");
      $sql = "SELECT * FROM groups WHERE group_key = '$finalkey' ";
      $res = $conn->query($sql);
      $count = 0;
      while($row = $res->fetch_assoc()){
        $count++;
      }
      
      if($count == 0){
        return $finalkey;
      }else{
        //generateKey();
      }

    }

	//TUTORIALS
    /***********************************************************************************/    

    function LoadTutorials(){

    	$conn = mysqli_connect("localhost", "root", "", "cai_it4");
      $sql = "SELECT * FROM tutorials";
      $res = $conn->query($sql);

      $div = "";
      while($row = $res->fetch_assoc()){

        $div .= "<div class='col-lg-3 thumbnail'>";
        $div .= "<label>".$row['title']."</label><br>";
        $div .= "<video src='".$row['_path']."' width='120' height='150' ></video><br>";
        $div .= "<div style='width:100%;height:100%;background:;'>";
        $div .= "<a style='padding:7px;' href='../tutorial-play2.php?source=".$row['_path']."'><i class='fas fa-play fa-2x'></i></a>";
        $div .= "<a style='padding:7px;' href='tutorials.php?remove&id=".$row['id']."'><i class='fas fa-trash fa-2x'></i></a>";
        $div .= "</div></div>";
      }

      return $div;

    }

    function LoadLessons(){

		  $conn = mysqli_connect("localhost", "root", "", "cai_it4");
      $sql = "SELECT * FROM lessons";
      $res = $conn->query($sql);

      $div = "";
      while($row = $res->fetch_assoc()){
        $div .= "<div class='col-lg-4s thumbnail2'>";
        $div .= "<label>".$row['title']."</label><br>";
        $div .= "<span><i class='fas fa-book-open fa-8x' style='color:lightblue;'></i></span>";
        $div .= "<div style='width:100%;height:100%;background:;'>";
        $div .= "<a style='padding:7px;' href='".$row['_path']."'><i class='fas fa-eye fa-2x'></i></a>";
        $div .= "<a style='padding:7px;' href='lessons.php?remove&id=".$row['id']."'><i class='fas fa-trash fa-2x'></i></a>";
        $div .= "</div></div>";
      }

      return $div;

    }

    function RemoveLesson($id){
       $conn = mysqli_connect("localhost", "root", "", "cai_it4");
       $getpath = "SELECT * FROM lessons WHERE id=".$id;
       $res = $conn->query($getpath);
       $path = "";
       $filename = "";
       while($row = $res->fetch_assoc()){
        $path = $row["_path"];
        $filename = str_replace("uploads/lessons/", "", $path);
       }
       if(unlink($path)){
        $delete = "DELETE FROM lessons WHERE id=".$id;
        $res = $conn->query($delete);
        if($res){
          //echo "Removed!";
          return true;
        }else{
          //echo "Removing from database has failed!";
          return false;
        }
       }else{
        //echo "Unable to remove!";
        return false;
       }
    }

    function RemoveTutorial($id){
       $conn = mysqli_connect("localhost", "root", "", "cai_it4");
       $getpath = "SELECT * FROM tutorials WHERE id=".$id;
       $res = $conn->query($getpath);
       $path = "";
       $filename = "";
       while($row = $res->fetch_assoc()){
        $path = $row["_path"];
        $filename = str_replace("uploads/tutorials/", "", $path);
       }
       if(unlink($path)){
        $delete = "DELETE FROM tutorials WHERE id=".$id;
        $res = $conn->query($delete);
        if($res){
          //echo "Removed!";
          return true;
        }else{
          //echo "Removing from database has failed!";
          return false;
        }
       }else{
        //echo "Unable to remove!";
        return false;
       }
    }

    //TUTORIALS
    /***********************************************************************************/    

    function SetProfileByGender($gender){
    	if($gender == "Male"){ return "../uploads/propicm.png";} else { return "uploads/propicf.png";}
    }


    function GetIP(){
    	return gethostbyname(gethostname());
    }

    function UploadFile($type, $file, $path, $save, $title){

    	if($type == "video"){

    		$allowedExts = array("mp4", "wmv", "3gp");
			  $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = $title . "." .$extension;

			  if (($file["type"] == "video/mp4")
			  || ($file["type"] == "video/3gp")
			  || ($file["type"] == "video/wmv")

			  && ($file["size"] < 100000000)
			  && in_array($extension, $allowedExts))

  			{
  				if ($file["error"] > 0){
			    	return "404";
    			}else{

		    		if(file_exists($path . $filename)){
					    return "303";
      			}else{
			    	  move_uploaded_file($file["tmp_name"], $path . $filename);
      			}

            if($save){

              $path = $path . $filename;
              $conn = mysqli_connect("localhost", "root", "", "cai_it4");
              $sql = "INSERT INTO tutorials (title, _path) VALUES ('$title', '$path')";
              $res = $conn->query($sql);
              
              if($res) return "success";
              else return "505";
            
            }

    			}
  			}else{
		    	return "404";
  			}
    	
      }else if($type == "pdf"){

        $allowedExts = array("pdf");
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = $title . "." .$extension;

        if (($file["type"] == "application/pdf")
        && ($file["size"] < 100000000)
        && in_array($extension, $allowedExts))

        {
          if ($file["error"] > 0){
            return "404";
          }else{

            if(file_exists($path . $filename)){
              return "303";
            }else{
              move_uploaded_file($file["tmp_name"], $path . $filename);
            }

            if($save){

              $path = $path . $filename;
              $conn = mysqli_connect("localhost", "root", "", "cai_it4");
              $sql = "INSERT INTO lessons (title, _path) VALUES ('$title', '$path')";
              $res = $conn->query($sql);
              
              if($res) return "success";
              else return "505";
            
            }

          }
        }else{
          return "404";
        }

      }
	
	}

  function CreateAlert($head, $content, $style, $icon){
    echo '<div class="alert alert-success-'.$style.' alert-success-stylenone">
            <button type="button" class="close sucess-op" data-dismiss="alert" aria-label="Close">
              <span class="icon-sc-cl" aria-hidden="true">×</span>
            </button> 
            <i class="fas '.$icon.' admin-check-sucess admin-check-pro-none" style="margin-left:15px;"></i>
            <p style="color:#fff;"><strong>'.$head.'</strong> &nbsp;'.$content.'</p>
          </div>';
  }

    function GtUpdates($user){

    	$conn = mysqli_connect("localhost", "root", "", "cai_it4");

  $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
  $display = mysql_fetch_array($query);

  /////////////////////////////////////////////////////////////////////////FACULTY
  $updateCount = 0;
  $updater = "";

  //LOGS
  $sql = "SELECT * FROM logs LIMIT 99";
  $res = $conn->query($sql);

  $updates = "";
  while($row = $res->fetch_assoc()){

    $loggerid = $row['memberid'];

    if($loggerid != $display['member_id']){

        $sqlx = "SELECT * FROM members WHERE member_id='$loggerid' ";
        $resx = $conn->query($sqlx);

        $Lname = "";
        $Limg = "";

        while($rowx = $resx->fetch_assoc()){$Lname=$rowx['firstname']." ".$rowx['lastname']; $Limg=$rowx['image'];}

        $updates .= '<li>
                  <a href="#">
                    <div class="notification-icon">
                      <i class="fas fa-user-clock aria-hidden="true"></i>
                    </div>
                    <div class="notification-content">
                      <span class="notification-date">'.$row['datein'].'</span>
                      <h2>'.$Lname.'</h2>
                      <p>Has logged in to the system. <i>'.$row['timein'].'</i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    </div>
                  </a>
               </li>';
        $updateCount++;

    }
  }

  $sql3 = "SELECT * FROM updates ";
  $res3 = $conn->query($sql3);

  while($row2 = $res3->fetch_assoc()){
            
    $sqlx2 = "SELECT * FROM members WHERE member_id=".$row2['member_id'];
    $resx2 = $conn->query($sqlx2);

    $Lname2 = "";

    while($rowx2 = $resx2->fetch_assoc()){$Lname2=$rowx2['firstname']." ".$rowx2['lastname']; $Limg2=$rowx2['image'];}

    $icon = "";

    if($row2['status'] == "Has taken a quiz"){
        $icon = '<i class="fas fa-edit aria-hidden="true"></i>';
    }else if($row2['status'] == "Added a new lesson"){
        $icon = '<i class="fas fa-laptop-code aria-hidden="true"></i>';
    }else if($row2['status'] == "Added a new quiz"){
        $icon = '<i class="fas fa-newspaper aria-hidden="true"></i>';
    }
            
    $updates .= '<li>
                  <a href="#">
                    <div class="notification-icon">'.$icon.'</div>
                    <div class="notification-content">
                      <span class="notification-date">'.time_elapsed_string($row2['dt']).'</span>
                      <h2>'.$Lname2.'</h2>
                      <p>'.$row2['status'].' <i style="color:#fff;">........................</i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    </div>
                  </a>
               </li>';

    $updateCount++;

  }

  $updater = '<span class="badge badge-notif">'.$updateCount.'</span>';

  if($updateCount == 0) $updates = "<p class='text-center'>No new notifications</p>";

  $result = Array();

  $result[] = $updates;
  $result[] = $updater;

  return $result;

    }

?>