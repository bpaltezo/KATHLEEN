<?php

$conn = mysqli_connect("localhost", "root", "", "cai_it4");
$id = $_POST['id'];
$q = $_POST['q'];
if($_POST['type'] == "1") $type = "Multiple Choice";
if($_POST['type'] == "2") $type = "Identification";
if($_POST['type'] == "3") $type = "True or False";
$c1 = $_POST['c1'];
$c2 = $_POST['c2'];
$c3 = $_POST['c3'];
$c4 = $_POST['c4'];
$answer = $_POST['ans'];
$title = $_POST['title'];

#echo $answer."<br>";
#echo $q."<br>";
#echo $c1."<br>";
#echo $c2."<br>";
#echo $c3."<br>";
#echo $c4."<br>";
#echo $type."<br>";

$xsql =  "SELECT * FROM quiz WHERE quiz_title='$title' ";
$xres = $conn->query($xsql);

while ($row = $xres->fetch_assoc()) {
	$q_id = $row['quiz_id'];
}

$sql = "INSERT INTO questions (quiz_id,questions_question,questions_type,qid) VALUES ('$q_id', '$q', '$type','$q_id')";
$res = $conn->query($sql);

$ysql = "SELECT * FROM questions WHERE questions_question='$q'";
$yres = $conn->query($ysql);

while($row = $yres->fetch_assoc()){
	$qid = $row['questions_id'];
}

$sql2 = "INSERT INTO answers (questions_id, answer, correct, choice1, choice2, choice3, choice4)
		 VALUES ('$qid', '', '$answer', '$c1', '$c2', '$c3', '$c4')";
$res2 = $conn->query($sql2);

if($res && $res2){

	$sql3x = "SELECT * FROM questions WHERE qid='$q_id'";
	$res3x = $conn->query($sql3x);
	$result = 0;
	while($row = $res3x->fetch_assoc()){
		$result++;
	}
	echo $result;

}else{

	echo "err";

}

?>