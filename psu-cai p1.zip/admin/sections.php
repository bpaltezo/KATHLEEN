<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>

<?php

  include("../session/DBConnection.php");
    require_once("../includes/session.php"); 
    require_once("../includes/connection.php");
  include "functions.php";

    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $current_lesson = $display['current_lesson'];
    $current_quiz = $display['current_quiz'];
    $fullname = $name." ".$lastname;

    if($pix == ""){$pix = SetProfileByGender($display['gender']);}

?>

  <title>Admin - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

  <?php include "links.php"; ?>
  
</head>
<body style="">
  
<?php
    include "updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>

<?php include ('header.php'); ?>

<br>
<div class="breadcome-area">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="breadcome-list">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <ul class="breadcome-menu">
                <li><span class="bread-blod">Computer Aided Instruction</span> / Admin</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php 
  
  if(isset($_GET['delete'])){

    $conn = mysqli_connect("localhost", "root", "", "cai_it4");

    $id = $_GET['delete'];
    $sqlx = "DELETE FROM groups WHERE group_key='$id'";
    $resx = $conn->query($sqlx);
    if($resx){
      header("Location: sections.php");
    }

  }else if(isset($_POST['add'])){

    $conn = mysqli_connect("localhost", "root", "", "cai_it4");

    $key = $_POST['gkey'];
    $name = $_POST['gname'];
    $prof = $_POST['prof'];

    $sql = "INSERT INTO groups (group_key,group_name,image,faculty_name) VALUES ('$key','$name','uploads/Gimage.jpg','$prof')";
    $res = $conn->query($sql);
    if($res){
      header("Location: sections.php");
    }

  }else if(isset($_POST['assign'])){

    $conn = mysqli_connect("localhost", "root", "", "cai_it4");

    $key = $_POST['gkey'];
    $name = $_POST['gname'];
    $prof = $_POST['prof'];
    $fullname = explode(" ", $prof);
    $fn = $fullname[0];
    $ln = $fullname[1];
    $sql = "UPDATE groups SET faculty_name='$prof' WHERE group_key='$key' ";
    $res = $conn->query($sql);

    $sql2 = "UPDATE members SET group_key='$key' WHERE lastname='$ln' AND firstname='$fn' ";
    $res2 = $conn->query($sql2);

    if($res && $res2){
      header("Location: sections.php");
    }

  }

?>

<div class="courses-area">
  <div class="container-fluid">
    <div class="row">
      <div class="product-status">
        <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="product-status-wrap">
              <h4>All Sections</h4>
              <div class="add-product">
                <button class="btn btn-primary addModal" data-toggle="modal" data-target="#Modalx" style="float: right;">
                  <i class="fas fa-calendar-plus"></i> New Block</button>
                <br><br><br>
              </div>
              <div class="asset-inner">
                <table>
                  <thead>
                    <tr>
                    <th></th>
                    <th>Name</th>
                    <th>Instructor</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  
<?php

  if(!isset($_GET['view']) && !isset($_GET['add']) && !isset($_GET['edit']) && !isset($_GET['pos'])){

                    
    $query = mysql_query("SELECT * FROM groups ORDER BY group_name ASC") or die (mysql_error());

    $count = 0;
    while($row = mysql_fetch_array($query)){
      echo "<tr><td></td>";
      echo "<td>".$row['group_name']."</td>";
      echo "<td>".$row['faculty_name']."</td>";
      echo '<td>
              <a href="sections.php?delete='.$row['group_key'].'"><button data-toggle="tooltip" title="Delete this block" class="btn btn-danger"><i class="fas fa-trash" aria-hidden="true"></i> Delete</button></a> &nbsp;
              <a href="#" data-toggle="modal" data-target="#mx"><button onclick="PassData('.$count.')" data-toggle="tooltip" title="Assign instructor to this section" class="btn btn-success"><i class="fas fa-chalkboard-teacher" aria-hidden="true"></i> Assign</button></a>
            </td>';
      echo "</tr>";
      echo "<input type='hidden' class='igk' value='".$row['group_key']."' />";
      echo "<input type='hidden' class='ign' value='".$row['group_name']."' />";
      $count++;
    }

    if($count == 0) echo "<tr><td colspan='8'><center>You have no sections to manage</center></td></tr>";
   
  }

?>

                  </tbody>
                </table>
              </div>
              
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>
</div>


<div id="Modalx" class="modal modal-edu-general default-popup-PrimaryModal fade" role="dialog" style="display: none;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-close-area modal-close-df">
        <a class="close" data-dismiss="modal" href="#"><i class="fas fa-times"></i></a>
      </div>

      <form method="post" action="sections.php">
          
        <div class="modal-body">
          <div class="row">
            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
              <div class="breadcome-headin text-left">
                  <label>Group Key</label>
                  <input type="text" class="form-control gkey" name="gkey" value="" readonly >
                  <br>
                  <label>Group Name</label>
                  <input type="text" class="form-control" name="gname" autocomplete="off" required>
                  <br>
                  <label>Instructor</label>
                  <select class="form-control" name="prof">
                    <option></option>
                    <?php

                      $sql = "SELECT * FROM members WHERE group_key='' AND type='Faculty'";
                      $res = $conn->query($sql);

                      while($row = $res->fetch_assoc()){
                        echo "<option>".$row['faculty_name']."</option>";
                      }

                    ?>
                  </select>
                  <input type="hidden" name="add">
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button data-dismiss="modal" href="#" class="btn btn-default" >Cancel</button>
          <button type="submit" class="btn btn-success" >Submit</button>
        </div>
        </form>

    </div>
  </div>
</div>

<div id="mx" class="modal modal-edu-general default-popup-PrimaryModal fade" role="dialog" style="display: none;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-close-area modal-close-df">
        <a class="close" data-dismiss="modal" href="#"><i class="fas fa-times"></i></a>
      </div>

      <form method="post" action="sections.php">
          
        <div class="modal-body">
          <div class="row">
            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
              <div class="breadcome-headin text-left">
                  <label>Group Key</label>
                  <input type="text" class="form-control xgkey" name="gkey" value="" readonly >
                  <br>
                  <label>Group Name</label>
                  <input type="text" class="form-control xgname" name="gname" autocomplete="off" required>
                  <br>
                  <label>Available Instructors</label>
                  <select class="form-control" name="prof">
                    <?php

                      $sql = "SELECT * FROM members WHERE group_key = '' AND type='Faculty' ";
                      $res = $conn->query($sql);

                      while($row = $res->fetch_assoc()){
                        echo "<option>".$row['firstname']." ".$row['lastname']."</option>";
                      }

                    ?>
                  </select>
                  <input type="hidden" name="assign">
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button data-dismiss="modal" href="#" class="btn btn-default" >Cancel</button>
          <button type="submit" class="btn btn-success" >Submit</button>
        </div>
        </form>

    </div>
  </div>
</div>

<?php include "footer.php"; ?>

<script type="text/javascript">
  
  window.onload = function(){

    $(".addModal").on("click", function(){
      $(".gkey").val(function(){
        var letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i"];
        var numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
        var result = "";
        for(var x=0;x<3;x++){
          var Lidx = Math.random()*9;
          var Nidx = Math.random()*9;
          console.log(Math.floor(Lidx), Math.floor(Nidx));

          result += letters[Math.floor(Lidx)];
          result += numbers[Math.floor(Nidx)];
        }
        return result;
      });
    });

  }

  function PassData(index){
    var groupkey = document.getElementsByClassName("igk")[index].value;
    var groupname = document.getElementsByClassName("ign")[index].value;
    document.getElementsByClassName("xgkey")[0].value = groupkey;
    document.getElementsByClassName("xgname")[0].value = groupname;
  }

</script>