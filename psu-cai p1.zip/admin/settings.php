<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>

<?php
	include("../session/DBConnection.php");	
	$user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $current_lesson = $display['current_lesson'];
    $current_quiz = $display['current_quiz'];
    $fullname = $name." ".$lastname;

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";

?>


<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/connection.php"); ?>
<?php include "functions.php"; ?>
<?php

    if(isset($_POST['old']) && isset($_POST['new'])){

        $new = $_POST['new'];
        $sql = "UPDATE members SET password='$new' WHERE member_id=".$display['member_id'];
        $res = $conn->query($sql);
    
        header("Location: admin_settings.php");
    }

?>

<title>CAI - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

<?php include "links.php"; ?>

</head>
<body style="">

<?php
    include "updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>

<?php include ('header.php'); ?>

<br>
<div class="error-pagewrap">
    <div class="error-page-int">
        <div class="text-center ps-recovered">
            <h3>SYSTEM ADMIN SETTINGS</h3>
        </div>
        <div class="content-error">
            <div class="hpanel">
                <div class="panel-body poss-recover">
                    <p>
                        Reset your password.
                    </p>
                    <form action="admin_settings.php" method="post" id="loginForm">
                        <div class="form-group">
                            <label class="control-label" for="username">Old Password 
                                <span class="eye1"><i class="fas fa-eye"></i></span>
                            </label>
                            <input type="password" required="" value="<?php echo $display['password']; ?>" name="old" id="old" class="form-control">
                        </div>

                        <div class="form-group">
                            <label class="control-label" for="username">New Password 
                                <span class="eye2"><i class="fas fa-eye"></i></span>
                            </label>
                            <input type="password" title="Please enter your new password" required="" value="" name="new" id="new" class="form-control">
                        </div>

                        <button type="button" class="btn btn-success btn-block sbtn">Reset password</button>
                        <input type="submit" id="submitbtn" style="display: none;">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>

<script type="text/javascript">
(function ($) {
 "use strict";

    /*----------------------------
     jQuery MeanMenu
    ------------------------------ */
    jQuery('nav#dropdown').meanmenu();  
    /*----------------------------
     jQuery myTab
    ------------------------------ */
    $('#myTab a').on('click', function (e) {
          e.preventDefault()
          $(this).tab('show')
        });
        $('#myTab3 a').on('click', function (e) {
          e.preventDefault()
          $(this).tab('show')
        });
        $('#myTab4 a').on('click', function (e) {
          e.preventDefault()
          $(this).tab('show')
        });
        $('#myTabedu1 a').on('click', function (e) {
          e.preventDefault()
          $(this).tab('show')
        });

      $('#single-product-tab a').on('click', function (e) {
          e.preventDefault()
          $(this).tab('show')
        });
    
    $('[data-toggle="tooltip"]').tooltip(); 
    
    $('#sidebarCollapse').on('click', function () {
         $('#sidebar').toggleClass('active');
     });
    // Collapse ibox function
    $('#sidebar ul li').on('click', function () {
        var button = $(this).find('i.fa.indicator-mn');
        button.toggleClass('fa-plus').toggleClass('fa-minus');
        
    });
    /*-----------------------------
        Menu Stick
    ---------------------------------*/
    $(".sicker-menu").sticky({topSpacing:0});
        
    $('#sidebarCollapse').on('click', function () {
        $("body").toggleClass("mini-navbar");
        //SmoothlyMenu();
    });
    $(document).on('click', '.header-right-menu .dropdown-menu', function (e) {
          e.stopPropagation();
    });
    /*----------------------------
     wow js active
    ------------------------------ */
     new WOW().init();
    /*----------------------------
     owl active
    ------------------------------ */  
    $("#owl-demo").owlCarousel({
      autoPlay: false, 
      slideSpeed:2000,
      pagination:false,
      navigation:true,    
      items : 4,
      /* transitionStyle : "fade", */    /* [This code for animation ] */
      navigationText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
      itemsDesktop : [1199,4],
      itemsDesktopSmall : [980,3],
      itemsTablet: [768,2],
      itemsMobile : [479,1],
    });
    /*----------------------------
     price-slider active
    ------------------------------ */  
      $( "#slider-range" ).slider({
       range: true,
       min: 40,
       max: 600,
       values: [ 60, 570 ],
       slide: function( event, ui ) {
        $( "#amount" ).val( "£" + ui.values[ 0 ] + " - £" + ui.values[ 1 ] );
       }
      });
      $( "#amount" ).val( "£" + $( "#slider-range" ).slider( "values", 0 ) +
       " - £" + $( "#slider-range" ).slider( "values", 1 ) );
    /*--------------------------
     scrollUp
    ---------------------------- */ 
    $.scrollUp({
        scrollText: '<i class="fa fa-angle-up"></i>',
        easingType: 'linear',
        scrollSpeed: 900,
        animation: 'fade'
    });        
 
})(jQuery); 

    $(document).ready(function() {
    
        $(".eye1").on("click", function(){
            
            var f = document.getElementById("old");

            if(f.type == "password"){
                f.type = "text";
            }else if(f.type == "text"){
                f.type = "password";
            }

        });

        $(".eye2").on("click", function(){
            
            var f = document.getElementById("new");

            if(f.type == "password"){
                f.type = "text";
            }else if(f.type == "text"){
                f.type = "password";
            }

        });

        $(".sbtn").on("click", function(){

            if(document.getElementById("new").value != "" ){
                $("#submitbtn").click();
            }

        });

    });
</script>
