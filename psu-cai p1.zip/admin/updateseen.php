<?php

	session_start();
	$_SESSION["badge"] = "seen";

?>