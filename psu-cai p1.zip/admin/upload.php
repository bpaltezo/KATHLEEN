<?php include "functions.php"; ?>
<?php

	if($_POST['subject'] == "tutorial"){
		
		$upload = UploadFile("video", $_FILES['file'], "uploads/tutorials/", true, $_POST['title']);

		echo $upload;

		if($upload == "303"){
			header("Location: tutorials.php?upload=".$upload."&file=".$_POST['title']);
		}else{
			header("Location: tutorials.php?upload=".$upload);
		}
	
	}else if($_POST['subject'] == "lesson"){

		$upload = UploadFile("pdf", $_FILES['file'], "uploads/lessons/", true, $_POST['title']);

		echo $upload;

		if($upload == "303"){
			header("Location: lessons.php?upload=".$upload."&file=".$_POST['title']);
		}else{
			header("Location: lessons.php?upload=".$upload);
		}

	}
	

?>

<!-- 

upload_max_filesize is the limit of any single file. post_max_size is the limit of the entire body of the request, which could include multiple files.

Given post_max_size = 20M and upload_max_filesize = 6M you could upload up to 3 files of 6M each. If instead post_max_size = 6M and upload_max_filesize = 20M then you could only upload one 6M file before hitting post_max_size. It doesn't help to have upload_max_size > post_max_size.

It's not obvious how to recognize going over post_max_size. $_POST and $_FILES will be empty, but  $_SERVER['CONTENT_LENGTH'] will be > 0. If the client just didn't upload any post variables or files, then $_SERVER['CONTENT_LENGTH'] will be 0.
	
This probably means that the php script can't find the file. Good chance this is because the file you tried to upload was too big and the server rejected it. Check you php.ini file and change the upload_max_size property (change post_max_size aswell).

 -->