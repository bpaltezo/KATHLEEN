<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>

<?php

	include("../session/DBConnection.php");
    require_once("../includes/session.php"); 
    require_once("../includes/connection.php");
	include "functions.php";

    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $current_lesson = $display['current_lesson'];
    $current_quiz = $display['current_quiz'];
    $fullname = $name." ".$lastname;

    if($pix == ""){$pix = SetProfileByGender($display['gender']);}

?>


<?php

    if(isset($_POST['confirm'])){
        ConfirmAccount($_POST['id']);
    }

    if(isset($_POST['remove'])){
        DeleteAccount($_POST['id']);
    }

?>

	<title>Administrator Panel | CAI-PSULC</title>  

	<?php include "links.php"; ?>
	
</head>
<body style="">

<?php
    include "updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>

<?php include ('header.php'); ?>

<div class="breadcome-area">
  <div class="container-fluid">
    <br>
    
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="breadcome-list">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <h3>Welcome Admin</h3>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <ul class="breadcome-menu">
                <li><span class="bread-blod">Computer Aided Instruction</span> / Admin Panel</li>
              </ul>
            </div>
          </div>
          <br><br>
          <div class="row">
            <div class="col-lg-12">
                <div class="alert alert-success" role="alert" style="font-size: 14pt;">
                   <i class="fas fa-wifi fa-4x"></i> The system is running at <strong><?php echo GetIP(); ?></strong>
                </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>

<?php include "footer.php"; ?>