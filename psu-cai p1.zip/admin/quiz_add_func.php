<?php

$conn = mysqli_connect("localhost", "root", "", "cai_it4");

$title = $_POST['title'];
$desc = $_POST['desc'];
$time = $_POST['time'];
$num = $_POST['num'];
$fac = $_POST['fac'];
$total = 0;
$tid= $_POST['topicid'];

$sqlx = "SELECT * FROM quiz";
$resx = $conn->query($sqlx);

while($row = $resx->fetch_assoc()){
	$total++;
}

$total = $total + 1;

$sql = "INSERT INTO quiz (quiz_title, quiz_description, quiz_timelimit, item_student, faculty_name, topic_id, pos) 
		VALUES ('$title', '$desc', '$time', '$num', '$fac', '$tid', '$total')";
$res = $conn->query($sql);

if($res){
	$sql2 = "SELECT * FROM quiz WHERE quiz_title='$title' AND quiz_description='$desc' AND item_student='$num' AND faculty_name='$fac' ";
	$res2 = $conn->query($sql2);

	while($row = $res2->fetch_assoc()){
		echo $row['quiz_id'];
	}
}

?>