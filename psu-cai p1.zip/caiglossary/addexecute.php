<?php include_once './dbconnect.php'; 

	$name=mysql_real_escape_string ($_POST['name']);
	$description=mysql_real_escape_string($_POST['description']);
	$sql = mysql_query("SELECT g_id FROM cai_glossary WHERE name='$name' LIMIT 1");
	$samecontact = mysql_num_rows($sql); // count the output amount
    if ($samecontact > 0) {
		echo  "<script language='JavaScript'>alert('The term $name already exist. Please try other term or edit the existing one.'),window.location.href='view.php'; return false;</script>";
		exit();
	}
	else {
			$update=mysql_query("INSERT INTO cai_glossary(keyword, name, discription)VALUES('$name','$name','$description')");
			header("location:view.php");
			exit();
	}
?>
