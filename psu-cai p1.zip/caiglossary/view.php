<?php session_start();?>
 <?php
include("../session/DBConnection.php");
$user = $_SESSION['log']['username'];
      $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
      $display = mysql_fetch_array($query); 
      $key = $display['group_key'];
      ?>
<title>CAI - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  
<link rel="shortcut icon" HREF="images/dnsc_logo.png" />

<link href="images/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="./js/script.js" type="text/javascript" charset="utf-8"></script>
<script src="./js/application.js" type="text/javascript" charset="utf-8"></script>
<script src="js/jquery-1.7.2.min.js" type="text/javascript" ></script>
<script src="images/facebox.js" type="text/javascript"></script>
<script type="text/javascript">
   jQuery(document).ready(function($){
    jQuery.facebox.settings.opacity = 0.0
      jQuery('a[rel*=facebox]').facebox({
		 
      })
	
 })
</script>
<link href="custom-scrollbar-plugin/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css" />
<?php
include('dbconnect.php');
?>
<link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css" />
<br /> <tr id="n" align="center" >
                  <th><div class="L" style="height:40px;"  ><a class="btn" style="text-decoration:none;" href="../home.php">BACK HOME</a></th><br />
          <th><div class="L" style="height:40px;"  ><a class="btn" rel="facebox" style="text-decoration:none;" href="addterm.php">ADD TERM</a><div style="margin-left:790px;margin-top:-30px"><form id="contactForm"><input  type="text" PlaceHolder="Search a Term."  height="50px" name="filter" value="" class="ed" id="filter" style="background-color:#FFF;width:300px" /><img  src="images/1266929716_Find.png" style="width:25px;height:25px;margin-left:-30px;margin-top:3px;position:absolute" /></form></div></div></th> 
    
		    <table  class="table table-striped table-bordered table-condensed" id="L" style="font-size:14px; text-indent:0px;" width="700px" cellpadding="0" cellspacing="0" id="resultTable">
          <thead>
            <tr>
    				  <th>Name</th> <th>Description</th> <th>Edit</th> <th>Delete</th>
            </tr>
          </thead>
          <tbody>
              <?php

              $sql = "SELECT * from cai_glossary ORDER BY name ASC" ;
              $i=0;
              //echo $sql . "<br />";
              $select = mysql_query($sql);

              while($row3 = mysql_fetch_assoc($select))
              {
              	if($row3 >=0){
                  echo "<tr>";
                
              	echo "<td> " . $row3['name'] . "</td>";
              	echo "<td> " . $row3['discription'] . "</td>";
              	
              	echo "<td> " . '<a   rel="facebox" href=./edit.php?id=' . $row3["g_id"] . '>' . '<img src="./images/edit.png" width="25" height="25" border="0" title="edit" />' . '</a>' . "</td>";
              	?> <td> <a id="link" rel="facebox" href=delete.php?id=<?php echo $row3["g_id"]  ?> ><img src="./images/trash.png" width="25" height="25" border="0" title="delete" /></a></td> <?php
                  echo "</tr>";
              	++$i; }
              	else if($row3 <=0) {
              		echo 'No Room ';
              		}
              }
              ?>
            </tr>
          </tbody>
        </table>  
