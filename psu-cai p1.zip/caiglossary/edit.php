
<html>
<head>


<link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css" />

<!--sa input that accept number only-->
<script>



function keyTrapping(myfield, event){

	var key;
	var keychar;
	var characterIndex=0;
	if (window.event)
   		key = window.event.keyCode;
	else if (event)
   		key = event.which;
	else
   		return true;
	
	keychar = String.fromCharCode(key);
	// control keys
	if ((key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) )
   		return true;
	//selected character only
	else if ((("abcdefghijklmnopqrstuvwxyz").indexOf(keychar) > -1))
   		return true;
	
   		
	else 

   		return false;	 
   		
	


	}
	
	
</script>
<?php
	
	echo '<form id="contactForm" action="editexecute.php" method="post">';

	echo '<br>';

			include_once './dbconnect.php'; 
		
			$id=$_GET['id'];
			$result = mysql_query("SELECT * FROM cai_glossary WHERE g_id = $id");

			while($row = mysql_fetch_array($result))
  			{
				
				
				
				?>
   </head>
   <body>
<div style="width:570px; height:330px;color: #090; background-color:#FFF; margin-top:-18px;">
<div class="add"><br>
           &nbsp;&nbsp;&nbsp;Edit Term
</div><br>
<input type="hidden" class="ed" name="g_id" value="<?php echo $row['g_id']?>;" ?>
 
  <input name="name" placeholder="New Term" required  title="*New Term" type="text" class="ed" value="<?php echo $row['name']; ?>" onKeyPress="return keyTrapping(this,event);" /><br />
<textarea name="description"  placeholder="New Description" required  title= "*New Description" class="ed" style=" font-size:18px; width:500px; height:120px; margin-left:60px;margin-bottom:20px;" > <?php echo $row['discription']; ?></textarea>
 

   <div class="add"> <input class="btn btn-add" type="submit" name="Submit"  value="save"  />
 
</form></div></div>
</body>
</html><?php  }?>