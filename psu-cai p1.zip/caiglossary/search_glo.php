<?php
include('dbconnect.php');
?>

<?php


if(isset($_POST))
{

$q=$_POST['searchword'];
if($q!=""){
$sql_res=mysql_query("select * from cai_glossary where name like '%$q%' order by g_id LIMIT 5");
while($row=mysql_fetch_array($sql_res))
{
$name=$row['name'];
$discription=$row['discription'];

$re_name='<b>'.$q.'</b>';
$re_discription='<b>'.$q.'</b>';

$final_name = str_ireplace($q, $re_name, $name);

$final_discription = str_ireplace($q, $re_discription, $discription);


?>
<div class="display_box" align="left" style="color:#1E1E1E"  >

<!--<img src="user_img/<?php// echo $image; ?>" style="width:25px; float:left; margin-right:6px" /> --><?php echo $final_name; ?>&nbsp;<?php //echo $final_discription; ?><br/>
<span style="font-size:13px; color:#444;"><?php echo $final_discription; ?></span></div>



<?php
}
}
}
else 
	

	
	

{

}


?>
