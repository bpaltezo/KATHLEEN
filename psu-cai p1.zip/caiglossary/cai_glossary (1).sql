-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 01, 2012 at 05:45 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ite-elect2`
--

-- --------------------------------------------------------

--
-- Table structure for table `cai_glossary`
--
-- Creation: Sep 29, 2012 at 06:26 AM
-- Last update: Sep 29, 2012 at 08:25 AM
--

DROP TABLE IF EXISTS `cai_glossary`;
CREATE TABLE IF NOT EXISTS `cai_glossary` (
  `g_id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `discription` text NOT NULL,
  PRIMARY KEY (`g_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=191 ;

--
-- Dumping data for table `cai_glossary`
--

INSERT INTO `cai_glossary` (`g_id`, `keyword`, `name`, `discription`) VALUES
(83, 'A', 'Accounting software system', 'an application software that records and processes accounting transactions within functional modules such as accounts payable, accounts receivable, payroll, and trial balance. '),
(84, 'A', 'Arbitration', 'it is a resolution technique in which a third party reviews the evidence in the case and imposes a decision that is legally binding for both sides and enforceable.'),
(85, 'B', 'Behavioral Segmentation ', 'consumers are divided into groups according to their knowledge of, attitude towards, use of or response to a product. It is actually based on the behavior of the consumer.'),
(86, 'B', 'Branding', 'bonding of the partners and marking of a submissive.'),
(87, 'B', 'Breach of Contract', 'is a legal cause of action in which a binding agreement is not honored by one or more of the parties to the contract by non-performance or interference with the other party''s performance.'),
(88, 'B', 'Burn rate', ' (negative cash flow) it is a measure for how fast a company will use up its shareholder capital. If the shareholder capital is exhausted, the company will either have to start making a profit, find a'),
(89, 'C', 'Catastrophe', 'is an extremely large-scale horrible event.'),
(90, 'C', 'Chamber of commerce', '(also referred to in some circles as a board of trade)- is a form of business network, e.g., a local organization of businesses whose goal is to further the interests of businesses.'),
(91, 'C', 'Collateral ', 'it is a way to secure repayment of a loan.'),
(92, 'C', 'Commercial fleet ', 'is a collection of ships or vehicles that may use as transportation of promotion for the business.'),
(93, 'C', 'Commercial loan', 'is a loan to a business rather than a loan to an individual consumer.'),
(94, 'C', 'Competitor analysis', 'in marketing and strategic management is an assessment of the strengths and weaknesses of current and potential competitors. This analysis provides both an offensive and defensive strategic context to'),
(95, 'C', 'Conformance', 'is how well something, such as a product that meets a specified standard.'),
(96, 'C', 'Cost-plus pricing ', 'is a pricing method used by companies to maximize their profits.'),
(97, 'C', 'Credit squeeze or Credit crisis ', '- is a reduction in the general availability of loans (or credit) or a sudden tightening of the conditions required to obtain a loan from the banks.'),
(98, 'C', 'Cycle (Business)', 'economy-wide fluctuations in production or economic activity over several months or years.'),
(99, 'D', 'Demographic segmentation ', 'consists of dividing the market into groups based on variables such as age, gender, family size, income, occupation, education, religion, race and nationality.'),
(100, 'D', 'Depreciation ', 'is the decrease in value of assets. '),
(101, 'D', 'Diversification', 'involves spreading investments. Diversification (marketing strategy) is a corporate strategy to increase market penetration.'),
(102, 'E', 'Employee stock ownership plan ', 'is a defined contribution plan that provides a company''s workers with an ownership interest in the company.'),
(103, 'F', 'Fiscal year/Fiscal quarter', 'is the reporting periods for firms and other agencies.'),
(104, 'G', 'Geographic segmentation', 'The market is segmented according to geographic criteriaâ€”nations, states, regions, countries, cities, neighborhoods, or zip codes. Geo-cluster approach combines demographic data with geographic data'),
(105, 'G', 'Green Entrepreneurship ', 'refers to the act of being an entrepreneur that depends on environmental criteria for the planned use of funds.'),
(106, 'I', 'Income tax ', 'is a tax levied on the income of individuals or businesses (corporations or other legal entities).'),
(107, 'I', 'Initial public offering ', 'is a type of public offering where shares of stock in a company are sold to the general public. Through this process, a private company transforms into a public company.'),
(108, 'L', 'Lead time', 'is the delay between the initiation and execution of a process. '),
(109, 'L', 'Lease ', 'is a contractual arrangement calling for the lessee (user) to pay the (owner) for use of an asset.'),
(110, 'M', 'Management buyout ', 'is a form of acquisition where a company''s existing managers acquire a large part or all of the company from either the parent company or from the private owners.'),
(111, 'M', 'Market segmentation ', 'is a marketing strategy that involves dividing a broad target market into subsets of consumers who have common needs and applications for the relevant goods and services.'),
(112, 'M', 'Markup ', 'is the difference between the cost of a good or service and its selling price. A markup is added on to the total cost incurred by the producer of a good or service in order to create a profit'),
(113, 'P', 'Personal loans ', 'these loans are often used by borrowers for small purchases such as computers, home improvements, vacations or unexpected expenses.'),
(114, 'P', 'Pilferage ', 'is the theft of part of the contents of a package. It may also include theft of the contents but leaving the package, perhaps resealed with bogus contents. '),
(115, 'P', 'Procurement ', 'is the acquisition of goods or services. It is favorable that the goods/services are appropriate and that they are procured at the best possible cost to meet the needs of the purchaser in terms of qua'),
(116, 'P', 'Psycho-graphic Segmentation ', 'consumers are divided according to their lifestyle, personality, values. Aliens within the same demographic group can exhibit very different psychographic profiles.'),
(117, 'R', 'Royalties ', '(sometimes, running royalties, or private sector taxes) are usage-based payments made by one party to another for the right to ongoing use of an asset, sometimes an intellectual property (IP).'),
(118, 'S', 'Scorecard ', 'is a strategic performance management tool - a semi-standard structured report, supported by proven design methods and automation tools that can be used by managers to keep track of the execution of a'),
(119, 'T', 'Trade Association ', 'is also known as an industry trade group, business association or sector association, is an organization founded and funded by businesses that operate in a specific industry. '),
(120, 'T', 'Trade-off (or tradeoff) ', 'is a situation that involves losing one quality or aspect of something in return for gaining another quality or aspect. It often implies a decision to be made with full comprehension of both the upsid'),
(121, 'U', 'Unique Selling Proposition ', 'is a marketing concept that was first proposed as a theory to understand a pattern among successful advertising campaigns of the early 1940s. It states that such campaigns made unique propositions to '),
(122, 'V', 'Venture philanthropy ', 'takes concepts and techniques from venture capital fund that makes money by owning equity in the companies it invests in, and high technology business management and applies them to achieving philanth'),
(123, 'W', 'Warranty ', 'is an assurance by one party to the other party that specific facts or conditions are true or will happen; the other party is permitted to rely on that assurance and seek some type of remedy if it is '),
(124, 'A', 'Angel investors', 'Individuals who have capital that they are willing to risk. Angels are often successful entrepreneurs who invest in emerging entrepreneurial ventures, often as a bridge from the self-funded stage to t'),
(125, 'A', 'Assets', ' Items of value owned by a company and shown on the balance sheet, including cash, equipment, inventory, etc.'),
(126, 'B', 'Balance sheet', 'Summary statement of a company''s financial position at a given point in time, listing assets as well as liabilities.'),
(127, 'B', 'Breakeven point', 'Dollar value of sales that will cover, but not exceed, all of the company''s costs, both fixed and variable.'),
(128, 'B', 'Bridge finance', 'Short-term finance that is expected to be repaid quickly.'),
(129, 'B', 'Browser', 'A computer program that enables users to access and navigate the World Wide Web.'),
(130, 'B', 'Business incubator', 'This is a form of mentoring in which workspace, coaching, and support services are provided to entrepreneurs and early-stage businesses at a free or reduced cost.'),
(131, 'B', 'Business plan', 'A written document detailing a proposed venture, covering current status, expected needs, and projected results for the enterprise. It contains a thorough analysis of the product or service being offe'),
(132, 'C', 'Capital', 'Cash or goods used to generate income. For entrepreneurs, capital often refers to the funds and other assets invested in the business venture.'),
(133, 'C', 'Cash flow', 'The difference between the company''s cash receipts and its cash payments in a given period. It refers to the amount of money actually available to make purchases and pay current bills and obligations.'),
(134, 'C', 'Cash flow statement', 'A summary of a company''s cash flow over a period of time.'),
(135, 'C', 'Copyright', 'Copyright is a form of legal protection for published and unpublished literary, scientific, and artistic works that have been fixed in a tangible or material form. It grants exclusive rights to the wo'),
(136, 'C', 'Corporation', 'A business form that is an entity legally separate from its owners. Its important features include limited liability, easy transfer of ownership, and unlimited life.'),
(137, 'E', 'E-commerce', 'The sale of products and services over the Internet.'),
(138, 'E', 'Entrepreneur', 'A person who organizes, operates, and assumes the risk for a business venture.'),
(139, 'E', 'Equity', 'An ownership interest in a business.'),
(140, 'H', 'Home-based business', ' A business, of any size or type, whose primary office is in the owner''s home.'),
(141, 'I', 'Income statement', 'Also known as a "profit and loss statement," it shows a firm''s income and expenses, and the resulting profit or loss over a specified period of time.'),
(142, 'I', 'Intangible assets', 'Items of value that have no tangible physical properties, such as ideas.'),
(143, 'I', 'Inventory', 'Finished goods, work in process of manufacture, and raw materials owned by a company.'),
(144, 'J', 'Joint venture', 'A legal entity created by two or more businesses joining together to conduct a specific business enterprise with both parties sharing profits and losses.'),
(145, 'L', 'Liabilities', 'Debts a business owes, including accounts payable, taxes, bank loans, and other obligations. Short-term liabilities are due within a year, while long-term liabilities are due in a period of time great'),
(146, 'L', 'Limited partnership', 'A business arrangement in which the day-to-day operations are controlled by one or more general partners and funded by limited or silent partners who are legally responsible for losses based on the am'),
(147, 'L', 'Line of credit', '(1) An arrangement between a bank and a customer specifying the maximum amount of unsecured debt the customer can owe the bank at a given point in time. (2) A limit set by a seller on the amount that '),
(148, 'L', 'Liquidity', 'The ability of an asset to be converted to cash as quickly as possible and without any price discount.'),
(149, 'M', 'Marketing', 'The process of researching, promoting, selling, and distributing a product or service. Marketing covers a broad range of practices, including advertising, publicity, promotion, pricing, and packaging.'),
(150, 'M', 'Marketing plan', 'A document describing a firm''s potential customers and a comprehensive strategy to sell them goods and services'),
(151, 'N', 'Niche marketing', 'Identifying and targeting markets not adequately served by competitors.'),
(152, 'O', 'Outsourcing', 'The practice of using subcontractors or other businesses, rather than paid employees, for standard services such as accounting, payroll, information technology, advertising, etc.'),
(153, 'P', 'Partnership', 'Legal form of business in which two or more persons are co-owners, sharing profits and losses. . Patent: A property right granted to an inventor to exclude others from making, using, offering for sale'),
(154, 'S', 'Seed financing', 'A relatively small amount of money provided to prove a concept; it may involve product development and market research.'),
(155, 'S', 'Social entrepreneur', 'Someone who recognizes a social problem and uses entrepreneurial principles to organize, create, and manage a venture to make social change. Social entrepreneurs often work through non-profit organiza'),
(156, 'T', 'Trademark', 'A form of legal protection given to a business or individual for words, names, symbols, sounds, or colors that distinguish goods and services. Trademarks, unlike patents, can be renewed forever as lon'),
(157, 'A', 'Accountant', ' A person who carries out bookkeeping, auditing, and other financial reporting and analysis. This is a generic term referring to a wide range of skills from semi-clerical to highly trained professional'),
(158, 'A', 'Accounts payable', 'The outstanding bills of an enterprise; money owed to suppliers for goods and services purchased for the normal operations of the venture. Accounts payable are included on the balance sheet under curr'),
(159, 'A', 'Accounts receivable', 'he money that is owed to a venture for goods and services that have been purchased from it or that have been committed as a grant or donation. Accounts receivable are included on the balance sheet und'),
(160, 'B', 'Business', 'The production of goods or services for profit. Such activity can be carried out by an individual, a family, a partnership, or an incorporated company.'),
(161, 'C', 'Calculated risk', 'A risk that has been given thoughtful consideration and for which the potential costs and potential benefits have been weighted and considered.'),
(162, 'C', 'Capitalist', 'A person who owns shares in a business enterprise.'),
(163, 'C', 'Competition', 'A market in which rival sellers are trying to gain extra business at one another''s expense and thus are forced both to be as efficient as possible and to hold their prices down as much as possible. Co'),
(164, 'D', 'Demand', 'The combined desire, ability and willingness on the part of individuals to acquire or make use of a good or service. Demand is determined by income and by price, which is, in part, determined by suppl'),
(165, 'E', 'Economic growth', 'The increase over a period of time in the production of goods and services and the capacity to produce goods and services. Economic growth is usually measured as the percentage increase in gross natio'),
(166, 'E', 'Efficiency', 'The most effective use or allocation of resources to yield the maximum benefits. Efficiency in one sense â€” the effective use of resources â€” is often applied to individual firms in comparing how we'),
(167, 'G', 'Groupthink', 'The forces that tend to suppress or resist divergent thinking when a group is working to accomplish a specific task within a limited period of time.'),
(168, 'I', 'Idea', '(for entrepreneurship) A new, creative approach to specifically addressing a perceived opportunity (a need, want, problem or challenge).'),
(169, 'I', 'Innovation', 'The use of a new technology, item, or process to change what goods and services are provided, the way they are produced, or the way they are distributed.'),
(170, 'I', 'Interest', 'The cost incurred in borrowing and using someone else''s money or, alternatively, the income earned by allowing others to use your money.'),
(171, 'I', 'Intrapreneurship', 'The application of entrepreneurial skills and approaches within or by a corporation.'),
(172, 'I', 'Invention', 'The creation of a new technology, item, or process, as opposed to its application in widespread use.'),
(173, 'I', 'Investment', ' 1. As used in economics, spending on capital goods such as factories, mines, and machinery so as to increase the productive capacity of the economy. 2. In its broader meaning, investment is any purch'),
(174, 'I', 'Investment capital', '(start-up) Initial investment capital necessary for starting a business usually consisting of inventory, equipment, pre-opening expenses, and leaseholds.'),
(175, 'M', 'Market', '1. The place where buyers and sellers meet to exchange goods for money or for other goods at a price that is arrived at through an implied auction in which buyers and sellers negotiate price. 2. The d'),
(176, 'M', 'Market economy', 'An economy in which the setting of prices and allocating of resources are determined largely by the forces of supply and demand.'),
(177, 'M', 'Marketing strategy', ' Marketing starts with market research, in which needs and attitudes and competitors'' products are assessed, and continues through into advertising, promotion, distribution, and, where applicable, cus'),
(178, 'O', 'Opportunity', '(for entrepreneurship) A need, want, problem, or challenge that can potentially be addressed by an entrepreneurial idea and an entrepreneurial venture.'),
(179, 'O', 'Opportunity cost', 'The loss of the next best alternative whenever a decision is made involving two or more options.'),
(180, 'P', 'Patent', 'The legal right to ownership of an invention issued, in Canada, under the Patent Act. By granting this right to inventors, society hopes to encourage invention and innovation and, thus, to benefit fro'),
(181, 'P', 'Productivity', 'The output of goods and services in the economy or in an industry from the effective use of various inputs (such as skilled workers, capital equipment, managerial know-how, technological innovation, a'),
(182, 'P', 'Profit', 'What is left over for the owner(s) of a business after all expenses have been deducted from the revenues of a firm. Gross profit is the profit before corporate income taxes. Net profit is the final pr'),
(183, 'R', 'Resources', 'The raw materials, supplies, capital equipment, factories, offices, labour, management, and entrepreneurial skills that are used in producing goods and services.'),
(184, 'R', 'Revenue', 'The total income a business firm or government receives from all sources.'),
(185, 'R', 'Risk', 'The likelihood of undesirable, unforeseen, or uncontrollable events occurring.'),
(186, 'S', 'Strategic plan', 'A forward-looking plan that aims to map out the means to achieve longer-term goals and to plan a response to unforeseen problems and opportunities.\r\n'),
(187, 'V', 'Venture', 'Any initiative that entails the mobilization of resources to establish a good, service, program, and so forth to address needs, wants, problems, and challenges.'),
(188, 'V', 'Venture planning ', 'A comprehensive written summary drawn up to establish the viability and direction of a contemplated venture. It includes how the entrepreneur intends to organize resources to attain established goals.'),
(189, 'W', 'Working capital', 'The funds available for carrying on the activities of a business after an allowance is made for bills that have to be paid within the year. Working capital is calculated by deducting the current liabi'),
(190, 'z', 'zzzz', ' person who carries out bookkeeping, auditing, and other financial reporting and analysis. This is a generic term referring to a wide range of skills from semi-clerical to highly trained professional	');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
