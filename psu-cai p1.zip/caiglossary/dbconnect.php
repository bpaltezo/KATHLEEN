<?php
$db_name = "cai_it4";
$db_server = "localhost";
$db_user = "root";
$db_pass = "23rencomaj3s";
$bd = mysql_connect($db_server, $db_user, $db_pass) or die("Could not connect database");
mysql_select_db($db_name, $bd) or die("Could not select database");
?>