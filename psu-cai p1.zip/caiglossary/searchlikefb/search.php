<?php include_once '../dbconnect.php'; ?>

<?php



if($_POST)
{

$q=$_POST['searchword'];

$sql_res=mysql_query("select * from cai_glossary where name like '%$q%'  order by g_id LIMIT 5");
while($row=mysql_fetch_array($sql_res))
{
$name=$row['name'];
$discription=$row['discription'];

$re_name='<li style="color:yellow"><b >'.$q.'</b></li>';
$re_discription='<b>'.$q.'</b>';

$final_name = str_ireplace($q, $re_name, $name);

$final_discription = str_ireplace($q, $re_discription, $discription);


?>
<div class="display_box"  align="left" style="color:#FF0">
<?php echo $final_name; ?>&nbsp;<br/>
<span style="font-size:16px; color:#FFF"><?php echo $final_discription; ?></span></div>



<?php
}

}
else

{

}


?>
