<link href="images/facebox.css" media="screen" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="jquery.watermarkinput.js"></script> 
<script type="text/javascript">
$(document).ready(function(){

$(".search").keyup(function() 
{
var searchbox = $(this).val();
var dataString = 'searchword='+ searchbox;

if(searchbox=='')
{
}
else
{

$.ajax({
type: "POST",
url: "search.php",
data: dataString,
cache: false,
success: function(html)
{

$("#display").html(html).show();
	
	
	}




});
}return false;    


});
});

jQuery(function($){
   $("#searchbox").Watermark("Search");
   });
</script>
<style type="text/css">
body
{
font-family:"Lucida Sans";

}
*
{
margin:0px
}
#searchbox
{
width:250px;
border:solid 1px #000;
padding:3px;
background-image:url(search.jpg);
	background-position:right;
	background-repeat:no-repeat;
}
#display
{
width:600px;
display:none;

float:right; margin-right:0px;
border-left:solid 1px #dedede;
border-right:solid 1px #dedede;
border-bottom:solid 1px #dedede;
overflow:hidden;
}
.display_box
{
padding:4px; border-top:solid 1px #dedede; font-size:12px; height:30px;
background-color:#090; 
}

.display_box:hover
{
background:#3b5998;
color:#FFFFFF;
}
#shade
{
background-color:#00CCFF;

}


</style>
<script src="js/jquery-1.2.6.min.js" type="text/javascript"></script>
<script src="images/facebox.js" type="text/javascript"></script> 
<script type="text/javascript">
   jQuery(document).ready(function($){
    $.facebox.settings.opacity = 0.0
      $('a[rel*=facebox]').facebox({
		 
      })
	
 })
</script>


<script language="Javascript">

$(document).ready(function() {
    $.facebox.settings.opacity = 0.0
});

</script> 
<?php

$db_name = "glossary";
$db_server = "localhost";
$db_user = "root";
$db_pass = "";

//$mysqli = new MySQLi($db_server, $db_user, $db_pass, $db_name) or die(mysqli_error());
$bd = mysql_connect($db_server, $db_user, $db_password) or die("Could not connect database");
mysql_select_db($db_name, $bd) or die("Could not select database");


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div style="width:200px; height:30px; margin-left:300px">
<input style="margin-right:0px" type="text" class="search" id="searchbox"  /><br /></div>
</div>
<div style="width:850px; height:600px; ">

<div style="width:840px; background-image:url(header_bg.png); height:30px; border:1px solid; color:#FFF; font-weight:bold font-size:16px; -webkit-border-top-left-radius: 10px;-webkit-border-bottom-left-radius: 0px;
	 -webkit-border-top-right-radius: 10px;-webkit-border-bottom-right-radius: 0px; ">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold font-weight:bold" rel='fancybox' href=./index.php?Keyword=a>a</a>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=b>b</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=c>c</a>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=d>d</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=e>e</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=f>f</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=g>g</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=h>h</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=i>i</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=j>j</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=k>k</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=l>l</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=m>m</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=n>n</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=o>o</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=p>p</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=q>q</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=r>r</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=s>s</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=t>t</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=u>u</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=v>v</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=w>w</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=x>x</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold"rel='fancybox' href=./index.php?Keyword=y>y</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a style="color:#FFF; font-weight:bold" rel='fancybox' href=./index.php?Keyword=z>z</a>
</div>
<div style="width:150px; height:580px;  margin-left:0px; margin-top:3px; border:1px solid; color:#090;background-image:url(bg.jpg); font-size:20px;">

<div style="width:140px; height:580px;  margin-left:0px; margin-top:3px; border:1px solid; background-color:#000; margin-left:4px; color:#090;background-image:url(bg.jpg); font-size:20px; overflow:auto;">

<br />

 <?php  
		$id=$_GET['Keyword'];
		 ?>
<?php $sql = "SELECT name from cai_glossary where keyword='$id' " ;

//echo $sql . "<br />";
$select = mysql_query($sql);

while($row = mysql_fetch_assoc($select))
{
		if($row >=1){
    echo "<tr>";
  
	echo "<td><a style='color:#FFF; font-weight:bold' id='link' rel='facebox'  href=./discription.php?disc=" . $row['name'] . "> " . $row['name']. "</a></td><br>";
	
    echo "</tr>";
  
 
}
else  {
			echo "<td><a style='color:#FFF' id='link' rel='facebox' href=./discription.php?id='" ."nono". "</a></td>";
		}}
?>

</div><a  id="link" rel="facebox"  href=epditpic.php?id=' . $_SESSION['user_id'] . '>
<div style="width:645px; height:580px;  margin-left:155px; margin-top:-582px; border:0px solid; color:#090"><div style="margin-left:355px">

<div id="display" style="margin-right:0px" >
</div>
 
</div>
<div>
</div>
</body>
</html>