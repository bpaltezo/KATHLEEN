<?php
		include_once './dbconnect.php'; 
		$id = $_POST['num'];
		mysql_query("DELETE FROM cai_glossary WHERE g_id='$id'");
		header("location:view.php");
		exit();
?>