<?php session_start();?> 

<?php include('../header.php') ?>
<script type="text/javascript">
$(document).ready(function(){

$(".search").keyup(function() 
{
var searchbox = $(this).val();
var dataString = 'searchword='+ searchbox;

if(dataString!='')
{

$.ajax({
type: "POST",
url: "search.php",

data: dataString,
cache: false,
success: function(html)
{

$("#display").html(html).show();
	
	
	}




});
}
else{
	$("#display").html(html).hide();	
}return false;    


});
});

jQuery(function($){
   $("#searchbox").Watermark("Search a Term.");
   });
</script>
<!--CUSTom SCROll -->

<style type="text/css">
	<!--
		
		
	</style>
	<!-- Custom scrollbars CSS -->
	<link href="custom-scrollbar-plugin/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css" />
<!-- mousewheel plugin -->
	<script src="custom-scrollbar-plugin/jquery.mousewheel.min.js"></script>
    <script src="./jquery/jquery.min.js"></script>
	<script>!window.jQuery && document.write(unescape('%3Cscript src="jquery/jquery-1.7.2.min.js"%3E%3C/script%3E'))</script>
	<script src="./jquery/jquery-ui.min.js"></script>
	<script>!window.jQuery.ui && document.write(unescape('%3Cscript src="jquery/jquery-ui-1.8.21.custom.min.js"%3E%3C/script%3E'))</script>
	<!-- custom scrollbars plugin -->
	<script src="custom-scrollbar-plugin/jquery.mCustomScrollbar.js"></script>
	
<!--End scroll -->
<!-- <script src="js/jquery-1.2.6.min.js" type="text/javascript"></script>-->
<script src="images/facebox.js" type="text/javascript"></script> 


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

<link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css" />
<style type="text/css">
      	body 
{
margin: 0;
padding: 0;
color: #000000;
font-family: Tahoma, Geneva, sans-serif;
font-size: 13px;
line-height: 1.5em;
background-color: #E0E0E0;
background-repeat: repeat-x;
background-position: top;
background-image: url(images/0.jpg);
}
    	</style>
</head>

<body>
<?php error_reporting(0);?>
<?php $id=$_GET['Keyword'];?>
<div style="width:850px; height:600px; margin-top:20px ">
<div class="gloss-header" style="width:840px; height:35px; font-weight:bold font-size:16px;  ">
<ul>
<li <?php if($id=='a'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold font-weight:bold" rel='fancybox' href=./index.php?Keyword=a>A</a></li>


<li <?php if($id=='b'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold;"rel='fancybox' href=./index.php?Keyword=b>B</a></li>
<li <?php if($id=='c'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=c>C</a></li>

<li <?php if($id=='d'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=d>D</a></li>
<li <?php if($id=='e'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=e>E</a></li>
<li <?php if($id=='f'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=f>F</a></li>
<li <?php if($id=='g'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=g>G</a></li>
<li <?php if($id=='h'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=h>H</a></li>
<li <?php if($id=='i'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=i>I</a></li>
<li <?php if($id=='j'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=j>J</a></li>
<li <?php if($id=='k'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=k>K</a></li>
<li <?php if($id=='l'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=l>L</a></li>
<li <?php if($id=='m'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=m>M</a></li>
<li <?php if($id=='n'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=n>N</a></li>
<li <?php if($id=='o'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=o>O</a></li>
<li <?php if($id=='p'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=p>P</a></li>
<li <?php if($id=='q'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=q>Q</a></li>
<li <?php if($id=='r'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=r>R</a></li>
<li <?php if($id=='s'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=s>S</a></li>
<li <?php if($id=='t'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=t>T</a></li>
<li <?php if($id=='u'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=u>U</a></li>
<li <?php if($id=='v'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=v>V</a></li>
<li <?php if($id=='w'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=w>W</a></li>
<li <?php if($id=='x'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=x>X</a></li>
<li <?php if($id=='y'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold"rel='fancybox' href=./index.php?Keyword=y>Y</a></li>
<li <?php if($id=='z'){echo 'class="selected"';} ?>><a style="color:#08C; font-weight:bold" rel='fancybox' href=./index.php?Keyword=z>Z</a></li>

<li><a style="color:#08C; font-weight:bold" href=../home.php><b>HOME</b></a></li>
</ul>
</div>
<div style="width:225px; height:580px;  margin-left:0px; margin-top:3px; background:#fff; color:#090; font-size:20px;">

<div id="content_1" style="width:200px; height:540px;  margin-left:0px; margin-top:3px;  margin-left:4px; color:#090; 
  font-size:20px; overflow:auto; padding-left: 15px; border:1px solid E5E5E5;">
<!--background-image:url(bg.jpg); -->
<br />
 <?php  
 		
			$id=$_GET['Keyword'];
        if($id=='')
	{
		

	$id='a';
	
	 $sql = "SELECT g_id,name from cai_glossary order by name " ;



//echo $sql . "<br />";
$select = mysql_query($sql);

while($row = mysql_fetch_assoc($select))
{
		if($row >=1){
    echo "<tr>";
  
	echo "<td class='s'><a  style='color:#333;  font-size:13px; margin-top:10px; text-decoration:none;' id='link' rel='facebox'  href=./discription.php?disc=" . $row['g_id'] . "> " . $row['name']. "</a></td><br><br>";
	
    echo "</tr>";
  
 
}}
	
	
	
	
	
	
	
	}else{
          ?>
         
<?php $sql = "SELECT g_id,name from cai_glossary where keyword='$id' " ;



//echo $sql . "<br />";
$select = mysql_query($sql);

while($row = mysql_fetch_assoc($select))
{
		if($row >=1){
    echo "<tr>";
  
	echo "<td ><div class='s'><a style='color:#333; text-decoration:none; font-size:13px; margin-top:10px;' id='link' rel='facebox'  href=./discription.php?disc=" . $row['g_id'] . "></div> " . $row['name']. "</a></td><br><br>";
	
    echo "</tr>";
  
 
}
else  {
			echo "<td><a style='color:#333;  text-decoration:none;'; id='link' rel='facebox' href=./discription.php?id='" ."nono". "</a></td>";
		}}}
	
?>

</div></div>

<div style="width:600px; height:180px;position:fixed;  margin-left:240px; margin-top:-580px; border:0px solid; color:#333"><div >
<div style="width:200px; height:30px; margin:20px 250px 10px; float:right;">
<form id="contactForm"><input type="text" class="search search-query" id="searchbox" Placeholder="Search a Term." style="margin-right:0px; background-color:#FFF;color:#333;"  /></form><br /></div>
</div>
<div id="display" style="margin-right:-0px;" >
</div>
 
</div>
<div>
</div>
<script type="text/javascript">
   jQuery(document).ready(function($){
    $.facebox.settings.opacity = 0.0
      $('a[rel*=facebox]').facebox({
		 
      })
	
 })
</script>
<script>
		(function($){
			$(window).load(function(){
				$("#content_1").mCustomScrollbar({
					scrollButtons:{
						enable:true
					}
				});
			});
		})(jQuery);
	</script>
	      <script>
      $(document).ready(function() {
      $('body').hide().fadeIn(800);
 
      }); // end ready
    </script>
