-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 17, 2012 at 08:13 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `glossary`
--

-- --------------------------------------------------------

--
-- Table structure for table `cai_glossary`
--

CREATE TABLE IF NOT EXISTS `cai_glossary` (
  `g_id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `discription` varchar(200) NOT NULL,
  PRIMARY KEY (`g_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `cai_glossary`
--

INSERT INTO `cai_glossary` (`g_id`, `keyword`, `name`, `discription`) VALUES
(73, 'f', 'fafaf', 'fafaf'),
(69, 'a', 'aaa', 'aaa'),
(70, 'a', 'ar', 'aew'),
(63, 'a', 'a', 'aaa'),
(71, 's', 'sas', 'sa'),
(72, 'f', 'faf', 'afa'),
(67, 'a', 'asa', 'as'),
(68, 'a', 'asas', 'asa'),
(79, 'b', 'bgfdvs', 'vdsv'),
(80, 'v', 'vdsv', 'dsvdsv'),
(81, 'a', 'aaaaa', ' asssssssssss'),
(78, 'c', 'cv', 'vdsv'),
(75, 'r', 'r rar', 'rar'),
(76, 'a', 'ang bata', 'hahah'),
(77, 'd', 'dasd', 'dsd');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
