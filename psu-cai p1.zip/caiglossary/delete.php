<style type="text/css">

#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid; margin-left:22px; margin-top:10px;
border-width:thin;
border-color:#090;width:80px;
padding:5px; font-size:16px; color:#090;
height: 34px; 
}


</style>
			<?php
				  if (isset($_GET['id']))
	{
			 $messages_id = $_GET['id'];
		echo '<div style="width:500px; height:160px; color:#333; margin-top:0px; font-weight:bold; background-color:#f5f5f5; text-indent:30px">';?>
			<br/><form action="deleteexecute.php" method="post" > <?php
			echo '<input name="num" type="hidden" value="'. $messages_id . '" />';
			echo 'Are you sure you want to delete this Term ? ';
			echo '<br>';echo '<br>';
			echo '<div style="width:498px; height:60px; color:#333; font-weight:bold;background:#111;margin-top:38px; border:1px solid;border-color:#111; margin-right:-20px ">';
			
			echo ' <input class="btn btn-add" type="submit" value="Ok" />';
			echo '</form>';
		
	}	echo '</div>';echo '</div>';
			
			?>
			