
<html>
<head>
<link href="css/mystyle.css" media="screen" rel="stylesheet" type="text/css" />


<!--sa input that accept number only-->
<script>



function keyTrapping(myfield, event){

	var key;
	var keychar;
	var characterIndex=0;
	if (window.event)
   		key = window.event.keyCode;
	else if (event)
   		key = event.which;
	else
   		return true;
	
	keychar = String.fromCharCode(key);
	// control keys
	if ((key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27) )
   		return true;
	//selected character only
	else if ((("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ - _").indexOf(keychar) > -1))
   		return true;
	
   		
	else 

   		return false;	 
   		
	


	}
	
	
</script>
   </head>
   <body style="margin-left:100px;">
<div style="width:570px; height:335px;color: #090; background-color:#FFF;">
<div class="add" style=""><br>
&nbsp;&nbsp;&nbsp;&nbsp;Add Term
</div><br/>
<form id="contactForm" action="./addexecute.php" method="post" enctype="multipart/form-data" name="addroom" onSubmit="return validateForm()">
 
  <input name="name" style="height: 32px;" placeholder="Term Name" required  title="Please Enter Term" type="text" class="ed" onKeyPress="return keyTrapping(this,event);" /><br />
	<textarea name="description" class="ed" placeholder="Term Description" required  title= "*Please Enter Description" style=" font-size:18px;  height:120px; margin-left:60px;margin-bottom:20px;"></textarea>
   <div class="add"> <input  class="btn btn-add" type="submit" name="Submit"  value="save"  /></div>
 
</form></div>
</body>
</html>