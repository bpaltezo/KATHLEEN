<?php

include_once './dbconnect.php'; 
$g_id =mysql_real_escape_string($_POST['g_id']);
$name=mysql_real_escape_string($_POST['name']);
$a=$name;
$description=mysql_real_escape_string($_POST['description']);
/*$sql = mysql_query("SELECT g_id FROM cai_glossary WHERE name='$name' LIMIT 1");
	$samecontact = mysql_num_rows($sql); // count the output amount
    if ($samecontact > 0) {
		
echo  "<script language='JavaScript'>alert('Sorry you try to duplicate $name in the database. Please Input  another.'),window.location.href='view.php'; return false;</script>";
		
		exit();
		
	}
	else {*/

mysql_query("UPDATE cai_glossary SET keyword='$a', name='$name', discription='$description'  WHERE g_id='$g_id'");
header("location: view.php");
mysql_close($con);//}
?> 