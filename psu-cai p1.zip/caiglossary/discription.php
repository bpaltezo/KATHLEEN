<?php

include_once './dbconnect.php'; 
?>
<style>
#a{ background-color:#403696;}
#as{ text-indent:130px; margin-top:10px;  }
</style>
<?php  
		$disc=$_GET['disc'];
		 ?>
<?php /* $sql2 = "SELECT discription from cai_glossary where name=$disc " ;

//echo $sql . "<br />";
$select2 = mysql_query($sql2);

while($row2 = mysql_fetch_assoc($select2))
{
	echo  $row2['discription'];
  
 
}
*/


$sql =" SELECT * from cai_glossary where g_id='$disc' " ;


$select = mysql_query($sql);

while($row3 = mysql_fetch_assoc($select))
{
	
    echo "<div style='width:580px;height:auto; border:none;'><tr>";
  echo "<div style='width:580px;height:50px;  background:#111; color:white;text-indent:20px; font-size:20px;border-bottom: 1px solid #ddd;padding-top:10px'>";
	echo "<td vertical_align=\"center\"> " . $row3['name']. "</td></div>";
	echo "<div style='padding: 20px; background-color:white; height:120px'><td >&nbsp;&nbsp;&nbsp; " .'<b style="color:#333"></b>'. $row3['discription']. "</td><div>";
	
}
?>





