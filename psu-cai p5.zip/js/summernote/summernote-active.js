

$('#summernote1').summernote({
		height: 300,
		toolbar: [
         ["insert", ["pitcure", "link", "math"]],
     	]
	});