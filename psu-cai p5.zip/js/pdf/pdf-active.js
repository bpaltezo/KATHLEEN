(function ($) {
 "use strict";

		$('a.media').media({width:800, height:950});
		 
 
})(jQuery); 