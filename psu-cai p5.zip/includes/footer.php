 <hr />

    <div id="footer">
       <div class="container_12 clearfix">
      <div class="grid_12">
      <footer>
       <p>&copy;&nbsp;DNSC 2012 Computer Aided Instruction. All rights reserved. | <a href="copyright.php">Copyright</a> | <a href="terms.php">Terms and Conditions</a> | <a href="privacy.php">Privacy Policy</a> | <a href="about.php">About Us</a> </p>
      </footer>
   </div><!-- end grid -->
    </div>
    </div>

      <script src="javascripts/bootstrap-transition.js"></script>
      <script src="javascripts/bootstrap-alert.js"></script>
      <script src="javascripts/bootstrap-modal.js"></script>
      <script src="javascripts/bootstrap-dropdown.js"></script>
      <script src="javascripts/bootstrap-scrollspy.js"></script>
      <script src="javascripts/bootstrap-tab.js"></script>
      <script src="javascripts/bootstrap-tooltip.js"></script>
      <script src="javascripts/bootstrap-popover.js"></script>
      <script src="javascripts/bootstrap-button.js"></script>
      <script src="javascripts/bootstrap-collapse.js"></script>
      <script src="javascripts/bootstrap-carousel.js"></script>
      <script src="javascripts/bootstrap-typeahead.js"></script>
 <?php
	// 5. Close connection
	mysql_close($connection);
  exit;
?>
