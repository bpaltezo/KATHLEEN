<?php

function UploadImage($image, $send, $id){

		$currentDir = getcwd();

		$errors = array();
		$result = array();

		$fileExtensions = array('jpeg','jpg','png');

		$filename = $image['name'];
		$filesize = $image['size'];
		$fileTmpName = $image['tmp_name'];
		$fileType = $image['type'];
		$temp = explode('.', $filename);
		$fileExtension = strtolower(end($temp));

		$uploadPath = $currentDir."/uploads/".basename($id.".".$fileExtension);

		if($send){

			if(!in_array($fileExtension, $fileExtensions)){
				$errors[] = "The image file extension is not allowed. Please upload a JPEG or PNG file";
			}

			if($filesize > 50000000){	//50mb
				$errors[] = "Thie image file is more than 2MB. Sorry it has to be less than or equal to 50MB";
			}

			if(empty($errors)){

				$didupload = move_uploaded_file($fileTmpName, $uploadPath);

				if($didupload){
					//echo "uploaded!";
					//return true;
					$result[] = $id.".".$fileExtension;
					$result[] = $uploadPath;
					return $result;

				}else{
					//echo "An error occured.";
					return false;
				}

			}else{

				$result[0] = false;

				foreach ($errors as $error) {
					$result[1][] = $error;
				}

				return $result;

			}
		}
	}
?>