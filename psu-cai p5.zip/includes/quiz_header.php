<!DOCTYPE html>
<html lang="en">
  <head>

    <?php
include("session/DBConnection.php");
$user = $_SESSION['log']['username'];
      $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
      $display = mysql_fetch_array($query); 
      $type = $display['type'];
      $name = $display['firstname'];
      $lastname = $display['lastname'];
      $pix = $display['image'];
?>
<title>CAI - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  
<link rel="shortcut icon" HREF="images/dnsc_logo.png" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
    	<meta name="description" content="">
    	<meta name="author" content="">
		<link href="style.css" rel="stylesheet" type="text/css" />
<link href="home.css" rel="stylesheet" type="text/css" />
		<link href="bootstrap/assets/css/bootstrap.css" rel="stylesheet" />
        <style type="text/css">
      	body 
{
margin: 0;
padding: 0;
color: #000000;
font-family: Tahoma, Geneva, sans-serif;
font-size: 13px;
line-height: 1.5em;
background-color: #E0E0E0;
background-repeat: repeat-x;
background-position: top;
background-image: url(images/0.jpg);
}
    	</style>
    	<link href="bootstrap/assets/css/bootstrap-responsive.css" rel="stylesheet" />
      <link rel="apple-touch-icon-precomposed" sizes="114x114" href="bootstrap/assets/ico/apple-touch-icon-114-precomposed.png">
    	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="bootstrap/assets/ico/apple-touch-icon-72-precomposed.png">
    	<link rel="apple-touch-icon-precomposed" href="bootstrap/assets/ico/apple-touch-icon-57-precomposed.png">

      <script src="javascripts/jquery.js"></script>
		<script>
			$(document).ready(function() {
 			$('body').hide().fadeIn(800);
 
			}); // end ready
		</script>
	</head>
<body>
		 <div class="navbar navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container-fluid">
          <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </a>
          <a class="brand" href="index.php"></i>CAI-IT4</a>
          <div class="nav-collapse">
            <ul class="nav">
              <li class="active"><a href="home.php"><i class="icon-home icon-white"></i>Home</a></li>
              <li class=""><a href="profile.php"><i class="icon-info-sign icon-white"></i>Profile</a></li>
              <li class=""><a href="friends.php"><i class="icon-user icon-white"></i>Friends
                <?php
  $user = $_SESSION['log']['username'];
$result = mysql_query("SELECT * FROM friends WHERE friend = '" . $user ."' and status = 'requesting'");
  
  $numberOfRows = MYSQL_NUMROWS($result);  
        if ($numberOfRows > 0 )
          echo '<font size="2" color="red">' . $numberOfRows .'</font>' ;
        else
           echo " ";  
        ?></a></li>
              <li class=""><a href="mail.php"><i class="icon-list icon-white"></i>Messages  <?php
$user = $_SESSION['log']['username'];
$status = 'unread';
$result = mysql_query("SELECT * FROM messages WHERE recipient='" . $user."' AND status='$status'");
  
  $numberOfRows = MYSQL_NUMROWS($result); 
  if($numberOfRows > 0){
  echo '<font size="1" color="red"><b>' . $numberOfRows .'</b></font>';} 
  ?>
                </a> </li>
              <li class="divider-vertical"></li>
              <li class="">&nbsp; &nbsp;</li>
        
               <li class=""><a href="content.php"><i class="icon-book icon-white"></i>Quiz</a></li>
              
              <?php if($type== 'Student'){ ?>

<?php  

    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
              $result = mysql_fetch_array($query);  
              $key=$result['group_key'];

   $query = mysql_query("SELECT * FROM groups WHERE group_key='$key'") or die (mysql_error()); 
              $result = mysql_fetch_array($query); 
              $keys=$result['group_key']; 
              $id=$result['group_id'];      
?>
<?php if($key== $keys&& $key!=null){ 
?>

<li class=""><a href="group_page.php?groupid=<?php echo $id;?>"><i class="icon-star icon-white"></i>Groups</a></li>
    <?php } else { ?>

<li class=""><a href="groups.php"><i class="icon-star icon-white"></i>Groups</a></li>

<?php }?>


<?php } else  {?>

<li class=""><a href="groups.php"><i class="icon-star icon-white"></i>Groups</a></li>
<?php }
?>
	      <li class=""><a href="grade.php"><i class="icon-pencil icon-white"></i>My Grades </a>
            </ul>
              <?php 
                  if(!isset($_SESSION['log']['username'])){
                    echo "<p class=\"navbar-text pull-right\">";
                    echo "Not logged in";
                    echo "</p>";
                  }
                  else{
                  echo "<ul class=\"nav pull-right\">
                  <li id=\"fat-menu\" class=\"dropdown\">
                  <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">Logged in as  $type <b class=\"caret\"></b></a>
                  <ul class=\"dropdown-menu\">
                  <li><a href=\"profile.php\"> $name <img class='grid_4 alpha blog_img framed' style='width:40px; height:40px;' SRC = '$pix' /></a></li>
                  <li class=\"divider\"></li>
                  <li><a href=\"setting.php\">Account Settings</a></li>
                  <li class=\"divider\"></li>
                  <li><a href=\"logout.php\">Logout</a></li>
                  </ul>
                  </li>
                  </ul>";     
                  }  
              ?>  
          </div><!--/.nav-collapse -->
        </div>
      </div>
    </div>
