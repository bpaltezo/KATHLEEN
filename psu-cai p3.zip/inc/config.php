<?php

$DB_['USER'] = 'root';
$DB_['PASS'] = '';
$DB_['HOST'] = 'localhost';
$DB_['NAME'] = 'cai_it4';
?>
