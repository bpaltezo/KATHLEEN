<?php
	function get_role($user_id){
		global $connection;

		$query = "SELECT type from users where user_id='$user_id'";
		$result = mysql_query($query,$connection);
		confirm_query($result);
		while($row = mysql_fetch_array($result)){ 
			$type = $row['type'];
		}
		return $type;
	}

	function get_score_ratings($score , $item_limit){
		$rate = ($score / $item_limit) * 100;
		return (int) $rate;
	}

	function get_chart_ratingsM($PassedM , $score_rating){

		if($PassedM==0&& $score_rating == 0){

			echo '<center><h1 style = "color:red;">Not yet taken by  the students</h1></center>';
		}
else
		$chart = ($PassedM / $score_rating) * 100;
		return (int)  $chart;


	}

function get_chart_ratingsF($PassedF , $score_rating){

	if($PassedF==0 && $score_rating == 0){

echo '<center><h1 style = "color:red;">Not yet taken by  the students</h1></center>';
	}
	else

		$chart = ($PassedF / $score_rating) * 100;
		return (int)  $chart;


	}


	function count_question_by_quiz_id($quiz_id){
		global $connection;

		$query = "SELECT count(questions_question) as items from questions where quiz_id = '$quiz_id'";
		$result = mysql_query($query,$connection);
		confirm_query($result);
		while($row = mysql_fetch_array($result)){ 
			$items = $row['items'];
		}
		return $items;
	}
	function get_the_title_by_id($id){
		global $connection;
		$query = "SELECT quiz_title from quiz where quiz_id = '$id'";
		$result = mysql_query($query,$connection);
		confirm_query($result);
		while($row = mysql_fetch_array($result)){ 
			$title = $row['quiz_title'];
		}
		return $title;
	}

	function get_quiz_desc_by_title($title){
		global $connection;
		$query = "SELECT quiz_description from quiz where quiz_title = '$title'";
		$result = mysql_query($query,$connection);
		confirm_query($result);
		$desc = "";
		while($row = mysql_fetch_array($result)){ 
			$desc = $row['quiz_description'];
		}
		return $desc;
	}
	function get_quiz_time_limit_by_id($id){
		global $connection;
		$query = "SELECT quiz_timelimit from quiz where quiz_id= '$id'";
		$result = mysql_query($query,$connection);
		confirm_query($result);
		while($row = mysql_fetch_array($result)){ 
			$limit = $row['quiz_timelimit'];
		}
		return $limit;
	}

function get_quiz_item_limit_by_id($id){
		global $connection;
		$query = "SELECT item_student from quiz where quiz_id= '$id'";
		$result = mysql_query($query,$connection);
		confirm_query($result);
		while($row = mysql_fetch_array($result)){ 
			$item_limit = $row['item_student'];
		}
		return $item_limit;
	}
	function get_quiz_id_by_title($title){
		global $connection;
		$query = "SELECT quiz_id from quiz where quiz_title = '$title'";
		$result = mysql_query($query,$connection);
		confirm_query($result);
		$quiz_id = "";
		while($row = mysql_fetch_array($result)){ 
			$quiz_id = $row['quiz_id'];
		}
		return $quiz_id;
	}

	function get_question_id_by_question($question){
		global $connection;
		$query = "SELECT questions_id from questions where questions_question = '$question'";
		$result = mysql_query($query,$connection);
		confirm_query($result);
		while($row = mysql_fetch_array($result)){ 
			$question_id = $row['questions_id'];
		}
		return $question_id;
	}
	function get_question_attr_by_id($id){
		global $connection;
		$query = "SELECT * from questions where questions_id = '$id'";
		$result = mysql_query($query,$connection);
		confirm_query($result);
		while($row = mysql_fetch_array($result)){ 
			$quiz_id = $row['quiz_id'];
			$question = $row['questions_question'];
			$type = $row['questions_type'];
		}
		return $questions_attr = array($quiz_id , $question , $type);

	}
	function get_answer_attr_by_quest_id($id){
		global $connection;
		$query = "SELECT * from answers where questions_id = '$id'";
		$result = mysql_query($query,$connection);
		confirm_query($result);
		while($row = mysql_fetch_array($result)){ 
			$answer_id = $row['answer_id'];
			$answer = $row['answer'];
			$correct = $row['correct'];
		}
		return $answer_attr = array($answer_id , $answer , $correct);

	}
	function redirect_to( $location = NULL ) {
		if ($location != NULL) {
			header("Location: {$location}");
			exit;
		}
	}
	function confirm_query($result_set) {
		if (!$result_set) {
			die("Database query failed: " . mysql_error());
		}
	}
	
	function mysql_prep( $value ) {
		$magic_quotes_active = get_magic_quotes_gpc();
		$new_enough_php = function_exists( "mysql_real_escape_string" ); // i.e. PHP >= v4.3.0
		if( $new_enough_php ) { // PHP v4.3.0 or higher
			// undo any magic quote effects so mysql_real_escape_string can do the work
			if( $magic_quotes_active ) { $value = stripslashes( $value ); }
			$value = mysql_real_escape_string( $value );
		} else { // before PHP v4.3.0
			// if magic quotes aren't already on then add slashes manually
			if( !$magic_quotes_active ) { $value = addslashes( $value ); }
			// if magic quotes are active, then the slashes already exist
		}
		return $value;
	}
		
	function destroy_session(){
	$_SESSION = array();
	if(isset($_COOKIE[session_name()])){
		setcookie(session_name(), '',time()-42000, '/');
	}
	session_destroy();
	}
	
	function getExtension($str) {
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
 }
	
function uploader(){
		
error_reporting(0);
$change="";
$abc="";


 define ("MAX_SIZE","400");
 $errors=0;
  
 if($_SERVER["REQUEST_METHOD"] == "POST")
 {
 	$image =$_FILES["file"]["name"];
	$uploadedfile = $_FILES['file']['tmp_name'];
     
 
 	if ($image) 
 	{
 	
 		$filename = stripslashes($_FILES['file']['name']);
 	
  		$extension = getExtension($filename);
 		$extension = strtolower($extension);
		
		
 if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) 
 		{
		
 			$change='<div class="msgdiv">Unknown Image extension </div> ';
 			$errors=1;
 		}
 		else
 		{

 $size=filesize($_FILES['file']['tmp_name']);


if ($size > MAX_SIZE*1024)
{
	$change='<div class="msgdiv">You have exceeded the size limit!</div> ';
	$errors=1;
}


if($extension=="jpg" || $extension=="jpeg" )
{
$uploadedfile = $_FILES['file']['tmp_name'];
$src = imagecreatefromjpeg($uploadedfile);

}
else if($extension=="png")
{
$uploadedfile = $_FILES['file']['tmp_name'];
$src = imagecreatefrompng($uploadedfile);

}
else 
{
$src = imagecreatefromgif($uploadedfile);
}
list($width,$height)=getimagesize($uploadedfile);


$newwidth=500;
$newheight=($height/$width)*$newwidth;
$tmp=imagecreatetruecolor($newwidth,$newheight);


$newwidth1=135;
$newheight1=($height/$width)*$newwidth1;
$tmp1=imagecreatetruecolor($newwidth1,$newheight1);

imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);

imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);


$filename = "uploads/" . "500x500 - " . $_FILES['file']['name'];
$filename1 = "uploads/" . "135x135 - " . $_FILES['file']['name'];


imagejpeg($tmp,$filename,100);
imagejpeg($tmp1,$filename1,100);

imagedestroy($src);
imagedestroy($tmp);
imagedestroy($tmp1);
}}

}
if(isset($_POST['pro_submit']) && !$errors) 
 {
 
   // mysql_query("update {$prefix}users set img='$big',img_small='$small' where user_id='$user'");
 	$change=' <div class="msgdiv">Image Uploaded Successfully!</div>';
 }
return $array = array($filename,$filename1);
}



?>