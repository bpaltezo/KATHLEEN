Thank you for your interest in contributing to this library!

## Using the issue tracker

The issue tracker on GitHub is the preferred channel for bug reports, feature requests, and discussions.

## Pull requests

**Please do not commit changes in `build` folder.**

**Please do not commit changes in `package.json` and `yarn.lock` files if is not related to the pull request changes.**
