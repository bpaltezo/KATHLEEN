<?php
	session_start();

?>
<!DOCTYPE html>
<html>
<head>
<?php
	
    include("session/DBConnection.php");	
	$user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";
?>
	<title>References - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>

	<?php require_once("includes/session.php"); ?>
	<?php require_once("includes/connection.php"); ?>
	<?php require_once("includes/functions.php"); ?>
	<?php include "links.php"; ?>
	<link href="js/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
    <link href="js/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

<?php

    if(isset($_POST['add'])){

        $name = $_POST['name'];
        $def = $_POST['def'];

        $sql = "INSERT INTO cai_glossary (name, discription) VALUES ('$name', '$def')";
        $res = $conn->query($sql);

    }

?>

</head>
<body>

<?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
	<?php include "header.php"; ?>

	<div class="breadcome-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="breadcome-list single-page-breadcome">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"></div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <ul class="breadcome-menu">
                                    <li><a href="#">Home</a> <span class="bread-slash">/</span></li>
                                    <li><span class="bread-blod">References</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="container-fluid">
    <div class="panel-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="text-center">References</h3>
                    </div>
                </div>
                <br>
                <table width="100%" class="table table-striped table-bordered table-hover" id="mytable">
                    <thead>
                        <tr>
                            <td><b>Term</b></td>
                            <td><b>Definition</b></td>
                        </tr>
                    </thead>
                    <tbody style="font-size:10pt;">
                        <?php
                            $sql = "SELECT * FROM cai_glossary ORDER BY name ASC";
                            $res = $conn->query($sql);

                            while($row = $res->fetch_assoc()){
                                echo "<tr>";
                                echo "<td>".ucfirst($row['name'])."</td>";
                                echo "<td>".ucfirst($row['discription'])."</td>";
                                echo "</tr>";
                            }

                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<br>
<?php
    
    if($type != "Student"){
        echo '<div class="container-fluid">
    <div class="panel-body">
        <h4>Add Reference</h4>
        <br>
        <div class="row">
            <div class="col-lg-1"></div>
            <form method="post" action="glossary.php">
            <div class="col-lg-8">
                <div class="form-group">
                    <label>Term</label>
                    <input type="text" name="name" class="form-control">
                </div>
                <div class="form-group">
                    <label>Definition</label>
                    <textarea name="def" class="form-control"></textarea>
                </div>
                <input type="hidden" name="add" value="1">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>';
    }

?>

    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script src="js/data-table/bootstrap-table.js"></script>
    <script src="js/data-table/tableExport.js"></script>
    <script src="js/data-table/data-table-active.js"></script>
    <script src="js/data-table/bootstrap-table-editable.js"></script>
    <script src="js/data-table/bootstrap-editable.js"></script>
    <script src="js/data-table/bootstrap-table-resizable.js"></script>
    <script src="js/data-table/colResizable-1.5.source.js"></script>
    <script src="js/data-table/bootstrap-table-export.js"></script>
 	<script src="js/editable/jquery.mockjax.js"></script>
    <script src="js/editable/mock-active.js"></script>
    <script src="js/editable/select2.js"></script>
    <script src="js/editable/moment.min.js"></script>
    <script src="js/editable/bootstrap-datetimepicker.js"></script>
    <script src="js/editable/bootstrap-editable.js"></script>
    <script src="js/editable/xediable-active.js"></script>
	<script src="js/editable/xediable-active.js"></script>
    <script src="js/datatables/js/jquery.dataTables.min.js"></script>
    <script src="js/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="js/datatables-responsive/dataTables.responsive.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#mytable').DataTable({
                responsive: true
            });
        });
    </script>

</body>
</html>