<?php

	$conn = mysqli_connect("localhost", "root", "", "cai_it4");

	$sql = "UPDATE members SET image = '' WHERE member_id=".$_GET['id'];
	$res = $conn->query($sql);

	if($res){
		echo "success";
		header("Location: profile.php");
	}

?>