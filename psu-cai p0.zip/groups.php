<?php session_start();?>
<?php ob_start(); ?>

<!DOCTYPE html>
<html>
<head>
	
	<?php
		
		include("session/DBConnection.php");	
		$user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";

?>

<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php require_once("includes/functions.php"); ?>

<?php

	if(isset($_POST['addgroup'])){

		$user = $_SESSION['log']['username'];
		$gname = $_POST['gname'];
		$key = $_POST['gkey'];
		$fac_name = $name." ".$lastname;
		$sql = "INSERT INTO groups (group_key, group_name, group_day, image, created_date, faculty_name) VALUES ('$key', '$gname', '', 'uploads/Gimage.jpg', '', '$fac_name')";
		$sql2 = "UPDATE members SET group_key='$key' WHERE username = '$user' ";
		$res = $conn->query($sql);
		$res2 = $conn->query($sql2);
	 
    if($res && $res2) header("Location: groups.php");

  }

?>


	<title>Groups - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

	<?php include "links.php"; ?>

</head>
<body>

<?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include("header.php"); ?>

<div class="login-form-area edu-pd mg-b-15">
  <div class="container-fluid">

    <div class="breadcome-area">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="breadcome-list single-page-breadcome">
              <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <div class="breadcome-heading">
                    <form role="search" class="sr-input-func">
                      <input type="text" placeholder="Search..." class="search-int form-control">
                      <a href="#"><i class="fa fa-search"></i></a>
                    </form>
                  </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <ul class="breadcome-menu">
                    <li><a href="#">Home</a> <span class="bread-slash">/</span></li>
                    <li><span class="bread-blod">Groups</span></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<?php if($type == "Faculty") include "parts/group_faculty.php"; ?>
<?php if($type == "Student") include "parts/group_student.php"; ?>

<?php include("footer.php"); ?>
