<?php

include "includes/connection.php";

$id = $_POST['id'];
$firstname = $_POST['fn'];
$lastname = $_POST['ln'];
$address = $_POST['address'];
$bdate = $_POST['bdate'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$gender = $_POST['gender'];
$civil = $_POST['civil'];

$sql = "UPDATE members SET firstname='$firstname', lastname='$lastname', address='$address', birthdate='$bdate', email='$email', contact_no='$contact', gender='$gender', relationship='$civil' WHERE member_id='$id' ";
$res = $conn->query($sql);

if($res){
	header("Location: profile.php");
}else{
	echo "err";
}

?>