<?php ob_start(); session_start(); ?>

<?php

  require_once("session/DBConnection.php");

  $conn = mysqli_connect("localhost", "root", "", "cai_it4");

  if(isset($_POST['login'])){

    $username = $_POST['username'];
    $password = $_POST['password'];
  
    $sql = "SELECT * FROM members WHERE username='$username' AND password='$password'";
    $res = $conn->query($sql);
    
    $found = false;

    while($row = $res->fetch_assoc()){

      if($row['confirmation'] == 0){
        echo '<script>
            window.onload = function(){
              $(".infomodalBtn").click();
            }
            </script>';
      }else{

        session_register('is');
        $_SESSION['log']['login'] = TRUE;
        $_SESSION['log']['username'] = $_POST['username'];
        $_SESSION['badge'] = "";
        $session = "1"; 
        
        $query = mysql_query("SELECT * FROM members WHERE username = '$username'") or die (mysql_error()); 
        $display = mysql_fetch_array($query);
        $memberid = $display['member_id'];
        $image = $display['image'];
        $type = $display['type'];
        $faculty = $display['instructor'];
        $key = $display['group_key'];
        $insert = "INSERT INTO users SET username = '$username', password = '$password', usertype = '$type', session_id= '', created_date = CURRENT_TIMESTAMP, modified_date = '0000-00-00 00:00:00', image = '$image', faculty_name='$faculty', group_key = '$key'";
        $add_member = mysql_query($insert);

        date_default_timezone_set("Asia/Manila");

        $timein = date("h:i:s a");
        $datein = date("M d");
        
        $type= $display['type'];
        if ($type=="Admin"){
          header("location: admin");
        }else{

          $sql = "INSERT INTO logs SET memberid='$memberid', timein='$timein', datein='$datein', gkey='$key' ";
          $res = mysql_query($sql);

          header("location:home.php");
        }

        //echo "Logged in!";
      
      }

      $found = true;
    }

    if(!$found){

      echo '<script>
        window.onload = function(){
          $(".failedmodalBtn").click();
        }
      </script>';
    }
    
  }

?>

<!DOCTYPE html>
<html>
<head>

	<title>Login | Computer Aided Instruction System for Discrete Structures of Pangasinan State University - Lingeyen Campus</title>  

  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="fonts/fa/css/all.css">
  <link rel="stylesheet" type="text/css" href="fonts/googlefonts.css">
  <script type="text/javascript" src="fonts/fa/js/all.js"></script>
  <link rel="stylesheet" href="css/owl.carousel.css">
  <link rel="stylesheet" href="css/owl.theme.css">
  <link rel="stylesheet" href="css/owl.transitions.css">
  <link rel="stylesheet" href="css/animate.css">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/meanmenu.min.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/educate-custon-icon.css">
  <link rel="stylesheet" href="css/morrisjs/morris.css">
  <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
  <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
  <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
  <link rel="stylesheet" href="css/calendar/fullcalendar.min.css">
  <link rel="stylesheet" href="css/calendar/fullcalendar.print.min.css">
  <link rel="stylesheet" href="css/modals.css">
  <link rel="stylesheet" href="css/form/all-type-forms.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="css/responsive.css">
  <script src="js/vendor/modernizr-2.8.3.min.js"></script>
  <style type="text/css">
    body{
      background: url("images/slider2.jpg");
      background-size:cover;
      background-repeat: no-repeat;
      background-position: right;
    }
    .title{
      text-align:center;
      font-family:'Open Sans';
    }
    .main-title{
      font-size:17pt;
      color:teal;
    }
    .sub-title{
      font-size: 10pt;
      color: #223345;
    }
  </style>

</head>
<body class="">

<div class="container-fluid">
  <br><br><br><br><br><br><br><br><br>
  <div class="row">
    <div class="col-lg-3"></div>
    <div class="col-lg-6 col-md-8 col-sm-6 col-xs-12" style="background: transparent;">
      <div class="sparkline8-list mt-b-30">
        <div class="sparkline8-hd">
          <div class="mybanne">
            <img src="images/logo.png" width="90" height="90" style="float: left;">
            <h4 class="title">
              <span style="font-weight: normal;">Welcome to</span><br><br>
              <span class="main-title">COMPUTER AIDED INSTRUCTION SYSTEM</span><br>
              <span class="sub-title">FOR DISCRETE MATHEMATICS</span>
            </h4>
          </div>
        </div>
        <br><br>
        <div class="sparkline8-graph">
          <div class="basic-login-form-ad">
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <br><br><br>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3"></div>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="basic-login-inner">
                  <h4 class="text-center">Login Now</h4>
                  <br>    
                  <form action="login2.php" method="post">
                    <input type="text" name="login" style="display: none;">
                    <div class="form-group-inner">
                      
                      <input type="text" class="form-control" placeholder="Username" name="username" required autocomplete="off">
                    </div>
                    <div class="form-group-inner">
                      
                      <input type="password" class="form-control" placeholder="Password" name="password" required autocomplete="off">
                    </div>
                    <div class="login-btn-inner">
                      <div class="inline-remember-me">
                        <button class="btn btn-sm btn-primary pull-right login-submit-cs" type="submit">
                          Log In
                        </button>
                      </div>
                    </div>
                  </form>
                
                </div>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-3"></div>
  </div>
</div>

<div id="zoomInDown1" class="modal modal-edu-general modal-zoomInDown fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-close-area modal-close-df">
        <a class="close" data-dismiss="modal" href="#">&times;</a>
      </div>
      <div class="modal-body">
        <div class="modal-login-form-inner">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="login-social-inner modalContent">
                <br>
                <h3 class="text-center">Register as</h3>
                <br>
                <div class="col-lg-6">
                  <a href="student_reg.php" style="color: skyblue;">
                    <button class="form-control btn-info"><i class="fas fa-user-circle"></i> Student</button>
                  </a>
                </div>
                <div class="col-lg-6">
                  <a href="instruc_reg.php" style="color: green;">
                    <button class="form-control btn-success"><i class="fas fa-chalkboard-teacher"></i> Faculty
                    </button>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="basic-login-inner modal-basic-inner">
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<a data-toggle="modal" data-target="#failedmodal" class="failedmodalBtn" style="display: none;"></a>
<div id="failedmodal" class="modal modal-edu-general FullColor-popup-DangerModal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header header-color-modal bg-color-4">
        <h4 class="modal-title"></h4>
        <div class="modal-close-area modal-close-df">
          
        </div>
      </div>
      <div class="modal-body">
        <span class="educate-icon educate-info modal-check-pro information-icon-pro"> </span>
        <h2>Login Failed!</h2>
        <p>The username or password you entered didn't match any accounts. Check your username and password and try again. </p>
      </div>
      <div class="modal-footer danger-md">
        <a data-dismiss="modal" href="#">Retry</a>
      </div>
    </div>
  </div>
</div>

<a data-toggle="modal" data-target="#infomodal" class="infomodalBtn" style="display: none;"></a>
<div id="infomodal" class="modal modal-edu-general FullColor-popup-PrimaryproModal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header header-color-modal bg-color-1">
        <h4 class="modal-title"></h4>
        <div class="modal-close-area modal-close-df">
          
        </div>
      </div>
      <div class="modal-body">
        <span class="educate-icon educate-info modal-check-pro information-icon-pro"> </span>
        <h3>Account subject for confirmation!</h3>
        <p>Please wait until the system administrator confirms your account registration.</p>
      </div>
      <div class="modal-footer primary-md">
        <a data-dismiss="modal" href="#">OK</a>
      </div>
    </div>
  </div>
</div>

    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery-price-slider.js"></script>
    <script src="js/jquery.meanmenu.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
    <script src="js/metisMenu/metisMenu.min.js"></script>
    <script src="js/metisMenu/metisMenu-active.js"></script>
    <script src="js/tab.js"></script>
    <script src="js/icheck/icheck.min.js"></script>
    <script src="js/icheck/icheck-active.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

</body>
</html>