<?php

    //GROUPS
    $sql = "SELECT * FROM groups WHERE group_key='$gkey' ";
    $res = $conn->query($sql);

    $gname = "";

    while($row = $res->fetch_assoc()){
        $gname = $row["group_name"];
    }

    $sql = "SELECT * FROM results WHERE group_name='$gname'";
    $res = $conn->query($sql);

    $passed = 0;
    $failed = 0;

    //RATINGS
    while($row = $res->fetch_assoc()){
        if($row["rating"] == "Passed") $passed++;
        else if($row["rating"] == "Failed") $failed++;  
    }

    //LESSONS
    $sql = "SELECT * FROM topics WHERE prof='$fullname' ";
    $res = $conn->query($sql);

    $lessonsList = "";
    while($row = $res->fetch_assoc()){
        
        //PASSING RATE PER LESSON
        $tid = $row['topic_id'];
        $sql2 = "SELECT * FROM quiz WHERE topic_id='$tid' AND faculty_name='$fullname' ";
        $res2 = $conn->query($sql2);

        $G = "";

        while($row2 = $res2->fetch_assoc()){

            $qid = $row2['quiz_id'];
            $sql3 = "SELECT * FROM grades WHERE quiz_id='$qid' ";
            $res3 = $conn->query($sql3);

            $g = 0;
            $gc = 0;
            while($row3 = $res3->fetch_assoc()){
                $g += $row3['grade'];
                $gc++;
            }
            if($g != 0) $G = $g / $gc;
        
        }
        //PASSING RATE PER LESSON

        $lessonsList .='<li>'.$row['topic_name'].' <span class="pull-right label-danger label-1 label">'.$G.'%</span></li>';

    }

    //GROUP LIST
    $sql = "SELECT * FROM members WHERE group_key = '$gkey' AND type='Student'";
    $res = $conn->query($sql);

    $groupList = "";
    while($row = $res->fetch_assoc()){
        $groupList .= '
        <div class="single-review-st-text">
            <img src="'.$row['image'].'" alt="Profile Image">
            <div class="review-ctn-hf">
                <h3>'.ucfirst($row['firstname']).' '.ucfirst($row['lastname']).'</h3>
                <p>'.$row['email'].'</p>
            </div>
            <div class="review-item-rating">
                <a href="message.php?compose&sendto='.$row['email'].'"><button class="btn btn-default"><i class="fas fa-envelope"></i> Message</button></a>
            </div>
        </div>';
    }




?>

<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="lessons.php">
            <div class="social-media-edu">
                <i class="fas fa-tasks fa-4x" style="color:#42f4df;"></i>
                <div class="social-edu-ctn">
                    <h3 style="color:cyan;">Printables</h3>
                    <p>Preview Lessons</p>
                </div>
            </div>
            </a>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="quiz.php">
            <div class="social-media-edu">
                <i class="fas fa-edit fa-4x" style="color:#6995f4;"></i>
                <div class="social-edu-ctn">
                    <h3 style="color:darkblue;">Quizes</h3>
                    <p>Manage your Quizes</p>
                </div>
            </div>
            </a>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="groups.php">
            <div class="social-media-edu">
                <i class="fas fa-users fa-4x" style="color:#ffae75;"></i>
                <div class="social-edu-ctn">
                    <h3 style="color:orange;">Groups</h3>
                    <p>Manage your Group</p>
                </div>
            </div>
            </a>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="profile.php">
            <div class="social-media-edu">
                <i class="fas fa-user-circle fa-4x" style="color:#b075ff;"></i>
                <div class="social-edu-ctn">
                    <h3 style="color:violet;">Profile</h3>
                    <p>Manage your Profile</p>
                </div>
            </div>
            </a>
        </div>
    </div>
</div>
</div>
<br>
<div class="row">
<div class="col-lg-12">
<div class="row">

<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
    <div class="charts-single-pro responsive-mg-b-30">
        <div class="alert-title">
            <h2>Demographics</h2>
        </div>
        <div id="pie-chart">
            <canvas id="mychart"></canvas>
        </div>
    </div>
</div>
<div class="col-lg-6">
    <div class="single-review-st-item res-mg-t-30 table-mg-t-pro-n">
        <div class="single-review-st-hd">
            <h2>Latest Updates</h2>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="single-review-st-item res-mg-t-30 table-mg-t-pro-n">
                    <?php echo loadUpdates($gkey); ?>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="single-review-st-item res-mg-t-30 table-mg-t-pro-n">
        <div class="single-review-st-hd">
            <h2>Your Group</h2>
        </div>
        <?php echo $groupList; ?>
    </div>
</div>

</div>

</div>
</div>

</div>

<?php

    $sql = "SELECT * FROM grades WHERE group_key='$gkey' ";
    $res = $conn->query($sql);

    $gradeData = array();
    $c = 0;
    $cc = 0;
    while($row = $res->fetch_assoc()){
        if($row['remarks'] == "Passed"){
            $gradeData[0] = $c += 1;
        }else if ($row['remarks'] == "Failed"){
            $gradeData[1] = $cc += 1;
        }else{
            $gradeData[0] = $c;
            $gradeData[1] = $cc;
        }
    }

?>

<script type="text/javascript">

  window.onload = function(){

    var ctx = document.getElementById("mychart");
    var piechart = new Chart(ctx, {
      type: 'pie',
      data: {
        labels: ["Passed", "Failed"],
        datasets: [{
          label: 'pie Chart',
                backgroundColor: [
            '#3399FF',
            '#FF3399',
            '#006DF0'
          ],
          data: <?php echo json_encode($gradeData); ?>
          }]
      },
      options: {
        responsive: true
      }
    });

  }

</script>