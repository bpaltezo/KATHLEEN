<?php

	session_start();
	if(!isset($_SESSION['log'])){
		header("Location: login2.php");
	}else{
		header("Location: home.php");
	}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

	<title>Computer Aided Instruction System for Pangasinan State University</title>
	<?php include "links.php"; ?>
	
</head>
<body>

	<?php include("header.php");?>

	<div id="content">
		<br>
		<div class="breadcome-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <img src="images/welcome-slider.jpg">
                    </div>
                </div>
            </div>
        </div>
        <br><br>
		<div class="breadcome-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                        <h3 class="border">Objectives</h3>
						<p align="justify">
						Develop students to become excellent programmers, system analyst, trainers, web designers, network administrators, software application users and other information technology-related <div id="bi" style="color: #000099;">Read More..</div><div align="justify" id="backin" style="display:none; margin-top: -16px;">work who will contribute to the country's development effort for information technology towards the 21st century. <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Produce competent committed graduates with the necessary knowledge, skills and values demanded of information technology profession and committed to its application for the service to the community</div></p>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                        <h3 class="border">Mission</h3>
						<p align="justify">
						Primarily cater to deserving clienteles particularly the underprivileged and the underserved.Develop the expertise of its personnel in their respective disciplines.<div id="mis" style="color: #000099;">Read More...</div>
						<div align="justify" id="mission" style="display:none; margin-top: -16px;">Endeavor to be a “replica” of industry in the pursuit of its functions in research, extension and production.Produce highly competent and versatile professionals, technologists, technicians, and workers who will take proactive leadership role in the different sectors of the society.</div></p>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                        <h3 class="border">Vision</h3>
						<p align="justify">
						A premier regional center for human resource development, technology generation and transfer, and technology commercialization in the various disciplines <div id="vis" style="color: #000099;">Read More...</div>
						<div align="justify" id="vision" style="display:none; margin-top: -16px;">mandated by the college charter with the aim in view of improving the quality of life of the people in Davao del Norte in particular and Region I in general.</div></p>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                        <h3 class="border">Goals</h3>
						<p align="justify">
						As a Premier Regional Center, the DNSC shall: (1) Vigorously pursue quality and relevant undergraduate programs equitably accessible to its clientele; (2) be an institution   <div id="man" style="color: #000099;">Read More...</div>
						<div align="justify" id="mandate" style="display:none; margin-top: -16px;">
						where workers/proffessionals in industry, teaching and other proffessions seek advanced studies to upgrade their competencies;(3) be an institution where appropriate technologies are continously generated, modified/improved and utilized by the indutry and the people; and (4) promote entrepreneurial development.</div></p>
                    </div>
                </div>
            </div>
        </div>



	  <div class="container_16 clearfix">

			

			<hr class="grid_16" />

			<div class="grid_11 suffix_1 clearfix">
				<h3>Latest Happenings </h3>
				<ul class="blog_brief">
					<li class="entry clearfix">
						<div class="blog_info">
							<span class="date">December 08, 2012</span>
							<span class="info"></span>
							<div class="clear"></div>
						</div>
						<a HREF="images/portfolio/dnsc.jpg" rel="prettyPhoto[gallery]">
							<img class="grid_4 alpha blog_img framed" SRC="images/portfolio/dnsc.jpg"/>
						</a>
						<div class="grid_7 omega">
							<h4> IIT Sports Fest 2011</h4>
							<p align="justify">
								This year's IIT Sports  Fest Meet was held last July 22, 2011, the Unit II which includes the combined force of Bachelor of Science in Secondary Education students was proclaimed as the overall champion.<div id="int" style="color: #000099;">Read More..</div><div align="justify" id="intrams" style="display:none; margin-top: -16px;">
	<br /><br />Last year, Unit III was the overall champion among the five units – Unit I (BEed), Unit II (BSed), Unit III (BSIT), Unit IV (AIT & BSHRM) and Unit V (BSIS & BSHRM). But now, they weren’t able to maintain their title.
	<br /><br />The Sports events started last September 05 and ended on September 07, while Literary-Musical events and Cheer Dance competition were held on the first day of Intramurals Meet and it was on last September 05, 2011.
	<br /><br />Unit III was the champion in Sports events, Unit II was declared as the overall champion in Literary-Musical events and Unit III was able to get the title as the champion in Cheer Dance completion.
	<br /><br />All the winners in different events and categories will serve as representative of Talisay Campus in the forthcoming Intercampus Meet here in CHMSC-Talisay also.			</div>				</p>
							
						</div>
					</li>
					<li class="entry clearfix">
						<div class="blog_info">
							<span class="date">July 22, 2011</span>
							<span class="info"></span>
							<div class="clear"></div>
						</div>
						<a HREF="images/portfolio/aquintance.jpg" rel="prettyPhoto[gallery]">
							<img class="grid_4 alpha blog_img framed" SRC="images/portfolio/aquintance.jpg"/>
						</a>
						<div class="grid_7 omega">
							<h4>BSIT Acquaintance Party 2011 </h4>
							<p align="justify">
								
	Black and White. – The motif and the color of dresses and suits that were wore by the students, faculty and staffs of ICT Department during the IS Acquaintance Day that was held at Business Inn Hotel, Bacolod City last night of August 12, 2011.<div id="ac" style="color: #000099;">Read More..</div><div align="justify" id="acq" style="display:none; margin-top: -16px;">
	<br /><br />This IS Acquaintance Day aimed to let every student and other members of ICT Department to make known with each other, to build a friendly feeling and goodwill among comrades and most especially to develop the term so called, “camaraderie”.
	<br /><br />All persons that gathered in the said place look elegant, handsome and beautiful in their semi-formal black and white attire.
	<br /><br />In this evening event, all students and including the ICT faculty and staffs enjoyed different kinds of fun activities and entertainment. This includes the MTV-Making contest, section presentation, search for the faces of the night and Mr. and Ms. IS 2011 and of course the two most important things in that night, the fine dining and the ball.
	<br /><br />BSIS 4B won in the MTV-Making contest with their piece “Marry Your Daughter”.  BSIS 3A shown a unique and entertaining number during the presentation and that’s enough reason for the win of their section. Xxxx of BSIS 2A and xxxx of BSIS 3A have choosen for the faces of the night. Eeeee of BSIS 3B and hhhhhh of BSIS 1A were pinned as Mr. and Ms. IS 2011.	</div>

							</p>
						
						</div>
					</li>
					<li class="entry clearfix">
						<div class="blog_info">
							<span class="date">January 22, 2012</span>
							<span class="info"></span>
							<div class="clear"></div>
						</div>
						<a HREF="images/portfolio/earthquakedrill.jpg" rel="prettyPhoto[gallery]">
							<img class="grid_4 alpha blog_img framed" SRC="images/portfolio/earthquakedrill.jpg"/>
						</a>
						<div class="grid_7 omega">
							<h4>Earthquake Drill</h4>
							<p align="justify">
								
	The Unit III inherits sovereignty and won the title as the champion in the cheer dance competition durin the CHMSC-Talisay Intramurals Meet, September 05, 2011.<div id="che" style="color: #000099;">Read More..</div><div align="justify" id="cheer" style="display:none; margin-top: -16px;">
	<br /><br />Five units which are composed of one to two courses from different departments and colleges in the school competed and showed their talents, skills and abilities in the said competition that was held at the CHMSC-Talisay Football field.
	<br /><br />Unit V managed to won the 2nd place in the competition in spite of, they lack cheer dancers and they have no time to practice and prepare.
	<br /><br />Unit IV which includeS the AIT AND BSHRM won the 3rd place in the said competition. They have shown a unique cheers and cheer dance during the contest. Also, Unit I and II landed 4TH and 5TH place in the competition.
	<br /><br />During the 2011 cheer dance competition, all units have shown their different and unique number. They all give a high-level performance resulting to a unusual excitement of the watchers.</div>

							</p>
						
						</div>
					</li>
				</ul><!-- end blog -->
			</div>

		  <!-- end sidebar, end grid -->
        </div>
		<!-- end container -->
	</div><!-- end content -->
	<!-- end footer -->





	<?php include("footer.php");?>
</body> 
</html>

	
    <script type="text/javascript">
		$(document).ready( function() {
	
			$("#bi").click( function() {
			$("#backin").fadeIn();
			$("#bi").fadeOut();
		});
	
		$("#mis").click( function() {
			$("#mission").fadeIn();
			$("#mis").fadeOut();
		});
	
		$("#vis").click( function() {
			$("#vision").fadeIn();
			$("#vis").fadeOut();
		});
	
		$("#man").click( function() {
			$("#mandate").fadeIn();
			$("#man").fadeOut();
		});	
	
		$("#int").click( function() {
			$("#intrams").fadeIn();
			$("#int").fadeOut();
		});	
	
		$("#che").click( function() {
			$("#cheer").fadeIn();
			$("#che").fadeOut();
		});	
	
		$("#ac").click( function() {
			$("#acq").fadeIn();
			$("#ac").fadeOut();
		});
	});

	</script>
	

	<script type="text/javascript">
		//Cycle
		$(document).ready(function() {
			if ($('#slides').length > 0) {
				$('#slides').cycle({ 
					fx: 'fade',
					speed: 750,
					timeout: 6000, 
					randomizeEffects: false, 
					pager:  '#slidepager',
					cleartypeNoBg: true
				});
			}
		});
		//END- Cycle

		//IE6 PNG Transparency Fix 
		$(document).ready(function(){ 
			$(document).pngFix(); 
		});
		//IE6 PNG Transparency Fix 

		//CUFON Font Replacement
		Cufon.replace('h1,h2,h3,h4,h5,h6');
		Cufon.replace('.logo', { color: '-linear-gradient(0.5=#FFF, 0.7=#DDD)' }); 
		//CUFON Font Replacement

		// DOM Ready
		$(function(){
			$('#slider').anythingSlider();
		});

	</script>
	
	<style>
	#slider { width: 900px; height: 390px; }
	
	</style>
	
	