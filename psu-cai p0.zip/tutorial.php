<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>

<?php

    include("session/DBConnection.php");
    require_once("includes/session.php"); 
    require_once("includes/connection.php");

    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $current_lesson = $display['current_lesson'];
    $current_quiz = $display['current_quiz'];
    $fullname = $name." ".$lastname;

    include "includes/functions.php";

    if($pix == ""){$pix = SetProfileByGender($display['gender']);}

?>

  <title>Admin - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

  <?php include "links.php"; ?>
  <style type="text/css">
     
    .thumbnail video{
        width: 100%;
        cursor:pointer;
    }

    .thumbnail video:hover{
        background:orange;
    }

    .thumbnail2{
        cursor:pointer;
        text-align: center;
        border: 0.5px solid #223345;
        padding:15px;
        margin: 5px;
        border-radius: 5px;
    }

    .thumbnail2:hover{
        border: 1px solid orange;
        color:orange;
    }
    
    </style>
  
</head>
<body style="">

  <?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include ('header.php'); ?>

<br>
<div class="breadcome-area">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="breadcome-list">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <ul class="breadcome-menu">
                <li><span class="bread-blod">Your Lessons / CAI</span></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container-fluid">
  <div class="panel-body">
    <div class="row">
      <div class="col-lg-12">
        <h2>Tutorials List</h2>
      </div>
    </div>
  </div>
</div>
<br>
<div class="container-fluid">
<div class="courses-area">
  <div class="container-fluid">
    <div class="row">

       <?php 

        echo LoadTutorials();

      ?>

    </div>
  </div>
</div>
</div>
<?php include "footer.php"; ?>
