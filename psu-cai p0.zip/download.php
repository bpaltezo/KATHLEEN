<?php

	$filename = "";
	header('Content-type: application/pdf');
	header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
	header('Content-Transfer-Encoding: binary');
	readfile($filename);

?>