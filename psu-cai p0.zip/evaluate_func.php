<?php

	date_default_timezone_set("Asia/Manila");
	$conn = mysqli_connect("localhost", "root", "", "cai_it4");

	$userid = $_POST['userid'];
	$qid = $_POST['quizid'];
	$name = $_POST['name'];
	$score = $_POST['score'];
	$total = $_POST['total'];
	$gender = $_POST['gender'];
	$gkey = $_POST['groupkey'];
	$gname = "";

	if($score > ($total/2)){
		$remarks = "Passed";
	}else{
		$remarks = "Failed";
	}

	$sql = "SELECT * FROM groups WHERE group_key='$gkey' ";
	$res = $conn->query($sql);

	while($row = $res->fetch_assoc()){
		$gname = $row['group_name'];
	}

	$id = generateID(6, "results");
	$date = date("F d Y");

	$sql2 = "INSERT INTO results
	(result_id, quizzer_name,quiz_id,score,total_item,rating,gender,group_name,date_quizzed) 
	VALUES ('$id','$name','$qid','$score','$total','$remarks','$gender','$gname','$date')";
	$res2 = $conn->query($sql2);

	$grade = $score / $total * 100;

	$sql3 = "INSERT INTO `grades`(`stud_id`, `quiz_id`, `score`, `date_recorded`, `total_items`, `group_key`, `grade`, `remarks`) VALUES ('$userid', '$qid', '$score', '$date', '$total', '$gkey', '$grade', '$remarks')";
	$res3 = $conn->query($sql3);

	$updateDate = date("D M d Y h:i:s a");

	$sql4 = "INSERT INTO updates (member_id, status, friend, dt) VALUES ('$userid', 'Has taken a quiz', '$gkey', '$updateDate' )";
	$res4 = $conn->query($sql4);

	if($res2 && $res3){
		echo $id;
	}else{
		echo "err";
	}

?>

<?php

function generateID($len, $table){

	$conn = mysqli_connect("localhost", "root", "", "cai_it4");
	$sql = "SELECT * FROM $table";
	$res = $conn->query($sql);

	$result = "";
	$count = 0;
	while($row = $res->fetch_assoc()){
		$count++;
	}

	for($i=0;$i<$len-strlen($count);$i++){
		$result .= 0;
	}

	return $result.($count+1);

}

?>