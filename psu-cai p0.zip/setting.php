<?php
	session_start();
	include("session/DBConnection.php");	
	$user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";
?>

<!DOCTYPE html>
<html>
<head>
	
	<title>Settings - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php include "links.php"; ?>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js2/jquery.watermarkinput.js"></script>
<script type="text/javascript">
	
	$(document).ready( function() {
		$("#edit").click( function() {
			$("#forms").fadeIn();
			$("#cancel1").fadeIn();
			$("#form01").fadeOut();
			$("#edit").fadeOut();
		});	
		$("#cancel1").click( function() {
			$("#forms").fadeOut();
			$("#cancel1").fadeOut();
			$("#form01").fadeIn();
			$("#edit").fadeIn();
		});	
		$("#cancel2").click( function() {
			$("#forms2").fadeOut();
			$("#cancel2").fadeOut();
			$("#form02").fadeIn();
			$("#edit2").fadeIn();
		});	
		$("#edit2").click( function() {
			$("#forms2").fadeIn();
			$("#cancel2").fadeIn();
			$("#form02").fadeOut();
			$("#edit2").fadeOut();
		});	
		$("#change").click( function() {
			$("#account").fadeIn();
			$("#cancel3").fadeIn();
			$("#pass").fadeOut();
			$("#change").fadeOut();
		});	
		$("#cancel3").click( function() {
			$("#account").fadeOut();
			$("#cancel3").fadeOut();
			$("#pass").fadeIn();
			$("#change").fadeIn();
		});	
	});


</script>
	

<script type="text/javascript">
	$(document).ready(function(){
		$(".search").keyup(function(){
			var searchbox = $(this).val();
			var dataString = 'searchword='+ searchbox;

			if(searchbox!=''){
				$.ajax({
					type: "POST",
					url: "search2.php",
					data: dataString,
					cache: false,
					success: function(html){
						$("#display").html(html).show();
					}
				});
			}
			return false;});
	});

	jQuery(function($){
   		$("#searchbox").Watermark("Search");
   	});
</script>
	
	<link rel="stylesheet" type="text/css" href="css/pswd.css" />
	<script type="text/javascript" SRC="js/jquery.pngFix.pack.js"></script>
	<script type="text/javascript"> 
		$(document).ready(function(){ 
			$(document).pngFix(); 
		}); 
		
		function passwordStrength(password){

	        var desc = new Array();

    	    desc[0] = "Very Weak";
    	    desc[1] = "Weak";
    	    desc[2] = "Better";
    	    desc[3] = "Medium";
    	    desc[4] = "Strong";
    	    desc[5] = "Strongest";

    	    var score   = 0;

    	    //if password bigger than 6 give 1 point
	        if (password.length > 6) score++;

        	//if password has both lower and uppercase characters give 1 point      
			if ( ( password.match(/[a-z]/) ) && ( password.match(/[A-Z]/) ) ) score++;

        	//if password has at least one number give 1 point
			if (password.match(/\d+/)) score++;

        	//if password has at least one special character give 1 point
			if ( password.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/) ) score++;

	        //if password bigger than 12 give another 1 point
			if (password.length > 12) score++;

         	$("#asswordDescription").text(desc[score]);
	        document.getElementById("passwordStrength").className = "strength" + score;
	}
	
</script>

</head>

<body>
	
<?php include("header.php"); ?>

	<div id="breadcrumb">
		<div class="container_12 clearfix">
			<div class="grid_1"></div>
			<div class="grid_9">
				
				<p> <?php

	include ("session/DBConnection.php");
	$error = "";
	$user = $_SESSION['log']['username'];
	$query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
	$display = mysql_fetch_array($query);	
	
	if(isset($_POST['edit1'])){ 
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$address = $_POST['address'];
		$contact_no = $_POST['contact_no'];
		$email = $_POST['email'];
		$birthdate = ($_POST['birthday_month'] . "/" . $_POST['birthday_day']. "/" . $_POST['birthday_year'] );
		$b_month = $_POST['birthday_month'];
		$b_day = $_POST['birthday_day'];
		$b_year = $_POST['birthday_year'];
		$gender = $_POST['gender'];
		$relationship = $_POST['relationship'];
		$hometown = $_POST['hometown']; 
	
		$query = "UPDATE members SET firstname='$firstname', lastname='$lastname', birthdate='$birthdate', b_month='$b_month', b_day='$b_day', b_year='$b_year', address='$address', contact_no='$contact_no', email='$email', gender='$gender', relationship='$relationship', hometown='$hometown' WHERE username='$user'";
		$result = mysql_query($query);

		// if successful redirect to delete_multiple.php 
		if($result){
			echo "<meta http-equiv=\"refresh\" content=\"0;URL=setting.php\">";
		}

	}

	if(isset($_POST['edit2'])){ 
		$college = $_POST['college'];
		$high_school = $_POST['high_school'];
		$quote =  $_POST['quote'];
		$aboutme = $_POST['aboutme'];
		$interest = $_POST['interest'];

		$sql2 = "UPDATE members SET interest='$interest', quote='$quote', college='$college', high_school='$high_school', aboutme='$aboutme'  WHERE username='$user'";
		$result2 = mysql_query($sql2);

		// if successful redirect to delete_multiple.php 
		if($result2){
			echo "<meta http-equiv=\"refresh\" content=\"0;URL=setting.php\">";
		}

	}

	if(isset($_POST['edit3'])){ 
	
		if(isset($_POST['old_pass'])){
			$old = $_POST['old_pass'];
		}
		if(isset($_POST['password'])){
			$new = $_POST['password'];
		}
 
 {
 	$oldpass = $display['password'];
 	if($old !=  $oldpass){
		$error = "Password Incorrect...";
	}

	if($old ==  $oldpass){
		if (empty($error)){
			$sql3 = "UPDATE members SET password='$new' WHERE username='$user'";
			$result3 = mysql_query($sql3);
		}

		// if successful redirect to delete_multiple.php 
		if($result3){
			echo "<meta http-equiv=\"refresh\" content=\"0;URL=setting.php\">";
		}
	}
}

if (empty($error)) { $error = "Password updated"; }

}

?></p>
			</div>
			<!-- end grid -->		
		
			<!-- end grid -->
		</div><!-- end container -->
	</div>
	<br>
	<div id="content">
		<div class="container_12 clearfix">
			
			<div class="col-lg-8">
			
			 	<fieldset>
				<legend>Account Information</legend>
					<div id="pass">
					<span style="color:#223345;">Username : </span>
					<span id="info" style="margin-left: 61px; text-transform:none;">
						<?php echo $display['username'] ?>
					</span><br />
					
<script type="text/javascript">
	var password = "<your password here>";
	var dispPassword = new String();
	var n = password.length;
	while(dispPassword.length < n){ 
        dispPassword.push("*"); 
	}
	document.getElementById("password").innerHTML = dispPassword;
</script>
					<span style="color:#223345;">Password : </span>
						<span id="password" style="margin-left: 61px;">
			  				<input type="password" class="form-control" name="password" value="<?php echo $display['password'] ?>" style="padding:1%;" readonly>
			  			</span>
			  			<span style="color:#ff0000;"><?php echo $error;?></span>
			  		</div>
					
					<div id="change" style="font-size: 10px;"><a>Change Password</a></div>
					<div id="cancel3" style="display:none;float: right;"><a>Cancel</a></div>
					
					<div class="col-lg-6">
					<div id="account" style="display:none;">
						<form id="form1" method="post" action="setting.php">
							<p><label for="text_field">Current Password:</label>
								<div id="entry-text">
						 			<input class="form-control" style="padding:1%;" type="password" name="old_pass" class="form-control" /><br />
					  			</div>
							</p>
							<p><label for="text_field">New Password:</label>
							<div id="entry-text">
								<input  class="form-control" id="text" name="password" type="password" onKeyUp="passwordStrength(this.value)" /> 
								<br />
								<label for="passwordStrength">Password strength</label>
		                        <div id="passwordDescription">Password not entered</div>
		                        <div id="passwordStrength" class="strength0"></div>
                        	</div>
							</p>
						
							<p id="but"><br />
								<input class="button" value="Submit" type="submit" name="edit3"/>
								<input class="button" value="Clear" type="reset" />
							</p>
	    				</form>
	    			</div>
	    			</div>

			  </fieldset>

				<fieldset style="width: 700px;">
					<legend>Basic and Contact information</legend>
					<div id="edit" style="padding-left: 620px;"><a>Edit</a></div>
					<div id="cancel1" style="display:none; padding-left: 620px;"><a>Cancel</a></div>
					<div id="form01">
					<span style="color:#42F709; font-weight:bold;">Name : </span><span id="info" style="margin-left: 61px;"><?php echo $display['firstname'] . " " . $display['lastname'] ?></span><br />
					<span style="color:#42F709; font-weight:bold;">Address : </span><span id="info" style="margin-left: 47px;"><?php echo $display['address'] ?></span><br />
					<?php $hometown = $display['hometown'];
					if($hometown != ""){
					echo '<span style="color:#42F709;; font-weight:bold;">Hometown : </span><span id="info" style="margin-left: 30px;">' . $hometown . '</span><br />'; } ?>
					<?php $contact = $display['contact_no'];
					if($contact != ""){
					echo '<span style="color:#42F709;; font-weight:bold;">Contact No. : </span><span id="info" style="margin-left: 25px;">' . $contact .'</span><br />'; } ?>
					<span style="color:#42F709; font-weight:bold;">Email : </span><span id="uu" style="margin-left: 64px;"><?php echo $display['email'] ?></span><br />
					<span style="color:#42F709; font-weight:bold;">Birthdate : </span><span id="info" style="margin-left: 39px;"><?php echo $display['birthdate'] ?></span><br />
					<span style="color:#42F709; font-weight:bold;">Gender : </span><span id="info" style="margin-left: 53px;"><?php echo $display['gender'] ?></span><br />
				<?php $rel = $display['relationship'];
					if($rel != ""){
					echo '<span style="color:#42F709;; font-weight:bold;">Relationship : </span><span id="info" style="margin-left: 20px;">' .$rel . '</span><br />'; }?></div>
					
<div id="forms" style="display:none;">
					<form id="form1" method="post" action="setting.php">
						
						<p>
						
							<label for="text_field">Firstname:</label>
					  <div id="entry-text">
							<input class="form-control" type="text" id="cap" name="firstname" value="<?php echo $display['firstname'] ?>"/></div>
					  </p>

						<p>
							<label for="text_field">Lastname:</label>
					  <div id="entry-text">
							<input class="form-control" type="text" id="cap" name="lastname"   value="<?php echo $display['lastname'] ?>"/></div>
						</p>
						<p><label for="text_field">Address:</label>
					  <div id="entry-text">
							 <input class="form-control" type="text" id="cap" name="address"   value="<?php echo $display['address'] ?>" /></div>
						</p>
						<p><label for="text_field">Hometown:</label>
						<div id="entry-text">
						 <input class="form-control" type="text" id="cap" name="hometown"   value="<?php echo $display['hometown'] ?>" /></p></div>
						<p>
						  <label for="text_field">Contact No.:</label>
					  <div id="entry-text">
							<input class="form-control" type="text" id="cap" name="contact_no"   value="<?php echo $display['contact_no'] ?>" /></div>
						<p><label for="text_field">Email:</label>
						<div id="entry-text">
							 <input class="form-control" type="text" name="email" id="username" value="<?php echo $display['email'] ?>" /></div>
						</p>
						<p><label for="text_field">Birthdate:</label>
					  	<div id="entry-text">
							<input type="date" name="birthdate" class="form-control">
						</div>
						</p>
						<p><label for="text_field">Gender:</label>
					  <div id="entry-text">
							 <select class="form-control" name="gender" id="drop cap">
                                <option selected="selected"><?php echo $display['gender'] ?></option>
                                <option value="-1">-Select Gender-</option>
                                <option>Female</option>
                                <option>Male</option>
                          </select></div>
						</p>
						<p><label for="text_field">Relationship:</label>
						<div id="entry-text">
							 <select class="form-control" name="relationship" id="drop cap">
                                <option selected="selected"><?php echo $display['relationship'] ?></option>
                                <option value="-1">-Select Status-</option>
                                <option>Single</option>
                                <option>In a relationship</option>
                                <option>Married</option>
                                <option>Widow</option>
                                <option>Seperated</option>
                          </select>
                      </div>
						</p><p id="but"><br />
							<input class="button" value="Submit" type="submit" name="edit1"/>
							<input class="button" value="Clear" type="reset" />
						</p>
						
					</form></div>
				</fieldset>
				<br />
				<fieldset style="width: 700px;">
				<legend>Education, Interest and Entertainment</legend>
				<div id="edit2" style="padding-left: 620px;"><a>Edit</a></div>
				<div id="cancel2" style="display:none; padding-left: 620px;"><a>Cancel</a></div>

					<div id="form02">
					<?php $high = $display['high_school'];
					if($high != ""){
					echo '<span style="color:#42F709; font-weight:bold;">High School :</span><span id="info" style="margin-left: 23px;">' .$high . '</span><br />'; } ?>
					<?php $college = $display['college'];
					if($college != ""){
					echo '<span style="color:#42F709; font-weight:bold;">College :</span><span id="info" style="margin-left: 55px;">' . $college . '</span><br />'; } ?>
					<?php $interest = $display['interest'];
					if($interest != ""){
					echo '<span style="color:#42F709; font-weight:bold;">Interests :</span><span id="info" style="margin-left: 45px;">' . $interest .'</span><br />'; } ?>
					<?php $aboutme = $display['aboutme'];
					if($aboutme != ""){
					echo '<span style="color:#42F709; font-weight:bold;">About You :</span><span id="info" style="margin-left: 34px;">' . $aboutme. '</span><br />'; } ?></div>
<div id="forms2" style="display:none;">
					<form id="form1" method="post" action="setting.php">
						<p><label for="text_field">High School:</label>
						<div id="entry-text">
						 <input type="text" id="cap" name="high_school"   value="<?php echo $display['high_school'] ?>" /></div>
						</p>
						<p><label for="text_field">College:</label>
						<div id="entry-text">
						 <input type="text" id="cap" name="college"   value="<?php echo $display['college'] ?>" /></div>
						</p>
				<p><label for="text_field">Interests:</label>
					  <div id="entry-text">
						<input type="text" id="cap" name="interest" value="<?php echo $display['interest'] ?>" /></div>
</p>				
						<p>
						<label for="text_field">About You:</label>
						<div id="entry-text">
						 <input type="text" id="cap" name="aboutme"   value="<?php echo $display['aboutme'] ?>" /></div>
						</p>
						<p id="but"><br />
							<input class="button" value="Submit" type="submit" name="edit2"/>
							<input class="button" value="Clear" type="reset" />
						</p>
		</form></div>
				</fieldset>
		  </div>
			<!-- end grid -->
<!-- /Cols 1 -->
    
<br class="clear" />
    
</div>
</div><!-- end container -->
	</div>
	<!-- end content -->
	<!-- end footer -->

<footer>
	<div class="footer">
		<div class="row">
			<div class="col-lg-12">
			<p class="pull-left">&copy; <a href="http://usman.it" target="_blank">Computer Aided Instruction System for Pangasinan State University. All Rights Reserved.</a> <?php echo date('Y') ?></p>
			<p class="pull-right">CAI: <a href="http://usman.it/free-responsive-admin-template">Discrete Mathematics</a></p>
			</div>
		</div>
	</div>
</div>
</footer>

<?php include("footer.php"); ?>
