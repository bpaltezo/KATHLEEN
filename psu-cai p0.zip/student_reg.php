<?php session_start(); ?>
<!DOCTYPE html>

<?php

  include('session/DBConnection.php');
  #include "includes/functions.php";

 if (isset($_POST['register'])) { 
  if (!$_POST['group_code']|
      !$_POST['username']|
      !$_POST['password']|
      !$_POST['firstname']|
      !$_POST['lastname']|
      !$_POST['email']|
      !$_POST['gender']){
    die('Please complete all the required feilds!');
  }
    
  if(!get_magic_quotes_gpc()){
    $_POST['username'] = addslashes($_POST['username']);
  }
  
  $usercheck = $_POST['username'];
  $check = mysql_query("SELECT * FROM members WHERE username = '$usercheck'") or die(mysql_error());
  $check2 = mysql_num_rows($check);
  
  if($check2 != 0){
    die('Sorry, the username '.$_POST['username'].' is already in use!' . " " . 'or' .  " " .'INVALID          username!<br />'. " " . " " .'Please try another username..' );
  }

  if(!get_magic_quotes_gpc()){
    $_POST['firstname'] = addslashes($_POST['firstname']);
  }

  if(!get_magic_quotes_gpc()){
    $_POST['lastname'] = addslashes($_POST['lastname']);
  }

  if(!get_magic_quotes_gpc()){
    $_POST['group_code'] = addslashes($_POST['group_code']);
  }
  
  $idcheck = $_POST['group_code'];
  $check3 = mysql_query("SELECT * FROM groups WHERE group_key= '$idcheck'") or die(mysql_error());
  $check4 = mysql_num_rows($check3);
  
  if($check4 == 0){
    die('Sorry, the Group Code.  '.$_POST['group_code'].' is incorrect!' . " " . 'or' .  " " .'INVALID Group Code.!<br />'. " " . " " .'Please try again..' );
  }
  
  $_POST['group_code'] = ($_POST['group_code']);
  $password = ($_POST['password']);
  $_POST['gender'] = ($_POST['gender']);
    
  $type = "Student";

  $group_key = $_POST['group_code'];

  $sql  = "SELECT * FROM groups WHERE group_key= '$group_key'";
  $result = mysql_query($sql);
  
  $instructor = "";

  while($row1 = mysql_fetch_assoc($result)){
    $instructor = $row1['faculty_name'];
  }
                     
  if(!get_magic_quotes_gpc()){
    $password = addslashes($_POST['password']);
    $_POST['username'] = addslashes($_POST['username']);
  }

  if($_POST['gender'] == "Male"){
    $propic = "uploads/propicm.png";
  }else if($_POST['gender'] == "Female"){
    $propic = "uploads/propicf.png";
  }

  $insert = "INSERT INTO members SET group_key='$_POST[group_code]', username='$_POST[username]', password='$password', firstname='$_POST[firstname]', lastname='$_POST[lastname]', email='$_POST[email]', address='', contact_no='', birthdate='', b_month='', b_day='', b_year='', gender='$_POST[gender]', instructor='$instructor', image='$propic', type='$type', confirmation='1', current_lesson='1', current_quiz='1'";
  
  $add_member = mysql_query($insert);

  if($add_member){
      echo "<script type='text/javascript'>
        alert('Account Registered!');
        window.location = 'admin/accounts.php';
      </script> ";
    }else{
      echo "<script type='text/javascript'>
      alert('Unable to Register!');  
    </script> ";
    }
  
  exit();
}

?>


<html>
<head>
  <title>Register</title>
  <meta name="description" content="">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon2.ico">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.print.min.css">
    <link rel="stylesheet" href="css/form/all-type-forms.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>

    <style type="text/css">
      body{
        background:url("images/slider2.jpg");
        background-size: auto;
        background-repeat: no-repeat;
        background-position: center;
        background-blend-mode: soft-light;
      }
    </style>

</head>
<body>

<div class="error-pagewrap">
    <div class="error-page-int">
      
      <div class="content-error">
        <div class="hpanel">
          <div class="panel-body">
            <div class="text-center custom-login">
              <h3>New Student</h3>
            </div>
            
            <form action="student_reg.php" method="post" id="loginForm">
              <div class="row">
                <div class="form-group col-lg-12">
                  <label>Username</label>
                  <input class="form-control" name="username" autocomplete="off">
                </div>
                <div class="form-group col-lg-12">
                  <label>Password</label>
                  <input type="password" class="form-control" name="password" autocomplete="off">
                </div>
                <div class="form-group col-lg-12">
                  <label>Section</label>
                  <select class="form-control" name="group_code" required>
                    <option></option>
                    <?php

                      $conn = mysqli_connect("localhost", "root", "", "cai_it4");
                      $sql = "SELECT * FROM groups WHERE faculty_name!='' ORDER BY group_name ASC";
                      $res = $conn->query($sql);

                      while($row = $res->fetch_assoc()){
                        echo "<option value='".$row['group_key']."'>";
                        echo $row['group_name'];
                        echo "</option>";
                      }

                    ?>
                  </select>
                </div>
              </div>
              <div class="row">
                <div class="form-group col-lg-6">
                  <label>First Name</label>
                  <input class="form-control" name="firstname" autocomplete="off">
                </div>
                <div class="form-group col-lg-6">
                  <label>Last Name</label>
                  <input class="form-control" name="lastname" autocomplete="off">
                </div>
                <div class="form-group col-lg-6">
                  <label>E-mail</label>
                  <input type="email" class="form-control" name="email" autocomplete="off">
                </div>
                <div class="form-group col-lg-6" style="display: none;">
                  <label>Address</label>
                  <input class="form-control" name="address" autocomplete="off" >
                </div>
               <div class="form-group col-lg-6">
                  <label>Gender</label>
                  <select class="form-control" name="gender" >
                    <option></option>
                    <option>Male</option>
                    <option>Female</option>
                  </select>
                </div>

              </div>

              <input type="hidden" name="register" value="true" >
              
              <div class="text-center">
                <button class="btn btn-success loginbtn">Register</button>
                <button type="button" class="btn btn-default" onclick="window.location.href = 'admin/accounts.php'; " >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="text-center login-footer">
        <p>Copyright © 2018. All rights reserved. Template by <a href="https://colorlib.com/wp/templates/">Colorlib</a></p>
      </div>
    </div>
  </div>

    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery-price-slider.js"></script>
    <script src="js/jquery.meanmenu.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
    <script src="js/metisMenu/metisMenu.min.js"></script>
    <script src="js/metisMenu/metisMenu-active.js"></script>
    <script src="js/tab.js"></script>
    <script src="js/icheck/icheck.min.js"></script>
    <script src="js/icheck/icheck-active.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">

      function passwordStrength(password){
        var desc = ["Very Weak", "Weak", "Better", "Medium", "Strong", "Strongest"];
        var score   = 0;

        //if password bigger than 6 give 1 point
        if (password.length > 6) score++;

        //if password has both lower and uppercase characters give 1 point      
        if ( ( password.match(/[a-z]/) ) && ( password.match(/[A-Z]/) ) ) score++;

        //if password has at least one number give 1 point
        if (password.match(/\d+/)) score++;

        //if password has at least one special caracther give 1 point
        if ( password.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/) ) score++;
        
        //if password bigger than 12 give another 1 point
        if (password.length > 12) score++;

        document.getElementById("passwordDescription").innerHTML = desc[score];
        document.getElementById("passwordStrength").className = "strength" + score;
      }

    </script>

</body>
</html>