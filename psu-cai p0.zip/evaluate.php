<?php session_start();?>
<?php
  include("session/DBConnection.php");  
    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $userid = $display['member_id'];
    $gender = $display['gender'];
    $current_lesson = $display['current_lesson'];
    $current_quiz = $display['current_quiz'];
    $fullname = $name." ".$lastname;

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";
    
?>

<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php require_once("includes/functions.php"); ?>

<?php

	$sql = "SELECT * FROM results WHERE result_id=".$_GET['sub'];
	$res = $conn->query($sql);

	while($row = $res->fetch_assoc()){
		$rname = $row['quizzer_name'];
		$quizid = $row['quiz_id'];
		$score = $row['score'];
		$total = $row['total_item'];
		$rating = $row['rating'];
		$rgender = $row['gender'];
		$gname = $row['group_name'];
		$date = $row['date_quizzed'];
	}

	$sql = "SELECT * FROM quiz WHERE quiz_id='$quizid' ";
	$res = $conn->query($sql);

	while($row = $res->fetch_assoc()){
		$topicid = $row['topic_id'];
		$topicpos = $row['pos'];
	}

	$sql = "SELECT * FROM quiz WHERE topic_id='$topicid' ";
	$res = $conn->query($sql);

	$quizontopic = 0;
	while($row = $res->fetch_assoc()){
		$quizontopic++;
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Evaluation - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>
	<?php include "links.php"; ?>

</head>
<body>

<?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include('header.php'); ?>

<br><br><br><br>
<div class="container-fluid">
	<div class="row" id="delay">
		<div class="col-lg-12 text-center">
			<i class="fas fa-spinner fa-spin fa-9x"></i><br><br><br><br><br>
			<h3><span id="tag">Checking your answers</span><span id="wait"> .</span></h3>
		</div>
	</div>
	<div class="row" id="result" style="display: none;">
		<section>
		<div class="container-fluid">
    		<div class="jumbotron container-fluid">

  		<?php
  			#$rating = "Failed";

  			if($rating == "Passed"){

  				$icon = "fa-check-circle";
  				$iconcolor = "#00BFFF";
  				$t1 = "Congratulations! You Passed";
  				$percent = $score / $total * 100;
  				$t2 = "<br>You can now continue to the next quiz<br> or continue to the next lesson.";
  				$btntext = "Continue";
  				$link = "quiz.php";

  				if($current_quiz < $quizontopic){
  					#NEXT QUIZ
  					$current_quiz++;
  					$sql = "UPDATE members SET current_quiz='$current_quiz' WHERE member_id='$userid' ";
  					$res = $conn->query($sql);

  				}else if($current_quiz == $quizontopic){
  					#NEXT LESSON
  					$current_lesson++;
  					$sql = "UPDATE members SET current_lesson='$current_lesson', current_quiz='1' 
  							WHERE member_id='$userid' ";
  					$res = $conn->query($sql);
  				}

  			}else if($rating == "Failed"){
  				$icon = "fa-exclamation-circle";
  				$iconcolor = "#DC143C";
  				$t1 = "Oops! You Failed";
  				$percent = $score / $total * 100;
  				$t2 = "<br>You have failed to pass the quiz. Go back to the lesson and retake the test.";
  				$btntext = "Retake Quiz";
  				$link = "quiz.php";

  			}
  		?>
    			
    			<div class="col-lg-12 text-center">
    				<i class="fas <?php echo $icon; ?> fa-9x" style="color:<?php echo $iconcolor; ?>;"></i>
    				<br><br><br><br>
    			  <div style="background-color:#fff;padding:5%;">
    				<h2><?php echo $t1; ?></h2>
    				<br><br>
    				<h4><?php echo floor($percent); ?>%</h4>
    				<p><?php echo $score; ?> out of <?php echo $total; ?></p>
    				<p style="font-size: 12pt;">
    					<?php echo $t2; ?>
    				</p>
    				<br><br>
    				<a href=""><button class="btn btn-info"><i class="fas fa-share"></i> Share</button></a>
    				<a href="<?php echo $link; ?>">
    					<button class="btn btn-success">
    						<?php echo $btntext; ?> <i class="fas fa-angle-right"></i>
    					</button>
    				</a>
    				<br>	
    			  </div>
    			</div>
    	
    		</div>
    	</div>
  		</section>
	</div>
</div>

<script type="text/javascript">

var d = 0;

var dots = window.setInterval( function() {
	var container = document.getElementById("delay");
	var res = document.getElementById("result");
    var wait = document.getElementById("wait");
    var t = document.getElementById("tag");
    if ( wait.innerHTML.length > 4 ) wait.innerHTML = "";
    else wait.innerHTML += ".";
    if (d == 6) t.innerHTML = "Evaluating";
    if (d == 12){
    	clearInterval(dots);
    	container.style.display = "none";
    	res.style.display = "block";
    }

    d++;
}, 10);

window.onload = function(){


}

</script>


<?php include "footer.php"; ?>