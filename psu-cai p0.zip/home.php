<?php session_start(); ?>
	
<!DOCTYPE html>
<html>
<head>

<?php
	include("session/DBConnection.php");	
		$user = (isset($_SESSION['log']['username'])) ? $_SESSION['log']['username'] : "";
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $current_lesson = $display['current_lesson'];
    $current_quiz = $display['current_quiz'];
    $fullname = $name." ".$lastname;
    $userid = $display['member_id'];

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";

?>

<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php include "includes/functions.php"; ?>

	<title>Home - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

  <?php include "links.php"; ?>
  <link rel="stylesheet" type="text/css" href="fonts/googlefonts.css">

  <style type="text/css">
    .coverer{
      background-color: #223345;
      background-blend-mode: darken;
    }
    a:hover{
      color:all;
    }
    
  </style>

</head>
<body class="">

<?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include ('header.php'); ?>
<br>
<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
  <div class="social-media-edu">
    <div class="col-lg-5">
      <img src="images/math2.jpg" style="width: 100%;height:80%;">
    </div>
    <div class="col-lg-7 text-center">
      <h1 style="color: #223345;">COMPUTER AIDED INSTRUCTION</h1>
      <h1><small>ON DISCRETE MATHEMATICS</small></h1><br>
      <span style="color:blue;font-size:16pt;">Pangasinan State University</span><br>
      <small>Lingayen Campus</small>
    </div>
  </div>
</div>

<div class="breadcome-area">
<div class="container-fluid">

<!--
<div class="col-lg-12 col-md-12 col-sm-6 col-xs-12" id="sliderx">
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  
  <div class="carousel-inner">
    <div class="item active">
      <img class="d-block" src="images/slider5.jpg" alt="First slide">
      <div class="carousel-caption">
        <h1 style="font-size:80pt;margin-top: -50%;color:#fff;">Welcome</h1>
      </div>
    </div>
    <div class="item">
      <img class="d-block w-100" src="images/slider6.jpg" alt="Second slide" width="100%" height="150">
      <div class="carousel-caption">
        <h1 style="width:100%;font-size:45pt;margin-top:-50%;color:#fff;text-shadow: 0 0 5px #45D699;">
        Computer Aided Instruction System</h1>
      </div>
    </div>
    <div class="item">
      <img class="d-block w-100" src="images/slider4.jpg" alt="Fourth slide" width="100%" height="150">
      <div class="carousel-caption">
        <h1 style="font-size:35pt;margin-top: -50%;color:#fff;text-shadow: 0 0 8px #CBD645;">
          <span style="color:#fff;font-weight: normal;font-size: 15pt;">On</span><br>
          Discrete Mathematics</h1>
      </div>
    </div>
    <div class="item">
      <img class="d-block w-100" src="images/slider2.2.jpg" alt="Fourth slide" width="100%" height="150">
      <div class="carousel-caption" style="">
        <h1 style="width: 100%;font-size:25pt;margin-top: -45%;color:#fff;text-shadow: 0 0 8px #4583D6;">
          <span style="color:#fff;font-weight: normal;font-size: 15pt;">For</span><br>
          Pangasinan State University
        </h1>
        <h3>Lingayen Campus</h3>
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>

</div>
</div>
-->
</div>
</div>
<br>

<?php if ($type == 'Student') include "home_student.php"; ?>
<?php if ($type == 'Faculty') include "home_instructor.php"; ?>


<br><br><br>

<script type="text/javascript">

  /*
  window.onscroll = function() {scrollFunction()};

  function scrollFunction(){

    if(document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
      
      $("#sliderx").hide("slow");

    }else if(document.body.scrollTop == 0 || document.documentElement.scrollTop == 0){
      
      $("#sliderx").show("slow"); 
    
    }
  }

  console.log(chrome);*/

</script>

<?php
include ('footer.php');
 ?>