<?php
 	
 	session_start();
 	date_default_timezone_set("Asia/Manila");

	include("session/DBConnection.php");
	$username = $_SESSION['log']['username'];
	$query = mysql_query("SELECT * FROM members WHERE username = '$username'") or die (mysql_error()); 
	$display = mysql_fetch_array($query);	
	$password = $display['password'];
	$id = $display['member_id'];
	$gkey = $display['group_key'];
	$timeout = date("h:i:s a");
	$dateout = date("M d");
	
	if($display['type'] == "Student"){
		$sql = "INSERT INTO logs (memberid, logout, dateout, gkey) VALUES ('$id', '$timeout', '$dateout', '$gkey')";
		$logs = mysql_query($sql);
	}

	$sql = "DELETE FROM users WHERE username = '$username' AND password = '$password'";
	$add_member = mysql_query($sql);

?>

<?php

  @session_unregister('log');
  @session_unset();

  header("Location: login2.php");


?>
