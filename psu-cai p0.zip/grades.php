<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>

<?php
	
	include("session/DBConnection.php");
	$user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $current_lesson = $display['current_lesson'];
    $current_quiz = $display['current_quiz'];
    $fullname = $name." ".$lastname;
    $userid = $display['member_id'];

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";

?>

<title>Grades - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php include "includes/functions.php"; ?>
<?php include "links.php"; ?>

</head>
<body>
<?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include "header.php"; ?>

<div class="breadcome-area">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="breadcome-list">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <h3><i class="fas fa-award fa-2x" style="color: #FFBD33;"></i> Your Grades</h3>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <ul class="breadcome-menu">
                <li><span class="bread-blod">Home</span> / Grades</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container-fluid">
    <div class="row">
        <br>
        <div class="col-lg-8 col-md-10 col-sm-6 col-xs-4">
            <div class="analysis-progrebar res-mg-t-30 mg-ub-10 res-mg-b-30 table-mg-t-pro-n tb-sm-res-d-n dk-res-t-d-n">
        
            <?php echo getGrades($display['member_id']); ?>
            
            </div>
        </div>
    </div>
</div>



<?php include "footer.php"; ?>