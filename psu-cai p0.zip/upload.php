<?php
	
	include "includes/connection.php";
	include "includes/upload.php";

	$profileImageId = $_POST['id'];
	$image = $_FILES['uploadimg'];

	$uploadedFile = UploadImage($image, true, $profileImageId);
	$success = false;

	if(!$uploadedFile[0]){
		//echo "err";
		$uploadedFileName = "";
		$uploadedFilePath = "";
	
	}else{
		//echo "success";
		$uploadedFileName = $uploadedFile[0];
		$uploadedFilePath = $uploadedFile[1];
		$success = true;
	}

	if($success){

		$imagesrc = "uploads/".$uploadedFileName;
		
		$sql = "UPDATE members SET image='$imagesrc' WHERE member_id=".$_POST['id'];
		$res = $conn->query($sql);

		if($res){
			header("Location: profile.php");
		}

	}else{
		echo "error";
	}

	
?>