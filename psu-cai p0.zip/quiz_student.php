<?php

  if(Security("get", "tutorial") || Security("get", "lesson")){
    if(Security("get", "tutorial")){
     header("Location: session/lockdown.php?active=tutorial"); 
   }else if(Security("get", "lesson")){
    header("Location: session/lockdown.php?active=lesson");
   }
  }else if(!Security("get", "tutorial") && !Security("get", "lesson")){
      Security("set", "quiz");
  }

  $qid = $_GET['topic'];
  $pos = $_GET['pos'];

    $sql = "SELECT * FROM quiz WHERE quiz_id ='$pos' ";

    $res = $conn->query($sql);

    $title = "";
    $desc = "";
    
    $ch = "";
    $iden = "";
    $tf = "";

    $count = 0;
    $content = "";

    $alldata = array();
    $quizid = "";

    while($row = $res->fetch_assoc()){
      $title = $row['quiz_title'];
      $desc = $row['quiz_description'];
      $total = $row['item_student'];
      $quizid = $row['quiz_id'];
      $time = $row['quiz_timelimit'];
    }

    if($quizid == ""){
      //header("Location: quiz_noquiz.php?pos=".$pos);
    }

    $sql2 = "SELECT * FROM questions WHERE quiz_id='$quizid' ";
    $res2 = $conn->query($sql2);

    while($row = $res2->fetch_assoc()){

      $data = array();
      
      $count++;
      $q = $row['questions_question'];
      $qid = $row['questions_id'];

      $data[] = $q;
      $data[] = $qid;
      $data[] = $row['questions_type'];

      $xsql = "SELECT * FROM answers WHERE questions_id='$qid' ";
      $xres = $conn->query($xsql);

      $choices = array();

      while($row2 = $xres->fetch_assoc()){
        $ans = $row2['correct'];
        $c1 = $row2['choice1'];
        $c2 = $row2['choice2'];
        $c3 = $row2['choice3'];
        $c4 = $row2['choice4'];

        $choices[] = $c1;
        $choices[] = $c2;
        $choices[] = $c3;
        $choices[] = $c4;
      }

      $data[] = $ans;
      $data[] = $choices;

      if($row['questions_type'] == "Multiple Choice"){

      }else if($row['questions_type'] == "Identification"){

      }else if($row['questions_type'] == "True or False"){
        
      }

      $alldata[] = $data;

    }

    shuffle($alldata);
    $finaldata = array();

    for($x = 0; $x < 10; $x++){
      $finaldata[] = $alldata[$x];
    }

    //print_r($finaldata);

?>

<div class="blog-details-area mg-b-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="blog-details-inner">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="latest-blog-single blog-single-full-view">
                                <div class="blog-image">
                                    <div class="blog-date">
                                        <p>
                                            <span class="blog-day"><?php echo date('d'); ?></span> 
                                            <?php echo date("M") ?>
                                        </p>
                                    </div>
                                </div>
                                <div style="margin-left: 7%;margin-top:-2%;">
                                    <h1><a class="blog-ht" href="#"><?php echo $title; ?></a></h1>
                                </div>
                                <div class="blog-details blog-sig-details">
                                    <div class="details-blog-dt blog-sig-details-dt courses-info mobile-sm-d-n">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                    
                                    <h3 class="text-center"><?php echo $desc; ?></h3>

                                    <br>

                <!-- QUIZ CONTAINER -->
                <div id="quiz-container" style="display: none;">
                                    <div class="progress" style="display: none;">
                                        <div id="myBar" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                                        </div>
                                    </div>
                                    
                                    <div class="jumbotron container-fluid">
                                      
                                      <div class="row">
                                        <div class="col-lg-6">
                                          Question <b id="counter"></b>/<span>10</span>
                                        </div>
                                        <div class="col-lg-6 text-right">
                                          <b id="timer"></b>
                                        </div>
                                      </div>
                                      <br><br>
                                      <div class="row">
                                        <div class="col-lg-12 text-center q" style="font-size:18pt;"></div>
                                      </div>
                                      <br>
                                      <div id="main-holder"></div>
                                      <br><br>
                                      <div class="text-center rescont">
                                      

                                      </div>
                                      <div class="row">
                                        <button class="btn btn-info ansBtn" style="float: right;">Final Answer 
                                          <i class="fas fa-arrow-alt-circle-right"></i></button>
                                        <button class="btn btn-info nextBtn" style="float: right;">Next
                                          <i class="fas fa-arrow-alt-circle-right"></i></button>
                                      </div>

                                    </div>

                </div>
              <!-- QUIZ CONTAINER -->

              <!-- START BUTTON CONTAINER -->
              <div class="row" id="startBtn">
                <div class="col-lg-12 text-center">
                  <button class="btn stBtn" data-toggle="tooltip" title="Start the Quiz Now" style="background-color: transparent;">
                  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="preloader-single shadow-inner res-mg-b-30">
                            <div class="ts_preloading_box">
                                <div id="ts-preloader-absolute14">
                                    <div class="tsperloader22" id="first_tsperloader22"></div>
                                    <div class="tsperloader22" id="second_tsperloader22"></div>
                                    <div class="tsperloader22" id="third_tsperloader22"></div>
                                </div>
                            </div>
                        </div>
                  </div>
                  </button>
                  
                  <p>Press the icon if you are ready to take the quiz.</p>
                </div>
              </div>
              <!-- START BUTTON CONTAINER -->
                                  
                                </div>
                            </div>
                        </div>
                    </div>

               </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

  var totalItems = 10;
  var data = null;
  var score = 0;
  var count = 0;
  var counter = null;
  var current = "";
  var result = {
    answer:[],
    input:[]
  };
  
  function move(){

    var elem = document.getElementById("myBar");
    var timer = document.getElementById("timer");
    var totalq = <?php echo $time; ?>;
    var width = 100 / totalq;
    var tempwidth = width;
    var time = totalq-1;
    counter = setInterval(frame, 1000);
  
    function frame() {
      if (width >= 100) {
        clearInterval(counter);
        next();
      } else {
        width += tempwidth;
        elem.style.width = width + '%';
        elem.setAttribute("aria-valuenow", width);
        if(time < 10){
          timer.innerText = "00:0" + time;
        }else{
          timer.innerText = "00:" + time;
        }
        time--;
      }
    }

  }

  function start(){

    $("#startBtn").hide();
    $("#quiz-container").show();
    $(".nextBtn").hide();
    generate();
    //move();

  }

  function next(){

    clearInterval(counter);

    count++;

    if(count < totalItems){

      generate();
      //move();

    }else{

      alert("Done! Your Score is "+score);
      //console.log(check());
      //alert("Done! Your Score is "+check());
      
      $.post("evaluate_func.php", {

        quizid: "<?php echo $quizid; ?>",
        name: "<?php echo $fullname; ?>",
        score: score,
        total: totalItems,
        gender: "<?php echo $gender; ?>",
        groupkey: "<?php echo $gkey; ?>",
        userid: "<?php echo $userid; ?>"

      }, function(data, success){

        if(data != "err"){
          //alert(data);
          console.log(data);
          window.location.href = "evaluate.php?sub="+data;
        }else{
          alert(data);
        }

      });
      
    }
    
  }

  window.onload = function(){

    //console.log(chrome.windows);

    /*THIS CODES ARE FOR THE QUIZ SECURITY   -- START
    localStorage.setItem("quizState", "active");

    var state = {
      tutorial: (localStorage.getItem("tutorialState")) ? localStorage.getItem("tutorialState") : "",
      lesson: (localStorage.getItem("lessonState")) ? localStorage.getItem("lessonState") : "",
      valid: true
    };

    if(state.tutorial == "active"){
      state.valid = false;
      //alert("The system has detected that the tutorial page is open. This will prevent you to take this quiz. Finish the lesson and close the tab and take the quiz again.");
    }

    if(state.lesson == "active"){
      state.valid = false;
      //alert("The system has detected that the lessons page is open. This will prevent you to take this quiz. Finish the lesson and close the tab and take the quiz again.");
    }

    if(!state.valid){
      window.location.href = "session/lesson_tutorial_lockdown.php";
    }
    //THIS CODES ARE FOR THE QUIZ SECURITY  -- END*/
     

    data = <?php echo json_encode($finaldata); ?>;
    
    $(".stBtn").on("click", function(){
      start();
    });

    $(".ansBtn").on("click", function(){

      check(count);
      $(".nextBtn").show();
      $(".ansBtn").hide();

    });

    $(".nextBtn").on("click", function(){

      if(result.input[count] == undefined || result.input[count] == null){
        result.input[count] = "";
      }
      next();
      $(".rescont").empty();
      $(".nextBtn").hide();
      $(".ansBtn").show();
    });

  }

  window.onbeforeunload = function(){
    $.post("session/security.php", {do: "unset",session: "quiz"});
  }

  window.onunload = function(){
    $.post("session/security.php", {do: "unset",session: "quiz"});
  }

  function generate(){

      var question = data[count][0];
      var id = data[count][1];
      var type = data[count][2];
      var answer = data[count][3];
      var choices= data[count][4];

      if(type == "Multiple Choice"){

        $("#main-holder").empty();
        $("#main-holder").html(`<div class="row" id="mc">
                          <div class="col-lg-3"></div>
                          <div class="col-lg-6 text-center">
                            <label class="container"><p id="mc1"></p>
                              <input type="radio" name="radio" class="abcd" value="a">
                              <span class="checkmark"></span>
                            </label>
                            <label class="container"><p  id="mc2"></p>
                              <input type="radio"  name="radio" class="abcd" value="b">
                              <span class="checkmark"></span>
                            </label>
                            <label class="container"><p  id="mc3"></p>
                              <input type="radio" name="radio"  class="abcd" value="c">
                              <span class="checkmark"></span>
                            </label>
                            <label class="container"><p id="mc4"></p>
                              <input type="radio" name="radio"  class="abcd" value="d">
                              <span class="checkmark"></span>
                            </label>
                          </div>
                          <div class="col-lg-3"></div>
                        </div>`);

      }else if(type == "Identification"){
        
        $("#main-holder").empty();
        $("#main-holder").html(`<div class="row" id="iden">
                          <div class="col-lg-3"></div>
                          <div class="col-lg-6 text-left">
                          <input type="text" id="ia" class="form-control blank" placeholder="Type your answer here" >
                          </div>
                          <div class="col-lg-3"></div>
                        </div>`);

      }else if(type == "True or False"){
        
        $("#main-holder").empty();
        $("#main-holder").html(`<div class="row" id="tf">
                          <div class="col-lg-3"></div>
                          <div class="col-lg-6 text-center">
                            <label class="container"><p>True</p>
                              <input type="radio" name="radio" value="true" class="tf">
                              <span class="checkmark"></span>
                            </label>
                            <label class="container"><p>False</p>
                              <input type="radio" name="radio" value="false" class="tf">
                              <span class="checkmark"></span>
                            </label>
                          </div>
                          <div class="col-lg-3"></div>
                        </div>`);
      }

      $(".q").text(question);
      $("#mc1").text(choices[0]);
      $("#mc2").text(choices[1]);
      $("#mc3").text(choices[2]);
      $("#mc4").text(choices[3]);

      $("#counter").text((count+1));

      current = type;
      result.answer.push(answer);

      //ANSWER GETTERS
      $(".abcd").on("click", function(){
        getInput(this.value);
      });

      $(".tf").on("click", function(){
        getInput(this.value);
      });

      $("#ia").on("input", function(){
        getInput(this.value);
      });
      //ANSWER GETTERS END
  }

  function getInput(answer){

      result.input[count] = answer;
      
  }

  function check(x){

    console.log(result);

    if(result.answer[x].toLowerCase() == result.input[x].toLowerCase()){
      score++;

      $(".rescont").empty();
      $(".rescont").html('<span class="alert alert-success"><i class="fas fa-check"></i> Correct!</span>');
      return "Correct";

    }else{

      $(".rescont").empty();
      $(".rescont").html('<span class="alert alert-danger"><i class="fas fa-times"></i> Wrong answer! The answer is <b>'+ result.answer[x] +'</b></span>');
      return "Wrong";

    }

  }

</script>