<?php session_start();?>

<!DOCTYPE html>
<html>
<head>

<?php
  include("session/DBConnection.php");  
    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";
?>

  <title>CAI - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php include "links.php"; ?>

</head>
<body>

  <?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include('header.php'); ?>

<div class="breadcome-area">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="breadcome-list single-page-breadcome">
              <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <div class="breadcome-heading">
                  </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <ul class="breadcome-menu">
                    <li><a href="#">Home</a> <span class="bread-slash">/</span></li>
                    <li><span class="bread-blod">Notifications</span></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<div class="container-fluid">
  <div class="row">
    <div class="col-lg-7">
      <div class="product-status-wrap">
        <h3>Logs</h3>
        <br>
        <div class="">
          <div class="sparkline8-graph">
            <div class="static-table-list">
              <table class="table">
                <thead>
                  <tr>
                    <th></th>
                    <th>Member</th>
                    <th>Date</th>
                    <th>Login</th>
                    <th>Logout</th>
                  </tr>
                </thead>
                <tbody class="logs">
                  <?php include "includes/logs.php" ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <br>
        <button class="btn btn-primary loadmore">Load More</button>
      </div>
    </div>
    <div class="col-lg-5">
      <div class="product-status-wrap animated zoomIn">
        <h3>Latest Updates</h3>
        <?php echo loadUpdates($gkey); ?>
      </div>
    </div>
  </div>
</div>

<?php include('footer.php'); ?>

<script type="text/javascript">
  
  var limit = 5;
  var id = <?php echo $display["member_id"]; ?>;

  window.onload = function(){

    $(".loadmore").on("click", function(){
      limit += 5;
      $.post("includes/logs.php", {id: id,limit: limit}, function(data, success){
        $(".logs").empty();
        $(".logs").html(data);
      });
    });

  }

</script>
