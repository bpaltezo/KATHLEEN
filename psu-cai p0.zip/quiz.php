<?php session_start();?>

<?php
  include("session/DBConnection.php");  
    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $userid = $display['member_id'];
    $gender = $display['gender'];
    $fullname = $name." ".$lastname;

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";
?>

<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php require_once("includes/functions.php"); ?>

<?php

if(isset($_POST['addnew'])){

  $conn = mysqli_connect("localhost", "root", "", "cai_it4");

}

?>

<!DOCTYPE html>
<html>
<head>

  <title>Quiz - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

  <?php include "links.php"; ?>

  <style type="text/css">
    
  </style>

</head>
<body>
  <?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include('header.php'); ?>
<div class="breadcome-area">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="breadcome-list">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="breadcome-heading">
                <?php 

                  if($type != "Student"){

                  echo '<form role="search" class="sr-input-func">
                    <input type="text" placeholder="Search..." class="search-int form-control">
                      <a href="#"><i class="fas fa-search"></i></a>
                    </form>';
                  }

                ?>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <ul class="breadcome-menu">
                <li><a href="#">Home</a> <span class="bread-slash">/</span></li>
                <li><span class="bread-blod">All Quizes</span></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<?php 
  
  if(isset($_GET['add'])){
    
    include "quiz_add.php";

  }else if(isset($_GET['view'])){

    include "quiz_view.php";
  
  }else if(isset($_GET['edit'])){

    include "quiz_edit.php";

  }else if(isset($_GET['pos']) && isset($_GET['topic']) && $type == "Student"){

    include "quiz_student.php";

  }else if(!isset($_GET['add']) && !isset($_GET['view']) && !isset($_GET['edit']) && !isset($_GET['pos'])){

     echo '<div class="courses-area">
            <div class="container-fluid">
              <div class="row">';
  }

?>

<?php

  if(!isset($_GET['view']) && !isset($_GET['add']) && !isset($_GET['edit']) && !isset($_GET['pos'])){

    echo '<div class="product-status">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="product-status-wrap">
              <h4>Your Quizes</h4>
              
              <div class="asset-inner">
                <table>
                  <thead>
                    <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Items to Answer</th>
                    <th>Attempts</th>
                    <th>Current Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>';
                    
    $query = mysql_query("SELECT * FROM quiz ") or die (mysql_error());

    $count = 0;
    while($row = mysql_fetch_array($query)){

      $quizid = $row["quiz_id"];
      $stud_id = $display["member_id"];

      $sql = "SELECT * FROM grades WHERE quiz_id='$quizid' AND stud_id='$stud_id'";
      $res = $conn->query($sql);

      $remark = "";
      $attempts = 0;
      while($row2 = $res->fetch_assoc()){
        $remark = $row2['remarks'];
        $attempts++;
      }

      echo "<tr><td>".$row['pos']."</td>";
      echo "<td>".$row['quiz_title']."</td>";
      echo "<td>10</td>";
      echo "<td>".$attempts."</td>";

      if($row['pos'] <= $display['current_quiz'] && $type == "Student"){

        if($remark == "" && $type == "Student"){
          echo "<td><i>Available</i></td>";
          echo '<td>
              <a href="quiz.php?topic&pos='.$row['quiz_id'].'"><button class="btn btn-default"><i class="fas fa-chalkboard" aria-hidden="true"></i> Take Quiz</button></a>
            </td>';
        }else if($remark == "Passed" && $type == "Student"){
          echo "<td><span class='badge-success'>Passed</span></td>";
          echo '<td>
              <a href="grades.php"><button class="btn btn-success"><i class="fas fa-check-circle" aria-hidden="true"></i> View Result</button></a>
            </td>';
        }else if($remark == "Failed" && $type == "Student"){
          echo "<td><span class='badge-danger'>Failed</span></td>";
          echo '<td>
              <a href="quiz.php?topic&pos='.$row['quiz_id'].'"><button class="btn btn-danger"><i class="fas fa-times-circle" aria-hidden="true"></i> Retake quiz</button></a>
            </td>';
        }

      }else if($row['pos'] > $display['current_quiz'] && $type == "Student"){

        echo "<td><span class='badge-default'>Locked</span></td>";
        echo '<td>
              <a href="#"><button class="btn btn-default" disabled><i class="fas fa-lock" aria-hidden="true"></i> Locked</button></a>
            </td>';

      }else if($type == "Faculty"){
        echo "<td></td>";
          echo '<td>
              <a href="quiz.php?view='.$row['quiz_id'].'"><button data-toggle="tooltip" title="Preview this quiz" class="btn btn-default"><i class="fas fa-folder-open" aria-hidden="true"></i> Preview</button></a>
            </td>';
      }

      echo "</tr>";
      $count++;
    }

    if($count == 0) echo "<tr><td colspan='8'><center>You have no quizes to manage</center></td></tr>";
                    
    echo '</tbody>
                </table>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>';
   
  }

?>

<?php
  if(!isset($_GET['view']) && !isset($_GET['add']) && !isset($_GET['edit'])) echo "</div></div></div>";
?>

<br><br>


<?php include('footer.php'); ?>
