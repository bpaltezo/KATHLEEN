<?php

  $pemail = GetMemberEmailByName($display['instructor']);
  $pimage = GetMemberImageByName($display['instructor']);
  $pcurrentquiz = 0;

  if($pimage == "") $pimage = "uploads/propicf.png";

	$sql = "SELECT * FROM quiz";
	$res = $conn->query($sql);

  $quizid = "";
  $x = 0;

	while($row = $res->fetch_assoc()){
	  if($x == $pcurrentquiz){
      $quizid = $row['quiz_id'];
    }
    $x++;
  }

?>

<div class="container-fluid">

<div class="row">
<div class="col-lg-12">
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="lessons.php">
            <div class="social-media-edu">
                <i class="fas fa-print fa-4x" style="color:#42f4df;"></i>
                <div class="social-edu-ctn">
                    <h3 style="color:cyan;">Printables</h3>
                    <p>Take your lessons</p>
                </div>
            </div>
            </a>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="tutorial.php">
            <div class="social-media-edu">
                <i class="fas fa-play-circle fa-4x" style="color:#6995f4;"></i>
                <div class="social-edu-ctn">
                    <h3 style="color:darkblue;">Tutorials</h3>
                    <p>Watch Tutorials</p>
                </div>
            </div>
            </a>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="grades.php">
            <div class="social-media-edu">
                <i class="fas fa-award fa-4x" style="color:#ffae75;"></i>
                <div class="social-edu-ctn">
                    <h3 style="color:orange;">Grades</h3>
                    <p>Check your Grades</p>
                </div>
            </div>
            </a>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <a href="groups.php?res=student&view=<?php echo $gkey; ?>">
            <div class="social-media-edu">
                <i class="fas fa-users fa-4x" style="color:#b075ff;"></i>
                <div class="social-edu-ctn">
                    <h3 style="color:violet;">Groups</h3>
                    <p>See latest updates</p>
                </div>
            </div>
            </a>
        </div>
    </div>
</div>
</div>

<br>

<style type="text/css">
  .d-block{
    height: 300px;
  }
</style>

<div class="row">

	<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
  
  <div class="single-review-st-item res-mg-t-30 table-mg-t-pro-n">
   	<div class="single-review-st-hd">
      <h2 style="color:darkblue;">Your Instructor</h2>
    </div>
    <div class="single-review-st-text">
      <img src="<?php echo $pimage; ?>" alt="Profile Image">
      <div class="review-ctn-hf">
        <h3><?php echo $fac_name; ?></h3>
        <a href="message.php?compose&sendto=<?php echo $pemail; ?>"><button class="btn btn-default"><i class="fas fa-envelope"></i> Message</button></a>
      </div>
      <div class="review-item-rating"></div>
   	</div>
  </div>

	</div>

</div>

</div>

<script type="text/javascript">
	window.onload = function(){
		$('.carousel').carousel();
	}
</script>

