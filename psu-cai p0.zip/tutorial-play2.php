<!DOCTYPE html>
<html>
<head>
	<title>Tutorial</title>
	<style type="text/css">
		*{
			margin: 0;
			padding: 0;
		}
		video{
			width: 100%;
			height: 100%;
		}
	</style>
</head>
<body>
<video controls autoplay="autoplay" src="<?php echo 'admin/'.$_GET['source']; ?>"></video>
</body>
</html>