<?php 
$sql = "SELECT * FROM quiz WHERE quiz_id=".$_GET['view'];
    $res = $conn->query($sql);

    $title = "";
    $desc = "";
    
    $ch = "";
    $iden = "";
    $tf = "";

    $count = 0;
    $content = "";

    while($row = $res->fetch_assoc()){
      $title = $row['quiz_title'];
      $desc = $row['quiz_description'];
      $total = $row['item_student'];
    }

    $sql2 = "SELECT * FROM questions WHERE quiz_id=".$_GET['view'];
    $res2 = $conn->query($sql2);

    while($row = $res2->fetch_assoc()){
      
      $count++;
      $q = $row['questions_question'];
      $qid = $row['questions_id'];

      $xsql = "SELECT * FROM answers WHERE questions_id='$qid' ";
      $xres = $conn->query($xsql);

      while($row2 = $xres->fetch_assoc()){
        $ans = $row2['correct'];
        $c1 = $row2['choice1'];
        $c2 = $row2['choice2'];
        $c3 = $row2['choice3'];
        $c4 = $row2['choice4'];
      }

      if($row['questions_type'] == "Multiple Choice"){
        
        $content .= '<p>Question #: <b>'.$count.'</b>/'.$total.'</p>

                      <div class="card" style="width: 80%;margin-left: 10%;">
                        <div class="card-body text-center">
                          <h5 class="card-title">'.$q.'</h5>
                          <br><br>
                          <div class="row">
                            <div class="col-lg-3"></div>
                            <div class="col-lg-6 text-left">
                              <label class="container"><p>A. '.$c1.'</p>
                                <input type="radio" name="radio">
                                <span class="checkmark"></span>
                              </label>
                              <label class="container"><p>B. '.$c2.'</p>
                                <input type="radio"  name="radio">
                                <span class="checkmark"></span>
                              </label>
                              <label class="container"><p>C. '.$c3.'</p>
                                <input type="radio" name="radio">
                                <span class="checkmark"></span>
                              </label>
                              <label class="container"><p>D. '.$c4.'</p>
                                <input type="radio" name="radio">
                                <span class="checkmark"></span>
                              </label>
                            </div>
                            <div class="col-lg-3"></div>
                          </div>
                        </div></div><br><br>';
                  # <a href="#" class="btn btn-primary" style="float: right;">Next Question</a>

      }else if($row['questions_type'] == "Identification"){

        $content .= '<p>Question #: <b>'.$count.'</b>/'.$total.'</p>

                    <div class="card" style="width: 80%;margin-left: 10%;">
                      <div class="card-body text-center">
                        <h5 class="card-title">'.$q.'</h5>
                        <br><br>
                        <div class="row">
                          <div class="col-lg-3"></div>
                          <div class="col-lg-6 text-left">
                          <input type="text" name="" class="form-control blank" placeholder="Type your answer here" >
                          </div>
                          <div class="col-lg-3"></div>
                        </div>
                      </div>
                    </div>
                    </div></div><br><br>';
                    #<a href="#" class="btn btn-primary" style="float: right;">Next Question</a>
      
      }else if($row['questions_type'] == "True or False"){
        
        $content .= '<p>Question #: <b>'.$count.'</b>/'.$total.'</p>

                      <div class="card" style="width: 80%;margin-left: 10%;">
                        <div class="card-body text-center">
                          <h5 class="card-title">'.$q.'</h5>
                          <br><br>
                          <div class="row">
                            <div class="col-lg-3"></div>
                            <div class="col-lg-6 text-left">
                              <label class="container"><p>True</p>
                                <input type="radio" name="radio">
                                <span class="checkmark"></span>
                              </label>
                              <label class="container"><p>False</p>
                                <input type="radio"  name="radio">
                                <span class="checkmark"></span>
                              </label>
                            </div>
                            <div class="col-lg-3"></div>
                          </div>
                        </div></div><br><br>';
                        #<a href="#" class="btn btn-primary" style="float: right;">Next Question</a>

      }
    }

?>

<div class="blog-details-area mg-b-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="blog-details-inner">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="latest-blog-single blog-single-full-view">
                                <div class="blog-image">
                                    <div class="blog-date">
                                        <p>
                                            <span class="blog-day"><?php echo date('d'); ?></span> 
                                            <?php echo date("M") ?>
                                        </p>
                                    </div>
                                </div>
                                <div style="margin-left: 7%;margin-top:-2%;">
                                    <h1><a class="blog-ht" href="#"><?php echo $title; ?></a></h1>
                                </div>
                                <div class="blog-details blog-sig-details">
                                    <div class="details-blog-dt blog-sig-details-dt courses-info mobile-sm-d-n">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                    
                                    <h3 class="text-center"><?php echo $desc; ?></h3>

                                    <br><br><br>

                                    <?php echo $content; ?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>

               </div>
            </div>
        </div>
    </div>
</div>
