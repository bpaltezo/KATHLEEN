<?php session_start();?>

<!DOCTYPE html>
<html>
<head>

<?php
  include("session/DBConnection.php");  
    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";
?>

  <title>CAI - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php include "links.php"; ?>

</head>
<body>

  <?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include('header.php'); ?>

<div class="breadcome-area">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="breadcome-list single-page-breadcome">
              <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <div class="breadcome-heading">
                  </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <ul class="breadcome-menu">
                    <li><a href="#">Home</a> <span class="bread-slash">/</span></li>
                    <li><span class="bread-blod">Syllabus</span></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<div class="container-fluid">
  <div class="pdf-viewer-area mg-b-15">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"></div>
        <div class="col-lg-12 col-md-8 col-sm-8 col-xs-8">
          <div class="pdf-single-pro">
            <a class="media" href="br/syllabus.pdf"></a>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2"></div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
  window.onload = function(){
    $('a.media').media({width:1000, height:950});
  }
</script>

<!--
<div class="container-fluid">

  <div class="row">

  <div class="col-lg-10">

     <div class="text-center">
    <p>Republic of the Philippines</p>
    <h4>PANGASINAN STATE UNIVERSITY</h4>
    <p>Lingayen, Pangasinan</p>
    <br>

    <h4>COLLEGE of COMPUTING SCIENCES</h4>
    <p>Second Semester A.Y. 2015-2016</p>
    <br><br>

    </div>

    <b>VISION</b>
    <p>To become an ASEAN premier state university in 2020.</p>
    <br>

    <b>MISSION</b>
    <p>The Pangasinan State University, through instruction, research, extension and production commits to develop highly principled morally upright, innovative and globally competent individuals capable of meeting the needs of industry, public service and civil society.</p>
    <br>

    <b>INSTITUTIONAL  LEARNING OUTCOMES</b>
    <br>
    <p style="text-indent: 30px;">The Pangasinan State University Institutional Learning Outcomes (PSU ILO) are the qualities that PSUnians must possess. These outcomes are anchored on the following core values: Accountability and Transparency, Credibility and Integrity, Competence and Commitment to Achieve, Excellence in Service Delivery, Social and Environmental Responsiveness, and Spirituality – (ACCESS). Anchored on these core values, the PSU graduates are able to:</p><br>

    <ol style="list-style:upper-alpha;">
      <li> demonstrate through institutional mechanisms, systems, policies, and processes which are reflective of transparency, equity, participatory decision making, and accountability;</li>
      <li>engage in relevant, comprehensive and sustainable development initiatives through multiple perspectives in decisions and actions that build personal and professional credibility and integrity;</li>
      <li> set challenging goals and tasks with determination and sense of urgency which provide continuous improvement and producing quality outputs leading to inclusive growth;</li>
      <li>exhibit life-long learning and global competency proficiency in communication skills, inter/interpersonal skills, entrepreneurial skills, innovative mind set, research and production initiatives and capability in meeting the industry requirements of local, ASEAN and international human capital market through relevant and comprehensive programs;</li>
      <li> display, socially and environmentally responsive organizational culture, which ensures higher productivity among the university constituents and elevate the welfare of the multi-sectoral communities and;</li>
      <li>practice spiritual values and morally upright behaviour which promote and inspire greater harmony to project a credible public image.</li>
    </ol>

    <br>
    <b>PROGRAM OUTCOMES</b>
    <br>
    <table cellpadding="15">
      <tbody>
      <tr>
        <td><b>Graduate Attributes</b></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td><b>BS Mathematics Program Outcomes (PO)</b> (based from CHED)<br>Graduates of the BS Mathematics programs is committed to produce graduates who:</td>
      </tr>
      <tr>
        <td><b>Subject Specialist</b></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td>a.  Gained mastery in the core areas of mathematics: algebra, analysis, geometry;</td>
      </tr>
       <tr>
        <td><b>Independent & Critical Thinkers</b></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td>b.  Demonstrate skills in pattern recognition, generalization, abstraction, critical analysis, problem solving and rigorous argument;</td>
      </tr>
       <tr>
        <td><b>Adaptive</b> </td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td>c.  Develop and enhance perception of the vitality and importance of mathematics in the modern world including inter-relationship within math and its connection to other disciplines;</td>
      </tr>
       <tr>
        <td><b>Independent</b> </td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td>d.  Make and evaluate mathematical conjectures and arguments and validate their own mathematical thinking;</td>
      </tr>
       <tr>
        <td><b>Well-rounded</b> </td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td>e.  Appreciate the concept  and role of proof and reasoning and demonstrate knowledge in reading and writing mathematical proof;</td>
      </tr>
       <tr>
        <td><b>Ethically Aware</b> </td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td>f.  Law-abiding, morally upright and sensitive to their social responsibilities;</td>
      </tr>
       <tr>
        <td><b>Socially aware</b> </td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td>g.  Demonstrate competencies that are beyond the needs and requirements of the community;</td>
      </tr>
       <tr>
        <td><b>Confident & effective communicators </b></td>
        <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td>h.  Communicate mathematical ideas orally and in writing using clear and precise language.</td>
      </tr>
      </tbody>
    </table>

    <br><br>
    <div class="text-center"><b>COURSE INFORMATION</b></div>
    <table>
      <thead>
        <tr>
          <td><b>Course Code</b>: Math 130.1</td>
          <td><b>Course Title</b>: Discrete Mathematics</td>
          <td><b>Lecture</b>: 3 units</td>
          <td><b>Laboratory</b>: None </td>
          <td><b>Credit Units</b>: 3</td>
        </tr>
      </thead>
      <br>
      <tbody>
        <tr>
          <td colspan="5">
            <b>Course Description:</b><br>
             This course deals with abstract mathematical structures used to represent discrete objects and relationships between these objects. It instructs students on mathematical principles used in computer applications. It course covers the fundamentals of logic and sets, the fundamental principles of counting, relations, algorithms, boolean algebra and combinatorial circuits.<br>
At the end of this course, students are expected to gain working knowledge of set theory, mathematical induction, relations, functions, boolean algebra and combinatorial circuits and see how these topics are applied to computer applications.

          </td>
        </tr>
        <tr>
          <td><b>Course Prerequisite</b>: Math 121, Stat 101  </td>
          <td><b>Course Schedule</b>:  Tuesday and Friday</td>
          <td><b>Time</b> :   2:30 – 4:00 p.m. </td>
        </tr>
      </tbody>
    </table>

  </div>

  <div class="col-lg-2">
    <img src="images/logo.png" width="120" height="120">
  </div>

  </div>

</div>
-->

<?php include('footer.php'); ?>
