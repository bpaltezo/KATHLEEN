<?php ob_start(); session_start(); ?>
<?php
$no_visible_elements=false;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>

  <link rel="shortcut icon" HREF="images/logo.png" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <link href="style.css" rel="stylesheet" type="text/css" />
  <link href="home.css" rel="stylesheet" type="text/css" />
  <!-- The styles -->

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style type="text/css">
    body {
    padding-bottom: 40px;
    }
    .sidebar-nav {
    padding: 9px 0;
    }
  </style>
  <link href="css/bootstrap-responsive.css" rel="stylesheet">
  <link href="css/charisma-app.css" rel="stylesheet">
  <link href="css/jquery-ui-1.8.21.custom.css" rel="stylesheet">
  <link href='css/fullcalendar.css' rel='stylesheet'>
  <link href='css/fullcalendar.print.css' rel='stylesheet'  media='print'>
  <link href='css/chosen.css' rel='stylesheet'>
  <link href='css/uniform.default.css' rel='stylesheet'>
  <link href='css/colorbox.css' rel='stylesheet'>
  <link href='css/jquery.cleditor.css' rel='stylesheet'>
  <link href='css/jquery.noty.css' rel='stylesheet'>
  <link href='css/noty_theme_default.css' rel='stylesheet'>
  <link href='css/elfinder.min.css' rel='stylesheet'>
  <link href='css/elfinder.theme.css' rel='stylesheet'>
  <link href='css/jquery.iphone.toggle.css' rel='stylesheet'>
  <link href='css/opa-icons.css' rel='stylesheet'>
  <link href='css/uploadify.css' rel='stylesheet'>
  <link rel="stylesheet" type="text/css" href="fonts/fa/css/all.css">
  <script type="text/javascript" src="fonts/fa/js/all.js"></script>
  <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
  <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->

  <!-- The fav icon -->
  <link rel="shortcut icon" href="images/favicon2.ico">

  <style type="text/css">
    body{
      background: url("images/slider2.jpg");
      background-size:cover;
      background-repeat: no-repeat;
      background-position: right;
    }

    footer {
   position:fixed;
   left:0px;
   bottom:0px;
   height:30px;
   width:100%;
   background:rgba(0,0,0,0);
   color:white;
}

  </style>
    
</head>

<body>

  <br><br><br><br><br><br><br><br><br>

  <?php if(!isset($no_visible_elements) || !$no_visible_elements) { ?>
    
  <?php } ?>

			<div class="container-fluid">
				<div class="well col-lg-6 center login-box">

          <div class="container-fluid">
          <img src="images/logo.png" width="75" height="75">
        <div class="span12 center login-header">
          <h2>Welcome to <br>Computer Aided Instruction System</h2>
        </div><!--/span-->
      </div><!--/row-->
      <br>
			<div class="alert alert-info">
						Please login with your Username and Password.
					</div>

					<?php
      require_once("session/DBConnection.php");
    if (isset($_POST['login'])) 
    { 
  
    $username = $_POST['username'];     
    $password = $_POST['password'];
  
    $result = mysql_query("SELECT * FROM members
        WHERE ((`members`.`username` = '$username') AND (`members`.`password` = '$password'))");
    $data =  mysql_fetch_array($result);

        if(!$result){
          die("Query to show fields from table failed");
        }
          
        $numberOfRows = MYSQL_NUMROWS($result);

        if($numberOfRows == 0){
              echo '
              <div class="alert alert-error">
						Please check your Username and Password Correctly and Try Again!.
					</div>
              ';
            
        }else if ($numberOfRows > 0){

          if($data['confirmation'] == 0){
            echo '
              <div class="alert alert-error">
            Account subject for approval!
              </div>
              ';
          }else{

            session_register('is');
            $_SESSION['log']['login'] = TRUE;
            $_SESSION['log']['username'] = $_POST['username'];
            $session = "1"; 
        
            $query = mysql_query("SELECT * FROM members WHERE username = '$username'") or die (mysql_error()); 
            $display = mysql_fetch_array($query);
            $memberid = $display['member_id'];
            $image = $display['image'];
            $type = $display['type'];
            $faculty = $display['instructor'];
            $key = $display['group_key'];
            $insert = "INSERT INTO users SET username = '$username', password = '$password', usertype = '$type', session_id= '', created_date = CURRENT_TIMESTAMP, modified_date = '0000-00-00 00:00:00', image = '$image', faculty_name='$faculty', group_key = '$key'";
            $add_member = mysql_query($insert);

            date_default_timezone_set("Asia/Manila");

            $timein = date("h:i:s a");
            $datein = date("M d");
        
            $type= $display['type'];
            if ($type=="Admin"){
              header("location:admin.php");
            }else{

              $sql = "INSERT INTO logs SET memberid='$memberid', timein='$timein', datein='$datein', gkey='$key' ";
              $res = mysql_query($sql);

              header("location:home.php");
            }

          }
        }
      }
?>
					
					<form id="login-form" class="block-content form" action="login.php" method="post">
						<fieldset>
							<div class="form-group" title="Username" data-rel="tooltip">
								<span class="form-group-addon"><i class="fas fa-user-circle" style="color: darkblue;"></i></span> <input autofocus class="required" name="username" type="text" require autocomplete="off" />
							</div>
							<div class="clearfix"></div>

							<div class="input-prepend" title="Password" data-rel="tooltip">
								<span class="add-on"><i class="fas fa-lock" style="color: darkblue;"></i></span> <input class="required" name="password" type="password" autocomplete="off" />
							</div>
							<div class="clearfix"></div>

						  <div class="clearfix"></div>
					
							<button type="submit" class="btn btn-large btn-primary" name="login"><i class="icon-ok"></i>
               Login
             </button>
							
						</fieldset>
					</form>

          or<br> Register as
          <br>

          <div class="row-fluid">
            <div class="span6">
              <button class="btn btn-success"><a href="student_reg.php" style="color:#fff;"><i class="fas fa-user-graduate"></i> Student</a></button>
            </div>
            <div class="span6">
              <button class="btn btn-warning"><a href="instruc_reg.php" style="color:#fff;"><i class="fas fa-user-graduate"></i> Faculty</a></button>
            </div>     
          </div>

				</div><!--/span-->

			</div>
<!--/row-->

         

  <!-- JavaScript at the bottom for fast page loading -->

  <!-- Grab Google CDN's jQuery, with a protocol relative URL; fall back to local if offline -->
  <script>window.jQuery || document.write('<script src="js/libs/jquery-1.6.2.min.js"><\/script>')</script>


  <!-- scripts concatenated and minified via ant build script-->
  <script defer src="js/plugins.js"></script> <!-- lightweight wrapper for consolelog, optional -->
  <script defer src="js/mylibs/jquery.notifications.js"></script> <!-- Notifications  -->
  <script defer src="js/mylibs/jquery.uniform.min.js"></script> <!-- Uniform (Look & Feel from forms) -->
  <script defer src="js/mylibs/jquery.validate.min.js"></script> <!-- Validation from forms -->
  <script defer src="js/mylibs/jquery.tipsy.js"></script> <!-- Tooltips -->
  <script defer src="js/common.js"></script> <!-- Generic functions -->
  
  <script type="text/javascript">
	$().ready(function() {
		
		/*
		 * Validate the form when it is submitted
		 */
		var validatelogin = $("#login-form").validate({
			invalidHandler: function(form, validator) {
      			var errors = validator.numberOfInvalids();
      			if (errors) {
        			var message = errors == 1
			          ? 'You missed 1 field. It has been highlighted.'
			          : 'You missed ' + errors + ' fields. They have been highlighted.';
        			$('#login-form').removeAlertBoxes();
        			$('#login-form').alertBox(message, {type: 'error'});
        			
      			} else {
       			 	$('#login-form').removeAlertBoxes();
      			}
    		}
		});
		
		jQuery("#reset-login").click(function() {
			validatelogin.resetForm();
		});
				
	});
  </script>
  <br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php include('footer.php'); ?>
