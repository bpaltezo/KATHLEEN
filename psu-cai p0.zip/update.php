<?php

date_default_timezone_set("Asia/Manila");

$userid = $_POST["uid"];
$gkey = $_POST["gkey"];
$id = $_POST["id"];

$conn = mysqli_connect("localhost", "root", "", "cai_it4");

$updateDate = date("D M d Y h:i:s");

$sql3 = "INSERT INTO updates (member_id, status, image, friend, dt) VALUES ('$userid', 'Added a new quiz', '$id', '$gkey', '$updateDate') ";
$res3 = $conn->query($sql3);

?>