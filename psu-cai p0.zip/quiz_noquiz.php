<?php session_start();?>

<?php
  include("session/DBConnection.php");  
    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $userid = $display['member_id'];
    $gender = $display['gender'];
    $fullname = $name." ".$lastname;

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";
?>

<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php require_once("includes/functions.php"); ?>

<!DOCTYPE html>
<html>
<head>

  <title>CAI - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

  <?php include "links.php"; ?>

</head>
<body>

<?php include "header.php"; ?>
<br>
<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
    <div class="alert-icon shadow-inner wrap-alert-b">
        <div class="alert-title">
        
        </div>
        <div class="alert alert-info alert-st-two alert-st-bg1" role="alert">
            <i class="fa fa-info-circle edu-inform admin-check-pro admin-check-pro-clr1" aria-hidden="true"></i>
            <p class="message-mg-rt"><strong>Heads up!</strong> There are no new quiz available yet. You will be notified if there is a new quiz. <br><a href="lessons.php?pos=<?php echo ($_GET['pos']); ?>">Go to last topic here</a> or <a href="home.php">Go back to Home</a></p>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>

