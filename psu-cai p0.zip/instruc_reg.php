<?php session_start(); ?>
<!DOCTYPE html>

<?php
  
  include('session/DBConnection.php');
  #include "includes/functions.php";
                    
  if(isset($_POST['register'])){ 
    if(!$_POST['username']|
        !$_POST['password']|
        !$_POST['firstname']|
        !$_POST['lastname']|
        !$_POST['email']|
        !$_POST['gender']){

      die('Please complete all the required feilds!');
    }
     
    if(!get_magic_quotes_gpc()){
      $_POST['username'] = addslashes($_POST['username']);
    }
             
    $usercheck = $_POST['username'];
    $check = mysql_query("SELECT * FROM members WHERE username = '$usercheck'") or die(mysql_error());
    $check2 = mysql_num_rows($check);
    
    if ($check2 != 0) {
      die('Sorry, the username '.$_POST['username'].' is already in use!' . " " . 'or' .  " " .'INVALID          username!<br />'. " " . " " .'Please try another username..' );
    }
            
    if(!get_magic_quotes_gpc()){
      $xidcheck = addslashes($_POST['username']);
    }
    
    $idcheck = $xidcheck;
    $check3 = mysql_query("SELECT * FROM members WHERE id_no = '$idcheck'") or die(mysql_error());
    $check4 = mysql_num_rows($check3);
             
    if($check4 != 0){
      die('Sorry, the ID No.  '.$_POST['id_no'].' is already in use!' . " " . 'or' .  " " .'INVALID          ID No.!<br />'. " " . " " .'Please try again..' );
    }
  
    $_POST['password'] = ($_POST['password']);
    $_POST['gender'] = ($_POST['gender']);
    
    $type = "Faculty";
  
    if(!get_magic_quotes_gpc()){
      $_POST['password'] = addslashes($_POST['password']);
      $_POST['username'] = addslashes($_POST['username']);
    }

    if($_POST['gender'] == "Male"){
      $propic = "uploads/propicm.png";
    }else if($_POST['gender'] == "Female"){
      $propic = "uploads/propicf.png";
    }

    $conn = mysqli_connect("localhost", "root", "", "cai_it4");

    $key = $_POST['key'];
    $gname = "";
    $prof = $_POST['firstname']." ".$_POST['lastname'];
    $sql = "SELECT * FROM groups WHERE group_key='$key'";
    $res = $conn->query($sql);
    while($row = $res->fetch_assoc()){
      $gname = $row["group_name"];
    } 

    $sql = "UPDATE groups SET faculty_name='$prof' WHERE group_key='$key'";
    $res = $conn->query($sql);

    $insert = "INSERT INTO members SET username='$_POST[username]', password='$_POST[password]', firstname='$_POST[firstname]', lastname='$_POST[lastname]', email='$_POST[email]', address='', birthdate='', b_month='', b_day='', b_year='', gender='$_POST[gender]', type='$type', id_no='$_POST[username]', image='$propic', confirmation='1', group_key='$_POST[key]', contact_no=''";
  
    $add_member = mysql_query($insert);

    if($add_member){
      echo "<script type='text/javascript'>
        alert('Account Registered!');
        window.location = 'admin/accounts.php';
      </script> ";
    }else{
      echo "<script type='text/javascript'>
      alert('Unable to Register!');
    </script> ";
    }

  exit();
  exit();

  }

 ?>

<html>
<head>
  <title>Register</title>
  <meta name="description" content="">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon2.ico">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.print.min.css">
    <link rel="stylesheet" href="css/form/all-type-forms.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>

    <style type="text/css">
      body{
        background:url("images/slider2.jpg");
        background-size: auto;
        background-repeat: no-repeat;
        background-position: center;
        background-blend-mode: soft-light;
      }
    </style>

</head>
<body>

<div class="error-pagewrap">
    <div class="error-page-int">
      
      <div class="content-error">
        <div class="hpanel">
          <div class="panel-body">
            <div class="text-center custom-login">
              <h3>Registration</h3>
            </div>
            
            <form action="instruc_reg.php" method="post" id="loginForm">
              <div class="row">
                <div class="form-group col-lg-12">
                  <label>Username</label>
                  <input class="form-control" name="username" autocomplete="off" required>
                </div>
                <div class="form-group col-lg-12">
                  <label>Password</label>
                  <input type="password" class="form-control" name="password" autocomplete="off" required>
                </div>
              </div>
              <div class="row">
                <div class="form-group col-lg-12">
                  <label>Handling Section</label>
                  <select class="form-control" name="key">
                    <option></option>
                    <?php

                      $conn = mysqli_connect("localhost", "root", "", "cai_it4");
                      $sql = "SELECT * FROM groups WHERE faculty_name='' ORDER BY group_name ASC";
                      $res = $conn->query($sql);

                      while($row = $res->fetch_assoc()){
                        echo "<option value='".$row['group_key']."'>";
                        echo $row['group_name'];
                        echo "</option>";
                      }

                    ?>
                  </select>
                </div>
                <div class="form-group col-lg-12" style="display: none;">
                  <label>Handling Section</label>
                  <div class="input-group custom-go-button">
                    <input type="hidden" class="form-control gkey" readonly required name="gkey">
                    <input type="text" class="form-control gname" readonly required name="gname">
                    <span class="input-group-btn">
                      <button type="button" class="btn btn-primary addModal" data-toggle="modal" data-target="#Modalx">Get Key</button>
                    </span>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="form-group col-lg-6">
                  <label>First Name</label>
                  <input class="form-control" name="firstname" autocomplete="off" required>
                </div>
                <div class="form-group col-lg-6">
                  <label>Last Name</label>
                  <input class="form-control" name="lastname" autocomplete="off" required>
                </div>
                <div class="form-group col-lg-6">
                  <label>E-mail</label>
                  <input type="email" class="form-control" name="email" autocomplete="off" required>
                </div>
                <div class="form-group col-lg-6">
                  <label>Gender</label>
                  <select class="form-control" name="gender" required>
                    <option></option>
                    <option>Male</option>
                    <option>Female</option>
                  </select>
                </div>

              </div>

              <input type="hidden" name="register" value="true" >
              
              <div class="text-center">
                <button class="btn btn-success loginbtn">Register</button>
                <button type="button" class="btn btn-default" onclick="window.location.href = 'admin/accounts.php'; " >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="text-center login-footer">
        <p>Copyright © 2018. All rights reserved. Template by <a href="https://colorlib.com/wp/templates/">Colorlib</a></p>
      </div>
    </div>
  </div>

<div id="Modalx" class="modal modal-edu-general default-popup-PrimaryModal fade" role="dialog" style="display: none;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-close-area modal-close-df">
        <a class="close" data-dismiss="modal" href="#"><i class="fas fa-times"></i></a>
      </div>
          
        <div class="modal-body">
          <div class="row">
            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
              <div class="breadcome-headin">
                  <label>Section Key</label>
                  <input type="text" class="form-control mgkey" value="" readonly >
                  <br>
                  <label>Section Name</label>
                  <input type="text" class="form-control mgname" autocomplete="off" required>
                  <br>
                  <input type="hidden" name="add">
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button data-dismiss="modal" class="btn btn-default" >Cancel</button>
          <button data-dismiss="modal" class="btn btn-success createGroupBtn" >Create</button>
        </div>

    </div>
  </div>
</div>

    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery-price-slider.js"></script>
    <script src="js/jquery.meanmenu.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
    <script src="js/metisMenu/metisMenu.min.js"></script>
    <script src="js/metisMenu/metisMenu-active.js"></script>
    <script src="js/tab.js"></script>
    <script src="js/icheck/icheck.min.js"></script>
    <script src="js/icheck/icheck-active.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">

      function passwordStrength(password){
        var desc = ["Very Weak", "Weak", "Better", "Medium", "Strong", "Strongest"];
        var score   = 0;

        //if password bigger than 6 give 1 point
        if (password.length > 6) score++;

        //if password has both lower and uppercase characters give 1 point      
        if ( ( password.match(/[a-z]/) ) && ( password.match(/[A-Z]/) ) ) score++;

        //if password has at least one number give 1 point
        if (password.match(/\d+/)) score++;

        //if password has at least one special caracther give 1 point
        if ( password.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/) ) score++;
        
        //if password bigger than 12 give another 1 point
        if (password.length > 12) score++;

        document.getElementById("passwordDescription").innerHTML = desc[score];
        document.getElementById("passwordStrength").className = "strength" + score;
      }

    </script>

    <script type="text/javascript">
  
  window.onload = function(){

    $(".addModal").on("click", function(){
      $(".mgkey").val(function(){
        var letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i"];
        var numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
        var result = "";
        for(var x=0;x<3;x++){
          var Lidx = Math.random()*9;
          var Nidx = Math.random()*9;
          console.log(Math.floor(Lidx), Math.floor(Nidx));

          result += letters[Math.floor(Lidx)];
          result += numbers[Math.floor(Nidx)];
        }
        return result;
      });
    });

    $(".createGroupBtn").on("click", function(){
      $(".gkey").val($(".mgkey").val());
      $(".gname").val($(".mgname").val());
    });

  }

</script>

</body>
</html>