<?php

include "includes/connection.php";

$id = $_POST['id'];
$username = $_POST['username'];
$password = $_POST['password'];

$sql = "UPDATE members SET username='$username', password='$password' WHERE member_id='$id' ";
$res = $conn->query($sql);

if($res){
	header("Location: profile.php");
}else{
	echo "error";
}

?>