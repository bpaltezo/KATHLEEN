<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
	<?php
	include("session/DBConnection.php");
		$user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $current_lesson = $display['current_lesson'];
    $current_quiz = $display['current_quiz'];
    $fullname = $name." ".$lastname;
    $userid = $display['member_id'];

    if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";

?>

<?php

    date_default_timezone_set("Asia/Manila");
    $conn = mysqli_connect("localhost", "root", "", "cai_it4");

    if(isset($_POST['reciever']) && isset($_POST['content'])){

        $reciever = $_POST['reciever'];
        $content = $_POST['content'];

        $date = date("D M d Y h:i:s");

        $sql = "INSERT INTO messages (sender, recipient, content, status, date_sent) VALUES ('$fullname', '$reciever', '$content', 'unseen', '$date')";
        $res = $conn->query($sql);

        if($res){
            echo "<script>alert('Message Sent!');window.location = 'message.php?inbox';</script>";
            #header("Location: message.php?inbox");
        }else{
            echo "<script>alert('Unable to send message right now!');</script>";
        }

    }

    if(isset($_GET['delete'])){

        $sql = "DELETE FROM messages WHERE message_id=".$_GET['message'];
        $res = $conn->query($sql);

        if($res){
            header("Location: message.php?inbox");
        }
    }

?>



<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php include "includes/functions.php"; ?>

	<title>Messages - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/fa/css/all.css">
    <link rel="stylesheet" type="text/css" href="fonts/googlefonts.css">
    <script type="text/javascript" src="fonts/fa/js/all.js"></script>
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/educate-custon-icon.css">
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
    <link rel="stylesheet" href="css/summernote/summernote.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.print.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    <style type="text/css">
        .iblue{color:#3E24B9;}
        .badge{
            background-color:rgba(255,0,0,0.9);
            margin-top:-200%;
            margin-left:-200%;
        }
    </style>

</head>
<body>

<?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include "header.php"; ?>

<div class="breadcome-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcome-list single-page-breadcome">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"></div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <ul class="breadcome-menu">
                                <li><a href="#">Home</a> <span class="bread-slash">/</span></li>
                                <li><span class="bread-blod">Messages</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(isset($_GET['inbox'])) include "parts/inbox.php"; ?>
<?php if(isset($_GET['compose'])) include "parts/compose.php"; ?>
<?php if(isset($_GET['read'])) include "parts/read.php"; ?>
<?php if(isset($_GET['sent'])) include "parts/sent.php"; ?>
<?php if(isset($_GET['trash'])) include "parts/trash.php"; ?>

<?php include "footer.php"; ?>