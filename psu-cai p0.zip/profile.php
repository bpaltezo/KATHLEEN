<?php
  session_start();
  include("session/DBConnection.php");  
    $user = $_SESSION['log']['username'];
    $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
    $display = mysql_fetch_array($query); 
    $type = $display['type'];
    $name = $display['firstname'];
    $lastname = $display['lastname'];
    $pix = $display['image'];
    $fac_name = $display['instructor'];
    $gkey = $display['group_key'];
    $fullname = $display['firstname']." ".$display['lastname'];

    //if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";
?>

<!DOCTYPE html>
<html>
<head>

  <title>Profile - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php require_once("includes/functions.php"); ?>

  <?php include "links.php"; ?>

</head>
<body>

<?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include('header.php'); ?>

<br>
<!-- Single pro tab review Start-->
        <div class="single-pro-review-area mt-t-30 mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="" style="float: right;">
                            <a href="profile_delete_photo.php?id=<?php echo $display['member_id'] ?>" class="btn btn-default">&times;</a>
                        </div>
                        <div class="profile-info-inner">
                            <div class="profile-img">
                                <img src="<?php echo $pix; ?>" alt=" Click here to upload photo" id="profile-image" width="100%" height="300" />
                                <form method="post" action="upload.php" enctype="multipart/form-data">
                                    <input type="file" name="uploadimg" id="uploadimg" style="display: none;" />
                                    <input type="text" name="id" value="<?php echo $display['member_id']; ?>" style="display: none;" />
                                    <input type="submit" id="uploadimgbtn" style="display: none;" />
                                </form>
                            </div>
                            <div class="profile-details-hr">
                                <div class="row">
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                                        <div class="address-hr">
                                            <p><b>Name</b><br /> <?php echo $fullname ?></p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                                        <div class="address-hr tb-sm-res-d-n dps-tb-ntn">
                                            <p><b>School ID</b><br /> <?php echo $display['id_no'] ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                                        <div class="address-hr">
                                            <p><b>E-mail</b><br /> <?php echo $display['email'] ?></p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                                        <div class="address-hr tb-sm-res-d-n dps-tb-ntn">
                                            <p><b>Phone</b><br /> <?php echo $display['contact_no'] ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="address-hr">
                                            <p><b>Address</b><br /> <?php echo $display['address'] ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                        <div class="address-hr">
                                            
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                        <div class="address-hr">
                                            <a href="#"><i class="fas fa-users"></i></a>
                                            <h3><?php if($display['type'] == "Faculty"){echo getTotalMembers($gkey);} ?></h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                        <div class="address-hr">
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <div class="product-payment-inner-st res-mg-t-30 analysis-progrebar-ctn">
                            <ul id="myTabedu1" class="tab-review-design">
                                <li class="<?php if(!isset($_GET['tab'])) echo 'active'; ?>"><a href="#description">Activity</a></li>
                                <li><a href="#reviews"> Biography</a></li>
                                <li><a href="#INFORMATION">Update Details</a></li>
                                <li class="<?php if(isset($_GET['tab'])) echo 'active'; ?>"><a href="#settings">Account Settings</a></li>
                            </ul>
                            <div id="myTabContent" class="tab-content custom-product-edit">
                                <div class="product-tab-list tab-pane fade <?php if(!isset($_GET['tab'])) echo 'active in'; ?>" id="description">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                           
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="single-review-st-item res-mg-t-30 table-mg-t-pro-n">
                        <?php echo loadUpdates($gkey); ?>
                    </div>
                </div>
            </div>
       
                                        </div>
                                    </div>
                                </div>
                                <div class="product-tab-list tab-pane fade" id="reviews">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="review-content-section">
                                                <div class="row">
                                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                                        <div class="address-hr biography">
                                                            <p><br /> <?php echo $display['aboutme']; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                                        <div class="address-hr biography">
                                                            <p><b>Full Name</b><br /> <?php echo $fullname; ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                                        <div class="address-hr biography">
                                                            <p><b>Mobile</b><br /> <?php echo $display['contact_no']; ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                                        <div class="address-hr biography">
                                                            <p><b>Email</b><br /> <?php echo $display['email']; ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                                        <div class="address-hr biography">
                                                            <p><b>Location</b><br /> <?php echo $display['address'] ?></p>
                                                        </div>
                                                    </div>
                                                </div>

                                                 <div class="row">
                                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                                        <div class="address-hr biography">
                                                            <p><b>Birthdate</b><br /> <?php echo $display['birthdate']; ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                                        <div class="address-hr biography">
                                                            <p><b>Gender</b><br /> <?php echo $display['gender']; ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                                        <div class="address-hr biography">
                                                            <p><b>Group Name</b><br /> <?php echo getGroupName($gkey); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                                                        <div class="address-hr biography">
                                                            <p><b>Group Key</b><br /> <?php echo $gkey; ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-tab-list tab-pane fade" id="INFORMATION">
                                    <div class="row">
                                        <br>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="review-content-section">
                                                <div class="row">
                                                    <form method="post" action="profile_update_info.php">
                                                    <input type="hidden" name="id" value="<?php echo $display['member_id']; ?>">
                                                    <div class="col-lg-12">
                                                        <div class="form-group">
                                                            <label>First Name</label>
                                                            <input name="fn" type="text" class="form-control" placeholder="First Name" value="<?php echo $name; ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Last Name</label>
                                                            <input type="text" class="form-control" placeholder="Last Name" name="ln" value="<?php echo $lastname; ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Address</label>
                                                            <input type="text" class="form-control" placeholder="Address" name="address" value="<?php echo $display['address']; ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Birthdate</label>
                                                            <input type="date" class="form-control" placeholder="Date of Birth" name="bdate" value="<?php echo $display['birthdate']; ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>E-mail</label>
                                                            <input type="email" class="form-control" placeholder="Date of Birth" name="email" value="<?php echo $display['email']; ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Contact</label>
                                                            <input type="text" class="form-control" placeholder="Phone number" name="contact" value="<?php echo $display['contact_no']; ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Gender</label>
                                                            <select class="form-control" name="gender">
                                                                <option><?php echo $display['gender']; ?></option>
                                                                <option>Male</option>
                                                                <option>Female</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Civil Status</label>
                                                            <select class="form-control" name="civil">
                                                                <option><?php echo $display['relationship']; ?></option>
                                                                <option>Single</option>
                                                                <option>Married</option>
                                                                <option>Widowed</option>
                                                            </select>
                                                        </div>
                                                        <br>
                                                        <div class="form-group">
                                                            <button type="submit" class="btn btn-info">Update Details</button>
                                                            <button type="button" class="btn btn-default">Reset</button>
                                                        </div>
                                                    </div>
                                                    </form>
                                                </div>  
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-tab-list tab-pane fade <?php if(isset($_GET['tab'])) echo 'active in'; ?>" id="settings">
                                    <div class="row">
                                        <br>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="sparkline11-list">
                                                <div class="sparkline11-graph">
                                                    <form method="post" action="profile_update_settings.php">
                                                    <input type="hidden" name="id" value="<?php echo $display['member_id']; ?>">
                                                    <div id="pwd-container2">
                                                        <div class="form-group">
                                                            <label>Username</label>
                                                            <input type="text" name="username" value="<?php echo $display['username'] ?>" class="form-control" autocomplete="off" >
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Current Password <i class="fas fa-eye psh1" style="cursor: pointer;"></i></label>
                                                            <input type="password" id="psh1" name="passx" value="<?php echo $display['password'] ?>" class="form-control psh1x" autocomplete="off" >
                                                        </div>
                                                        <div class="form-group head-strong-password">
                                                            <label for="password2">New Password</label>
                                                            <input type="password" class="form-control example2" id="password2" placeholder="Password" name="password">
                                                        </div>
                                                        <div class="form-group mg-b-pass">
                                                            <div class="pwstrength_viewport_verdict text-strong-password"></div>
                                                        </div>
                                                        <br>
                                                        <div class="form-group">
                                                            <button type="submit" class="btn btn-info">Update Details</button>
                                                            <button type="button" class="btn btn-default">Reset</button>
                                                        </div>
                                                    </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<script type="text/javascript">
    
    window.onload = function(){

        $("#profile-image").on("click", function(){
            $("#uploadimg").click();
            $("#uploadimg").on("change", function(){
                if(this.value != ""){
                    $("#uploadimgbtn").click();
                }
            });
        });

        $(".psh1").on("click", function(){

            var eye = document.getElementById("psh1");
            console.log(this.className.baseVal);
            if(eye.type == "password"){
                eye.type = "text";
            }else{
                eye.type = "password";
            }
        
        });

        //REMOVE AUTOCOMPLETE
        $("input").attr("autocomplete", "off");

    }

</script>

<?php include "footer.php"; ?>    
