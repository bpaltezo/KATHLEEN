    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon" type="image/x-icon" href="images/favicon2.ico">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/jquery-ui-1.8.21.custom.css" rel="stylesheet">
    <link href='css/fullcalendar.css' rel='stylesheet'>
    <link href='css/fullcalendar.print.css' rel='stylesheet'  media='print'>
    <link href='css/chosen.css' rel='stylesheet'>
    <link href='css/uniform.default.css' rel='stylesheet'>
    <link href='css/colorbox.css' rel='stylesheet'>
    <link href='css/jquery.cleditor.css' rel='stylesheet'>
    <link href='css/jquery.noty.css' rel='stylesheet'>
    <link href='css/noty_theme_default.css' rel='stylesheet'>
    <link href='css/elfinder.min.css' rel='stylesheet'>
    <link href='css/elfinder.theme.css' rel='stylesheet'>
    <link href='css/jquery.iphone.toggle.css' rel='stylesheet'>
    <link href='css/opa-icons.css' rel='stylesheet'>
    <link href='css/uploadify.css' rel='stylesheet'>

	<link rel="stylesheet" href="css/anythingslider.css">

    <link rel="stylesheet" type="text/css" href="css/layout.css" />
    <link rel="stylesheet" type="text/css" href="css/reset.css" />

	<script src="js/vendor/modernizr-2.8.3.min.js"></script>
    
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="fonts/fa/css/all.css">
    <link rel="stylesheet" type="text/css" href="fonts/googlefonts.css">
    <script type="text/javascript" src="fonts/fa/js/all.js"></script>
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/owl.transitions.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/educate-custon-icon.css">
    <link rel="stylesheet" href="css/form/all-type-forms.css">
    <link rel="stylesheet" href="css/morrisjs/morris.css">
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="css/metisMenu/metisMenu-vertical.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="css/calendar/fullcalendar.print.min.css">
    <link rel="stylesheet" href="css/summernote/summernote.css">
    <link rel="stylesheet" href="css/summernote/katex.min.css">
    <link rel="stylesheet" href="css/preloader/preloader-style.css">
    <link rel="stylesheet" href="css/alerts.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="style.css">

     <style type="text/css">
        .iblue{color:#3E24B9;}
        .footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 80%;
            margin-left:20%;
            color: #223345;
            text-align: center;
        }
        .xmodal{
            width:60%;
            margin-left:20%;
        }
        .xinput{
           font-family: 'Roboto', sans-serif;
           border: 1px solid #ececec;
           font-size: 25px;
           color: #303030;
           padding-left: 25px;
           padding-right: 25px;
           background: rgba(255, 255, 255, 0.1);
           box-shadow: none;
           border-radius: 30px;
        }

        .blank {
            text-align: center;
            border:none;
            border-bottom:1px solid #223345;
        }

        /* Customize the label (the container) */
        .container {
            display: block;
            position: relative;
            padding-left: 35px;
            margin-bottom: 12px;
            cursor: pointer;
            font-size: 16pt;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        /* Hide the browser's default radio button */
        .container input {
            position: absolute;
            opacity: 0;
            cursor: pointer;
            height: 0;
            width: 0;
        }

        /* Create a custom radio button */
        .checkmark {
            position: absolute;
            top: 0;
            left: 0;
            height: 25px;
            width: 25px;
            background-color: #eee;
            border-radius: 50%;
        }

        /* On mouse-over, add a grey background color */
        .container:hover input ~ .checkmark {
            background-color: #ccc;
        }

        /* When the radio button is checked, add a blue background */
        .container input:checked ~ .checkmark {
            background-color: #2196F3;
        }

        /* Create the indicator (the dot/circle - hidden when not checked) */
        .checkmark:after {
            content: "";
            position: absolute;
            display: none;
        }

        /* Show the indicator (dot/circle) when checked */
        .container input:checked ~ .checkmark:after {
            display: block;
        }

        /* Style the indicator (dot/circle) */
        .container .checkmark:after {
            top: 9px;
            left: 9px;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: white;
        }

        .quiz_container{
            width: 70%;
            height:auto;
            background:red;
        }

        .badge{
            background-color:rgba(255,0,0,0.9);
            margin-top:-25px;
            margin-left:-18px;
        }

        .badge-success{
            background-color:rgba(102,255,102,0.99);
            color:#fff;
            padding:5px;
            border-radius: 5px;
        }

        .badge-default{
            background-color:rgba(66,66,66,0.99);
            color:#fff;
            padding:5px;
            border-radius: 5px;
        }

        .badge-danger{
            background-color:rgba(255,0,0,0.69);
            color:#fff;
            padding:5px;
            border-radius: 5px;
        }

        #profile-image{
            cursor: pointer;
            border-radius: 15px;
            width: 100%;
            height:300px;
        }

        #profile-image:hover{
            cursor: pointer;
            border-radius: 15px;
        }

        .bg-lion{
            background:url('images/banner.png');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            background-blend-mode: darken;
        }

        .head{
            font-family: 'Open Sans';
            color:orange;
        }

        .head-head{
            background:url("images/slider6.jpg");
            background-color:rgba(10,10,10,0.8);
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-blend-mode: soft-light;
            border-radius: 5px;
        }

    </style>