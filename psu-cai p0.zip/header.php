<!-- Start Left menu area -->
    <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="./">
                    <img class="main-logo" src="images/logo.png" alt="" width="130" height="75" style="margin-top:25px;"/>
                </a>
                <strong><a href="./"><img src="images/logo.png" alt="" width="75" height="40" /></a></strong><br>
            </div>
            <hr>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li>
                            <a title="Go to Home" href="./home.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-home fa-1x iblue"></i> &nbsp;Home
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Go to Profile" href="./profile.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-id-badge fa-1x iblue"></i> &nbsp;&nbsp;Profile
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Go to Syllabus" href="./syllabus.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-book iblue"></i> &nbsp;&nbsp;Syllabus
                                </span>
                            </a>
                        </li>
                        <?php

                            if($type != "Student"){
                                echo ' <li>
                            <a title="Go to Lessons" href="./lessons.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-print iblue"></i> &nbsp;Printables
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Go to Tutorials" href="./tutorial.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-clipboard-list iblue"></i> &nbsp;&nbsp;Tutorials
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Go to Quiz" href="./quiz.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-edit iblue"></i> &nbsp;Quiz
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Go to Groups" href="./groups.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-layer-group iblue"></i> &nbsp;Groups
                                </span>
                            </a>
                        </li>';
                            }

                        ?>

                        <?php

                            if($type == "Student"){
                                echo ' 
                        <li>
                            <a title="Go to Tutorials" href="./tutorial.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-clipboard-list iblue"></i> &nbsp;Tutorials
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Go to Quiz" href="./quiz.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-edit iblue"></i> &nbsp;Quiz
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Go to Grades" href="./grades.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-star-half-alt iblue"></i> &nbsp;Grades
                                </span>
                            </a>
                        </li>
                        <li>
                            <a title="Go to Groups" href="./groups.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-layer-group iblue"></i> &nbsp;Groups
                                </span>
                            </a>
                        </li>';
                            }

                        ?>
                        <li>
                            <a title="Go to Messages" href="./message.php?inbox" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-envelope-open-text iblue"></i> &nbsp;Messages
                                </span>
                            </a>
                        </li>

                        <li>
                            <a title="Go to References" href="./glossary.php" aria-expanded="false">
                                <span class="mini-click-non">
                                    <i class="fas fa-book-reader iblue"></i> &nbsp;References
                                </span>
                            </a>
                        </li>
                        
                       
                    </ul>
                </nav>
            </div>
        </nav>
    </div>
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo" src="img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="background:#3E24B9;">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
                                                    <i class="educate-icon educate-nav"></i>
                                                </button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        
                                    </div>
                                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                                
                                                <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="educate-icon educate-message" aria-hidden="true"></i>
                                                   <span class="indicator-ms">
                                    <?php 

                                        $msgCount = count(GetMessages($display['email'],"unseen",99,""));
                                        if($msgCount != 0){
                                            echo '<span class="badge">'.$msgCount.'</span>';        
                                        }

                                    ?>
                                    </span>
                                                    </a>
                                                    <div role="menu" class="notification-author dropdown-menu animated zoomIn">
                                                        <div class="notification-single-top">
                                                            <h1>Messages</h1>
                                                        </div>
                                                        <ul class="notification-menu">
<?php

////////////////////MESSAGES
$messages = GetMessages($display['email'],"unseen",99,"");

for ($i=0; $i < count($messages); $i++) { 

    echo '<li>
                  <a href="message.php?read&message='.$messages[$i][0].'">
                    <div class="notification-icon">
                      <img src="'.GetMemberImageByName($messages[$i][1]).'">
                    </div>
                    <div class="notification-content">
                      <span class="notification-date">'.$messages[$i][0].'</span>
                      <h2>'.$messages[$i][1].'</h2>
                      <p>'.str_replace("<br>", "", $messages[$i][3]).' <br><i style="color:white;">'.$messages[$i][4].'</i> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    </div>
                  </a>
               </li>';
}

if(count($messages) == 0) echo "<p class='text-center'>No new messages</p>";

?>
                                                        </ul>
                                                        <div class="notification-view">
                                                            <a href="#">View All Notification</a>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle bell2"><i class="educate-icon educate-bell" aria-hidden="true"></i>
                                                    <?php 
                                                       if($type == "Faculty"){

                                                        if(isset($_SESSION['badge']) && $_SESSION['badge'] == ""){
                                                            echo $updatecount;    
                                                        }else{
                                                            echo '<span class="indicator-ms"></span>';
                                                        }
                                                        
                                                       }else{
                                                        echo '<span class="indicator-ms"></span>';
                                                       }
                                                    ?>
                                                    </a>
                                                    <div role="menu" class="notification-author dropdown-menu animated zoomIn">
                                                        <div class="notification-single-top">
                                                            <h1>Notifications</h1>
                                                        </div>
                                                        <ul class="notification-menu">
                                                            <?php
                                                                if($type == "Faculty"){
                                                                    echo $logupdates;
                                                                }
                                                            ?>
                                                        </ul>
                                                        <div class="notification-single-top">
                                                            <h1></h1>
                                                        </div>
                                                        <ul class="notification-menu">
                                                            <?php
                                                                if($type == "Faculty"){
                                                                    echo $quizupdates;
                                                                }
                                                            ?>
                                                        </ul>
                                                        <div class="notification-view">
                                                            <a href="notifications.php">View All Notification</a>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="nav-item">
                                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                                            <img src="<?php echo $pix; ?>" alt="" />
                                                            <span class="admin-name"><?php echo $name." ".$lastname; ?></span>
                                                            <i class="fa fa-angle-down edu-icon edu-down-arrow"></i>
                                                        </a>
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                        <li><a href="profile.php"><span class="fas fa-user-circle author-log-ic"></span>My Profile</a>
                                                        </li>
                                                        <li><a href="profile.php?tab=Settings"><span class="fas fa-cog author-log-ic"></span>Account Settings</a>
                                                        </li>
                                                        <li><a href="logout.php"><span class="fas fa-power-off author-log-ic"></span>Log Out</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
           <!-- Mobile Menu start -->
            <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
                                    <ul class="mobile-menu-nav">
                                        <li><a data-toggle="collapse" data-target="#Charts" href="#">Home <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="index.html">Dashboard v.1</a></li>
                                                <li><a href="index-1.html">Dashboard v.2</a></li>
                                                <li><a href="index-3.html">Dashboard v.3</a></li>
                                                <li><a href="analytics.html">Analytics</a></li>
                                                <li><a href="widgets.html">Widgets</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="events.html">Event</a></li>
                                        <li><a data-toggle="collapse" data-target="#demoevent" href="#">Professors <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul id="demoevent" class="collapse dropdown-header-top">
                                                <li><a href="all-professors.html">All Professors</a>
                                                </li>
                                                <li><a href="add-professor.html">Add Professor</a>
                                                </li>
                                                <li><a href="edit-professor.html">Edit Professor</a>
                                                </li>
                                                <li><a href="professor-profile.html">Professor Profile</a>
                                                </li>
                                            </ul>
                                        </li>
                                       
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu end -->

