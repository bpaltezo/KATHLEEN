<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
	
<?php
		
	include("session/DBConnection.php");	
	$user = $_SESSION['log']['username'];
  $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
  $display = mysql_fetch_array($query); 
  $type = $display['type'];
  $name = $display['firstname'];
  $lastname = $display['lastname'];
  $pix = $display['image'];
  $fac_name = $display['instructor'];
  $gkey = $display['group_key'];

  if($pix == "") if($display['type'] == "Male") $pix = "uploads/propicm.png"; else $pix = "uploads/propicf.png";

?>

<?php require_once("includes/session.php"); ?>
<?php require_once("includes/connection.php"); ?>
<?php require_once("includes/functions.php"); ?>

<title>Student Information - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>  

	<?php include "links.php"; ?>

<?php

	$sname = "";
	$semail = "";
	$saddress = "";
	$scontact = "";
	$sbday = "";
	$stype = "";
	$sprof = "";
	$sgender = "";
	$sgkey = "";
	$simage = "";

	if(isset($_GET['view'])){

		$sID = $_GET['view'];

		$sql = "SELECT * FROM members WHERE member_id='$sID' ";
		$res = $conn->query($sql);

		while($row = $res->fetch_assoc()){
			$sname = $row['firstname']." ".$row['lastname'];
			$semail = $row['email'];
			$saddress = $row['address'];
			$scontact = $row['contact_no'];
			$sbday = $row['birthdate'];
			$stype = $row['type'];
			$sprof = $row['instructor'];
			$sgkey = $row['group_key'];
			$simage = $row['image'];
			$sgender = $row['gender'];
		}

	}

?>


</head>
<body>
  <?php
    include "includes/updates.php";
    $latestupdates = GetUpdates($_SESSION['log']['username']);
    $logupdates = $latestupdates[0];
    $quizupdates = $latestupdates[1];
    $updatecount = $latestupdates[2];
?>
<?php include "header.php"; ?>

<!-- Mobile Menu end -->
<div class="breadcome-area">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
       	<div class="breadcome-list single-page-breadcome">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="breadcome-heading">
                <form role="search" class="sr-input-func">
                  <input type="text" placeholder="Search..." class="search-int form-control">
                  <a href="#"><i class="fa fa-search"></i></a>
                </form>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <ul class="breadcome-menu">
                <li><a href="#">Home</a> <span class="bread-slash">/</span></li>
                <li><span class="bread-blod">Student Profile</span></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

        <!-- Single pro tab review Start-->
        <div class="single-pro-review-area mt-t-30 mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6 col-md-4 col-sm-4 col-xs-12">
                        <div class="profile-info-inner">
                            <div class="profile-img">
                                <img style="width:50%;height:50%;margin-left:25%;border-radius: 50%;" src="<?php echo $simage; ?>" alt="User Profile" />
                            </div>
                            <div class="profile-details-hr">
                                <div class="row">
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                                        <div class="address-hr">
                                            <p><b>Name</b><br /> <?php echo $sname; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                                        <div class="address-hr tb-sm-res-d-n dps-tb-ntn">
                                            <p><b>Account Type</b><br /> <?php echo $stype; ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                                        <div class="address-hr">
                                            <p><b>Email ID</b><br /> <?php echo $semail; ?></p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                                        <div class="address-hr tb-sm-res-d-n dps-tb-ntn">
                                            <p><b>Phone</b><br /> <?php echo $scontact; ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="address-hr">
                                            <p><b>Address</b><br /> <?php echo $saddress; ?></p>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
<?php

  $sql = "SELECT * FROM grades WHERE group_key='$sgkey'";
  $res = $conn->query($sql);

  $total = 0;
  $passed = 0;

  while($row = $res->fetch_assoc()){
    if($row['remarks'] == "Passed"){
      $passed += 1;
    }
    $total++;
  }

?>
                    <div class="col-lg-6 col-md-8 col-sm-8 col-xs-12">
                        <div class="product-payment-inner-st res-mg-t-30 analysis-progrebar-ctn">
                            <ul id="myTabedu1" class="tab-review-design">
                                <li class="active"><a href="#bio"> Biography</a></li>
                                <li><a href="#activity"> Recent Activity</a></li>
                            </ul>
                            <div id="myTabContent" class="tab-content custom-product-edit st-prf-pro">

                                <div class="product-tab-list tab-pane fade active in" id="bio">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="review-content-section">

                                            	<div class="row">
                    								<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
                        								<div class="analytics-rounded reso-mg-b-30">
                            								<div class="analytics-rounded-content text-center">
                                								<h5>Quiz Demographics</h5>
                                								<h2><span class="counter"><?php echo $passed; ?></span>/<?php echo $total; ?></h2>
                                							    <div class="text-center">
                                    								<div id="demograph"></div>
                               	 								</div>
                            								</div>
                        								</div>
                    								</div>
                  								</div>

                                                <div class="row mg-b-15">
                                                    <div class="col-lg-12">
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="skill-title">
                                                                    <h2>Quiz Records</h2>
                                                                    <hr />
                                                                </div>

                                                                <?php echo getGrades($sID); ?>

                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                        
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="product-tab-list tab-pane fade" id="activity">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="review-content-section">
                                                <div class="chat-discussion" style="height: auto">
                                                <?php echo loadUpdates($gkey, "student", $sID); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                               
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>


	<script src="js/vendor/jquery-1.12.4.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="js/jquery-price-slider.js"></script>
  <script src="js/jquery.meanmenu.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.sticky.js"></script>
  <script src="js/jquery.scrollUp.min.js"></script>
  <script src="js/counterup/jquery.counterup.min.js"></script>
  <script src="js/counterup/waypoints.min.js"></script>
  <script src="js/counterup/counterup-active.js"></script>

  <script src="js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
  <script src="js/scrollbar/mCustomScrollbar-active.js"></script>
  <script src="js/metisMenu/metisMenu.min.js"></script>
  <script src="js/metisMenu/metisMenu-active.js"></script>
  <script src="js/sparkline/jquery.sparkline.min.js"></script>
  <script src="js/calendar/moment.min.js"></script>
  <script src="js/calendar/fullcalendar.min.js"></script>
  <script src="js/calendar/fullcalendar-active.js"></script>
  <script src="js/tab.js"></script>
  <script src="js/plugins.js"></script>
  <script src="js/main.js"></script>
  <script type="text/javascript">
    $("#demograph").sparkline([<?php echo $passed; ?>, 0], {
       type: 'pie',
       height: '116',
       sliceColors: ['#1ab394', '#ebebeb']
     });
  </script>
</body>
</html>
