<?php ob_start(); ?>

<?php session_start();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link media="screen, projection" type="text/css" href="css/style.css" rel="stylesheet">
<?php
include("../session/DBConnection.php");
$user = $_SESSION['log']['username'];
			$query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
			$display = mysql_fetch_array($query);	?>
<title>CAI - <?php echo $display['firstname'] . " " . $display['lastname'] ?> </title>	
	
	
<body>

<!-- end header -->
	
		
				
	


</body> 
</html>
