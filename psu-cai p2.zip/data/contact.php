<?php ob_start(); ?>
<?php session_start();?>


<?php
include("../session/DBConnection.php");

include('../gen.php');
 
?> 
<?php

 function GenKey($length = 7)
{
  $group_key = "";
  $possible = "0123456789abcdefghijkmnopqrstuvwxyz"; 
  while ($i < $length) { 

    
    $char = substr($possible, mt_rand(0, strlen($possible)-1), 1);
       
    
    if (!strstr($group_key, $char)) { 
      $group_key .= $char;
      $i++;
    }

  }

  return $group_key;

}
	   
	 
?>

<?php

/*
 * SimpleModal Contact Form
 * http://www.ericmmartin.com/projects/simplemodal/
 * http://code.google.com/p/simplemodal/
 *
 * Copyright (c) 2009 Eric Martin - http://ericmmartin.com
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Revision: $Id: contact-dist.php 254 2010-07-23 05:14:44Z emartin24 $
 *
 */

// User settings

// Include extra form fields and/or submitter data?
// false = do not include
$extra = array(
	"form_picture"	=> true,
	
);


$user = $_SESSION['log']['username'];
			$query = mysql_query("SELECT * FROM users WHERE username = '$user'") or die (mysql_error()); 
			$display = mysql_fetch_array($query);	
  $faculty_name= $display['username'];
  $type= $display['usertype'];
// Process

$action = isset($_POST["action"]) ? $_POST["action"] : "";
if (empty($action)) {


 if($type!= 'Student'){ 

	// Send back the contact form HTML
	$output = "<div style='display:none'>
	<div class='contact-top'></div>
	<div class='contact-content' style=height:50px; >
		<h1 class='contact-title' style='color:white;'>Add Groups:</h1>
		<div class='contact-loading' style='display:none'></div>
		<div class='contact-message' style='display:none'></div>
		<form action='#' style='display:none'>
			<br />
			<label for='contact-name'>Group Name:</label>
			&nbsp;&nbsp;&nbsp;<input type='text' id='contact-name' class='contact-input' name='group_name' tabindex='1001' style='width:195px;'/>
			<br />
			<br />
			<p  style='color:white; opacity:50px; position:relative; right-margin:40px;'>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Day(00:00am-00:00pm)</p>
			<label for='contact-day'>Day:</label>
			&nbsp;&nbsp;&nbsp;<input type='text' id='contact-day' class='contact-input' name='group_day' tabindex='1001' style='width:195px;'/>
			
			 <input name='image' type='hidden' value='uploads/Gimage.jpg' />
			<br />
<label>&nbsp;</label>
			<button type='submit' id='send' name='send' class='contact-send contact-button' tabindex='1006'>ADD</button>
			<button type='submit' class='contact-cancel contact-button simplemodal-close' tabindex='1007'>Cancel</button>
			<br/>
			<input type='hidden' name='token' value='" . smcf_token($to) . "'/>
		</form>
	</div>
	</div>
			";
echo $output;

 }

 else {
	$output = "<div style='display:none'>
	<div class='contact-top'></div>
	<div class='contact-content' style=height:30px; >
		<h1 class='contact-title'>Join Now!</h1>
		<div class='contact-loading' style='display:none'></div>
		<div class='contact-message' style='display:none'></div>
		<form action='#' style='display:none'>
			<label for='contact-name'>Enter Group Key:</label>
			<input type='text' id='contact-key' class='contact-input' name='group_keys' tabindex='1001' />
			 <br />
<label>&nbsp;</label>
			<button type='submit' id='send' name='send' class='contact-send contact-button' tabindex='1006'>OK</button>
			<button type='submit' class='contact-cancel contact-button simplemodal-close' tabindex='1007'>Cancel</button>
			<br/>
			<input type='hidden' name='token' value='" . smcf_token($to) . "'/>
		</form>
	</div>
	</div>
			";
echo $output;

 } 
	
}
else if ($action == "send") {
	// Send the email
	$name = isset($_POST['name']) ? $_POST['name'] : "";
	$picture = isset($_POST['picture']) ? $_POST['picture'] : "";
	$cc = isset($_POST["cc"]) ? $_POST["cc"] : "";
	$token = isset($_POST["token"]) ? $_POST["token"] : "";
	// make sure the token matches
	if ($token === smcf_token($to)) {
		smcf_send($name, $picture);

$group_day = $_POST['group_day'];	
$group_name = $_POST['group_name'];
$image = $_POST['image'];
  $group_key=GenKey();
//echo "<script> alert ('$user')</script>";
 $id=random_gen();

	mysql_query("INSERT INTO groups (`group_id`,`group_name`,`group_day`,`image`,
				`group_key`,
				`created_date`,`faculty_name`) 
				VALUES('$id','$group_name','$group_day','$image', 
				'$group_key',now(),'$faculty_name')
				") or die(mysql_error());
					
echo "Please copy your group_key : <h3 style='color:white;'> $group_key</h3>";
		}
	
	else {

echo "Unfortunately, Group not be verified.";
}
	}


function smcf_token($s) {
	return md5("smcf-" . $s . date("WY"));
}

// Validate and send email
function smcf_send($name,$picture) {
	global $to, $extra;



	// Set and wordwrap message body
	$body = "From: $name\n\n";
	$body .= "Message: $message";
	$body = wordwrap($body, 70);

}
	

exit;

?>