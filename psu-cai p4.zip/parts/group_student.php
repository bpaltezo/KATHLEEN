<?php

	$sql = "SELECT * FROM groups WHERE group_key='$gkey'";
	$res = $conn->query($sql);

	$pimage = "";
	$simage = "";

	while($row = $res->fetch_assoc()){
		$groupname = $row['group_name'];
		$instructor = $row['faculty_name'];
	}

?>

<div class="container-fluid">

	<div class="single-review-st-item res-mg-t-30 table-mg-t-pro-n">
	<div class="row">
		<div class="col-lg-6">
			<span>Group Name: <h3><?php echo $groupname; ?></h3></span>
			<span>Instructor: <h3><?php echo $instructor; ?></h3></span><br><br>
		</div>
	</div>
	</div>
	<br>
	<div class="row">
		
		<div class="col-lg-6">
			
			<div class="single-review-st-item res-mg-t-30 table-mg-t-pro-n">
   				<div class="single-review-st-hd">
     		 		<h2>Members</h2>
    			</div>
<?php

	$sql = "SELECT * FROM members WHERE group_key='$gkey' AND type='Student' ";
	$res = $conn->query($sql);

	while($row = $res->fetch_assoc()){

		if($row['member_id'] == $display['member_id']){
			echo '<div class="single-review-st-text">
      			<img src="'.$row['image'].'" alt="" style="border-radius:50%;">
      			<div class="review-ctn-hf">
        			<h3>'.$row['firstname']." ".$row['lastname'].'</h3>
        			<p>'.$row['email'].'</p>
      			</div>
      			<div class="review-item-rating">
       				
      			</div>
   			</div>';
		}else{
			echo '<div class="single-review-st-text">
      			<img src="'.$row['image'].'" alt="" style="border-radius:50%;">
      			<div class="review-ctn-hf">
        			<h3>'.$row['firstname']." ".$row['lastname'].'</h3>
        			<p>'.$row['email'].'</p>
      			</div>
      			<div class="review-item-rating">
       				<a href="message.php?compose&sendto='.$row['email'].'"><button class="btn btn-default"><i class="fas fa-envelope"></i> Message</button></a>
      			</div>
   			</div>';
		}
	
	}

?>	
  			</div>

		</div>

		<div class="col-lg-6">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="single-review-st-item res-mg-t-30 table-mg-t-pro-n">
                    	<div class="single-review-st-hd">
	                    	<h2>Lastest Updates</h2>
    					</div>
    					<?php echo loadUpdates($gkey); ?>
                    </div>
                </div>
            </div>
		</div>

	</div>
</div>