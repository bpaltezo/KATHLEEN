<div class="mailbox-compose-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <?php include "msg_menu.php"; ?>
                    <form method="post" action="message.php">
                    <div class="col-md-9 col-md-9 col-sm-9 col-xs-12">
                        <div class="hpanel email-compose">
                            <div class="panel-heading hbuilt">
                                <div class="p-xs h4">
                                    New message
                                </div>
                            </div>
                            <div class="panel-heading hbuilt">
                                <div class="p-xs">
                                    <form method="get" class="form-horizontal">
                                        <div class="form-group">
                                            <label class="col-lg-1 control-label text-left">To:</label>
                                            <div class="col-lg-11 col-md-12 col-sm-12 col-xs-12">
                                                <input name="reciever" type="email" class="form-control input-sm" placeholder="example@email.com" value="<?php if(isset($_GET['sendto'])) echo $_GET['sendto']; ?>" placeholder="email@email.com"  required />
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <br><br><br>
                            <div class="panel-body no-padding">
                                <input type="text" class="content" name="content" style="display: none;">
                                <div class="summernote6"></div>
                            </div>
                            <div class="panel-footer">
                                <div class="pull-right">
                                    <div class="btn-group active-hook">
                                        <button class="btn btn-default"><i class="fa fa-edit"></i> Save</button>
                                        <button class="btn btn-default"><i class="fa fa-trash"></i> Discard</button>
                                    </div>
                                </div>
                                <input type="submit" class="sendBtn" style="display: none;">
                                <button type="button" class="btn btn-primary ft-compse sbtn">Send email</button>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>

<script type="text/javascript">

    window.onload = function(){
        
        $(".summernote6").summernote({height: 300});

        $(".sbtn").on("click", function(){
            //console.log($(".summernote6").summernote("code"));
            if($(".summernote6").summernote("code") == "<p><br></p>"){
                alert("Cannot send empty messages!");
            }else{
                $(".content").val($(".summernote6").summernote("code"));
                $(".sendBtn").click();
            }
        });

    }
</script>
