<?php

  $conn = mysqli_connect('localhost', 'root', '', 'cai_it4');

  if(isset($_GET['view'])){

    $viewID = $_GET['view'];

    echo '<div class="contacts-area mg-b-15">
            <div class="container-fluid">
              <h4>Your Group Members</h4>
              <div class="add-product text-light" style="float:right;">
                Group Key: <b style="color:teal;font-size:22pt;";>'.$viewID.'</b>
              </div>
              <br><br><br>';

    $sql = "SELECT * FROM members WHERE type='Student' AND group_key='$viewID' ";
    $res = $conn->query($sql);

    $counter = 0;
    $count = 0;
    while($row = $res->fetch_assoc()){
      if($counter == 3) echo '<div class="row">';
      
      echo ' <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
              <a href="students.php?view='.$row['member_id'].'">
              <div class="student-inner-std res-mg-b-30">
                <br>
                <div class="student-im">
                  <img src="'.$row['image'].'" alt="" style="border-radius:50%;"/>
                </div>
                <div class="student-dtl">
                  <h2>'.$row['firstname']." ".$row['lastname'].'</h2>
                  <p class="dp">'.$row['email'].'</p>
                  <br>
                  <div class="review-item-rating">
                    <a href="message.php?compose&sendto='.$row['email'].'">
                      <button class="btn btn-default"><i class="fas fa-envelope"></i> Message
                      </button>
                    </a>
                  </div>

                </div>
              </div>
              </a>
            </div>';

      if($counter == 3){echo '</div>'; $counter = 0;}
      else{$counter++;}
      $count++;
    }

    if($count == 0){
      echo "<div class='text-center'>There is no members to this group. <a href='groups.php'>Manage Groups</a></div>";
    }

    echo ' </div>
            </div>
        </div>';


  }else{

    echo '<div class="product-status mg-b-15">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="product-status-wrap">
              <h4>Your Groups</h4>
              <div class="add-product">
                <a class="Primary mg-b-10" href="#" data-toggle="modal" data-target="#PrimaryModalalert">Add Group</a>
              </div>
              <div class="asset-inner">
                <table>
                  <thead>
                    <tr>
                    <th></th>
                    <th>Code</th>
                    <th>Group Name</th>
                    <th>Status</th>
                    <th>Total Students</th>
                    <th>Action</th>
                  </tr> 
                  </thead>
                  <tbody>';

    $sql = "SELECT * FROM groups WHERE group_key='$gkey'";
    $res = $conn->query($sql);
    $count = 0;

    while($row = $res->fetch_assoc()){

      $k = $row['group_key'];

      echo "<tr>";
      echo "<td></td>";
      echo "<td>".$k."</td>";                        
      echo "<td>".$row['group_name']."</td>";
      echo "<td><button class='pd-setting'>Active</button></td>";

      $sql2 = "SELECT * FROM members WHERE type='Student' AND group_key='$k'";
      $res2 = $conn->query($sql2);
      $count = 0;
      
      while($row2 = $res2->fetch_assoc()){
        $count++;
      }

      echo "<td>".$count."</td>";
 
      echo '<td>
              <button data-toggle="tooltip" title="View members" class="pd-setting-ed">
                <a href="groups.php?view='.$k.'">
                  <i class="fas fa-users" aria-hidden="true"></i>
                </a>
              </button>
              <button data-toggle="tooltip" title="Remove Group" class="pd-setting-ed">
                <a href="groups.php?del='.$k.'">
                  <i class="fas fa-trash" aria-hidden="true"></i>
                </a>
              </button>
            </td>';
      echo "</tr>";
      $count++;
    }

    if($count == 0) echo "<tr><td colspan='8'><center>You have no groups to manage</center></td></tr>";

    echo '</tbody>
                </table>
              </div>
              <div class="custom-pagination">
                <ul class="pagination">
                  <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item"><a class="page-link" href="#">Next</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>';
  }

?>

</div>
</div>

	<div id="PrimaryModalalert" class="modal modal-primary xmodal fade" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-close-area modal-close-df">
          <a class="close" data-dismiss="modal" href="#"><i class="fas fa-close"></i></a>
        </div>
        
        <form method="post" action="groups.php">
        	
        <div class="modal-body">
        	<div class="row">
        		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
              <div class="breadcome-heading">

                  <label>Group Key</label>
                  <input type="text" class="form-control" name="gkey" value="<?php echo generateKey(); ?>" readonly >
                	<br>
                	<label>Group Name</label>
                  <input type="text" class="form-control" name="gname" >
               		<input type="hidden" name="addgroup">
              </div>
            </div>
        	</div>
        </div>
        <div class="modal-footer">
          <a data-dismiss="modal" href="#" class="btn btn-danger" >Cancel</a>
          <button type="submit" class="btn btn-primary" >Submit</button>
        </div>
         </form>
      </div>
    </div>
  </div>