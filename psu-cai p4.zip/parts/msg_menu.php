<div class="col-md-3 col-md-3 col-sm-3 col-xs-12">
    <div class="hpanel responsive-mg-b-30">
        <div class="panel-body">
            <a href="message.php?compose" class="btn btn-success compose-btn btn-block m-b-md">Compose</a>
            <br>
            <ul class="mailbox-list">
                <li class="<?php if(isset($_GET['inbox'])) echo 'active';  ?>">
                    <a href="message.php?inbox">
                        <span class="pull-right" style="color:#223345;">
                            <?php echo count(GetMessages($display['email'],"unseen",99,"")); ?></span>
                        <i class="fa fa-envelope" style="color:lightblue;"></i> Inbox
                    </a>
                </li>
                <li class="<?php if(isset($_GET['sent'])) echo 'active';  ?>">
                    <a href="message.php?sent"><i class="fa fa-paper-plane" style="color:orange;"></i> Sent</a>
                </li>
                <li  class="<?php if(isset($_GET['trash'])) echo 'active';  ?>">
                    <a href="message.php?trash"><i class="fa fa-trash" style="color:maroon;"></i> Trash</a>
                </li>
            </ul>
            <hr>
            <ul class="mailbox-list">
                <li>
                    <a href="#"><i class="fa fa-cog" style="color:#223345;"></i> Settings</a>
                </li>
                <li>
                    <a href="#"><i class="fa fa-info-circle" style="color:#223345;"></i> Support</a>
                </li>
            </ul>
        </div>
    </div>
</div>