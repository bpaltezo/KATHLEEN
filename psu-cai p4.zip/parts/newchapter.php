<?php
	
	$conn = mysqli_connect("localhost", "root", "", "cai_it4");

	$title = $_POST['title'];
	$content = $_POST['content'];
	$group = $_POST['group'];
	$prof = $_POST['prof'];
	$pos = $_POST['pos'];

	#echo $title.$content.$group.$prof.$pos;

	$sql = "INSERT INTO chapters (title, content, group_key, prof, pos)
			VALUES ('$title', '$content', '$group', '$prof', '$pos')";
	$res = $conn->query($sql);

	if($res){
		
		$sql2 = "SELECT * FROM chapters WHERE title='$title' AND group_key='$group' AND prof='$prof' AND pos='$pos' ";
		$res2 = $conn->query($sql2);

		$id = "";
		$title = "";

		while($row = $res2->fetch_assoc()){
			$id = $row['id'];
			$title = $row['title'];
		}

		echo $id."&".$title;

	}else{
		echo "err";
	}

?>