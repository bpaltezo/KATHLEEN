<?php

    $datetime1 = "";
    $datetime2 = "";
    $sender = "";
    $content = "";
    $senderEmail = "";
    $msgid = "";

    if(isset($_GET['message'])){

        $conn = $conn = mysqli_connect("localhost", "root", "", "cai_it4");
        $sql = "SELECT * FROM messages WHERE message_id=".$_GET['message'];
        $res = $conn->query($sql);

        while($row = $res->fetch_assoc()){
            $sender = $row["sender"];
            $content = $row["content"];
            $datetime = explode(" ", $row["date_sent"]);
            $datetime1 = $datetime[1].$datetime[2].", ".$datetime[3];
            $time = explode(":", $datetime[4]);
            ($time[0] < 12) ? $ampm = "AM" : $ampm = "PM";
            $datetime2 = $time[0].":".$time[1]." ".$ampm." (".time_elapsed_string($datetime[4], false).")";
        }

        //SENDER EMAIL AND OTHER INFOS
        $name = explode(" ", $sender);
        $fn = $name[0];
        $ln = $name[1];

        $sql2 = "SELECT * FROM members WHERE firstname='$fn' AND lastname='$ln' ";
        $res2 = $conn->query($sql2);

        while($row = $res2->fetch_assoc()){
            $senderEmail = $row["email"];
        }

        $sql3 = "UPDATE messages SET status='seen' WHERE message_id=".$_GET['message'];
        $res3 = $conn->query($sql3);

    }

?>

<div class="mailbox-view-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <?php include "msg_menu.php"; ?>
                    <div class="col-md-9 col-md-9 col-sm-9 col-xs-12">
                        <div class="hpanel email-compose mailbox-view">
                            <div class="panel-heading hbuilt">

                                <div class="p-xs h4">
                                    <small class="pull-right view-hd-ml">
                                        <?php echo $datetime2; ?>
                                    </small> Message from <?php echo $sender; ?>

                                </div>
                            </div>
                            <div class="border-top border-left border-right bg-light">
                                <div class="p-m custom-address-mailbox">

                                    <div>
                                        <span class="font-extra-bold">From: </span>
                                        <a href="#"><?php echo $senderEmail; ?></a>
                                    </div>
                                    <div>
                                        <span class="font-extra-bold">Date: </span> <?php echo $datetime1; ?>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="panel-body panel-csm">
                                <div>
                                    <?php echo $content; ?>
                                <br>
                                   
                                </div>
                            </div>

                            <div class="border-bottom border-left border-right bg-white mg-tb-15">
                               
                            </div>

                            <div class="panel-footer text-right ft-pn">
                                <div class="btn-group active-hook">
                                    <a href="message.php?compose&sendto=<?php echo $senderEmail; ?>"><button class="btn btn-default"><i class="fa fa-reply"></i> Reply</button></a>
                                    <a href="message.php?read&message=116&delete"><button class="btn btn-default">
                                        <i class="fa fa-trash"></i> Remove</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

