<?php

	$msg_id = $_POST["id"];

	$conn = mysqli_connect("localhost", "root", "", "cai_it4");

	$sql = "DELETE FROM messages WHERE message_id='$msg_id' ";
	$res = $conn->query($sql);

	if($res){
		echo "success";
	}else{
		echo "err";
	}

?>