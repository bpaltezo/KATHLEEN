<div class="mailbox-area mg-b-15">
    <div class="container-fluid">
        <div class="row">
            <?php include "msg_menu.php"; ?>
            <div class="col-md-9 col-md-9 col-sm-9 col-xs-12">
                <div class="hpanel">
                    <div class="panel-heading hbuilt mailbox-hd">
                        <div class="text-center p-xs font-normal">
                            <div class="input-group">
                                <input type="text" class="form-control input-sm" placeholder="Search email in your inbox..."> 
                                <span class="input-group-btn active-hook"> 
                                    <button type="button" class="btn btn-sm btn-default">Search</button> 
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6 col-md-6 col-sm-6 col-xs-8">
                                <div class="btn-group ib-btn-gp active-hook mail-btn-sd mg-b-15">
                                    <button class="btn btn-default btn-sm"><i class="fas fa-sync-alt"></i> Refresh</button>
                                    <button class="btn btn-default btn-sm" onclick="MoveToTrash()">
                                        <i class="fa fa-trash"></i> Delete
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-6 col-md-6 col-sm-6 col-xs-4 mailbox-pagination">
                                <div class="btn-group ib-btn-gp active-hook mail-btn-sd mg-b-15">
                                    <button class="btn btn-default btn-sm"><i class="fa fa-arrow-left"></i></button>
                                    <button class="btn btn-default btn-sm"><i class="fa fa-arrow-right"></i></button>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive ib-tb">
                            <table class="table table-hover table-mailbox">
                                <tbody>

<?php

$messages = GetMessages($fullname,"trash",99,"");

for ($i=0; $i < count($messages); $i++) { 

    $status = "";

    if($messages[$i][5] == "unseen"){
        $status = "unread active";
    }
    
    echo '<tr class="'.$status.' msg" onclick="Highlight('.$i.','.$messages[$i][0].', this)" >
        <td class="">
            <div class="checkbox checkbox-single checkbox-success text-white">
                <input type="checkbox" checked="">
                <label></label>
                <i class="indicator fas fa-circle"></i>
            </div>
        </td>
        <td><a hef="message.php?read&message='.$messages[$i][0].'">'.$messages[$i][2].'</a></td>
        <td><a hef="message.php?read&message='.$messages[$i][0].'"><p>'.$messages[$i][3].'</p></a></td>
        <td class="text-right mail-date">Tue, Nov 25</td>
    </tr>';

}

?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>

<script type="text/javascript">

    tomove = [];

    function Highlight(x, id, row){

        var checked = document.getElementsByClassName("indicator")[x];

        if(!checked.classList.contains("text-danger")){
            checked.classList.add("text-danger");
            tomove.push(id);
        }else{
            checked.classList.remove("text-danger");
        }
    
    }
    
    function MoveToTrash(){

        for(var x=0;x<tomove.length;x++){

            $.post("parts/delete.php", {
                id: tomove[x]
            }, function(data, success){
                console.log(data);
                if(data == "success"){
                    window.location.reload();
                }
            });

        }

    }

</script>