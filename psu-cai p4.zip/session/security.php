<?php

	Security($_POST['do'], $_POST['session']);

?>

<?php

	function Security($task, $session){

		$conn = mysqli_connect("localhost", "root", "", "cai_it4");

		if($task == "set"){
		
			if($session == "quiz"){
				$sql = "UPDATE session SET quiz = 'active' WHERE id='1'";
			}else if($session == "lesson"){
				$sql = "UPDATE session SET lesson='active' WHERE id='1'";
			}else if($session == "tutorial"){
				$sql = "UPDATE session SET tutorial='active' WHERE id='1'";
			}

			$res = $conn->query($sql);
		
		}else if($task == "unset"){

			if($session == "quiz"){
				$sql = "UPDATE session SET quiz='inactive' WHERE id='1'";
			}else if($session == "lesson"){
				$sql = "UPDATE session SET lesson='inactive' WHERE id='1'";
			}else if($session == "tutorial"){
				$sql = "UPDATE session SET tutorial='inactive' WHERE id='1'";
			}

			$res = $conn->query($sql);
		
		}else if($task == "get"){
			$sql = "SELECT * FROM session";
			$res = $conn->query($sql);
			while($row = $res->fetch_assoc()){
				if($row[$session] == "active"){
					return true;
				}else{
					return false;
				}
			}
		}


	}

?>