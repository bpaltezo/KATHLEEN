<?php
	// This file is the place to store all basic functions

	function redirect_to( $location = NULL ) {
		if ($location != NULL) {
				echo " <script type='text/javascript'>

<!--redirection -->
		 var delay = 500;
		setTimeout(function(){ window.location = '{$location}';}, delay);  
<!--redirection end -->	
</script> ";
			exit;
		}
	}

	function confirm_query($result_set) {
		if (!$result_set) {
			die("Database query failed: " . mysql_error());
		}
	}

	function generateKey(){
		$key = uniqid();
		$finalkey = $key[0].$key[1].$key[2].$key[3].$key[4].$key[5];
		
		$conn = mysqli_connect("localhost", "root", "", "cai_it4");
		$sql = "SELECT * FROM groups WHERE group_key = '$finalkey' ";
		$res = $conn->query($sql);
		$count = 0;
		while($row = $res->fetch_assoc()){
			$count++;
		}
		if($count == 0){
			return $finalkey;
		}else{
			generateKey();
		}
	}

	function generateID($len, $table){

		$conn = mysqli_connect("localhost", "root", "", "cai_it4");
		$sql = "SELECT * FROM $table";
		$res = $conn->query($sql);

		$result = "";
		$count = 0;
		while($row = $res->fetch_assoc()){
			$count++;
		}

		for($i=0;$i<$len-strlen($count);$i++){
			$result .= 0;
		}

		return $result.($count+1);

	}

	function setTopicIndex(){

		$conn = mysqli_connect("localhost", "root", "", "cai_it4");
		$sql = "";		

	}

	function getTopicPosition($prof, $subject, $chapter){

		$conn = mysqli_connect("localhost", "root", "", "cai_it4");
		
		if($subject == "topics") $sql = "SELECT * FROM topics WHERE prof='$prof' AND chapter_id='$chapter' ";
		else if($subject == "chapters") $sql = "SELECT * FROM chapters WHERE prof='$prof' ";
		
		$res = $conn->query($sql);

		$counter = 0;
		while($row = $res->fetch_assoc()){
			$counter++;
		}

		return $counter+1;

	}

	function getLatestUpdates($gname, $range){

		$conn = mysqli_connect("localhost", "root", "", "cai_it4");

		$result  = "";

		//LATEST QUIZERS
		$quizzers = array();
		for($i=$range;$i>0;$i--){
			$date = date("F d Y", strtotime("-".($i-1)." day"));
			#echo $date;
			$sql = "SELECT * FROM results WHERE group_name='$gname' AND date_quizzed='$date'";
			$res = $conn->query($sql);

			$quizzersTemp = array();
			while($row = $res->fetch_assoc()){
				$quizzersTemp[] = $row['quizzer_name'];
				$quizzersTemp[] = $row['quiz_id'];
				$quizzersTemp[] = $row['rating'];
				$quizzersTemp[] = $row['date_quizzed'];
				$quizzers[] = $quizzersTemp;
			}
		}
		
		//HTML OUTPUT

		//QUIZZERS
		
		for($i=0;$i<count($quizzers);$i++){
			$result .= '
			<div class="single-review-st-text">
            <div class="review-ctn-hf">
                <h3>'.$quizzers[$i][0].'</h3>
                <p>'.$quizzers[$i][2].' a Quiz</p>
            </div>
            <div class="review-item-rating">
               '.$quizzers[$i][3].'
            </div>
	        </div>';
		}
	
		return $result;

	}

	function getGroupName($gkey){

		$conn = mysqli_connect("localhost", "root", "", "cai_it4");
		$result  = "";

		$sql = "SELECT * FROM groups WHERE group_key = '$gkey' ";
		$res = $conn->query($sql);

		while($row = $res->fetch_assoc()){
			$result = $row['group_name'];
		}

		return $result;

	}

	function getTotalMembers($gkey){
		$conn = mysqli_connect("localhost", "root", "", "cai_it4");
		$result  = 0;

		$sql = "SELECT * FROM members WHERE group_key = '$gkey' ";
		$res = $conn->query($sql);

		while($row = $res->fetch_assoc()){
			$result++;
		}

		return $result." Students";
	}

	function getGrades($uid){
		
    	$conn = mysqli_connect("localhost", "root", "", "cai_it4");

    	$sql = "SELECT * FROM grades WHERE stud_id='$uid' ";
    	$res = $conn->query($sql);

    	$result = "";

	    while($row = $res->fetch_assoc()){
        
        	$quizid = $row['quiz_id'];
        	$quizTitle = "";

        	$sql2 = "SELECT * FROM quiz WHERE quiz_id='$quizid' ";
        	$res2 = $conn->query($sql2);
        
        	while($row2 = $res2->fetch_assoc()){
    	        $quizTitle = $row2['quiz_title'];
   	    	}

        	$result .= '<div class="analysis-progrebar-content">
                    <p class="text-right"><i>'.$row['date_recorded'].'</i></p>
                    <h5>'.$quizTitle.'</h5>
                    <h2 class="storage-right"><span class="counter">'.floor($row['grade']).'</span>%</h2>
                    <div class="progress progress-mini ug-1">
                        <div style="width: '.$row['grade'].'%;" class="progress-bar"></div>
                    </div>
                    <div class="m-t-sm small">
                        <p>Scored '.$row['score'].' out of '.$row['total_items'].'</p>
                    </div>
                </div>';

    	}

    	return $result;

	}

	function loadUpdates($gkey, $type = "all", $uid = ""){

		$conn = mysqli_connect("localhost", "root", "", "cai_it4");

		if($type == "student" && $uid != ""){
			$sql = "SELECT * FROM updates WHERE friend ='$gkey' AND member_id='$uid' ORDER BY update_id DESC";
		}else{
			$sql = "SELECT * FROM updates WHERE friend ='$gkey' ORDER BY update_id DESC";
		}
		
		#$sql = "SELECT * FROM updates WHERE friend ='$gkey' ORDER BY update_id DESC";
		$res = $conn->query($sql);

		$hasupdates = false;

		while($row = $res->fetch_assoc()){

			$sql2 = "SELECT * FROM members WHERE member_id=".$row['member_id'];
			$res2 = $conn->query($sql2);

			$profileImg = "";
			$name = "";

			while($row2 = $res2->fetch_assoc()){
				$profileImg = $row2['image'];
				$name = $row2['firstname']." ".$row2['lastname'];
			}

			$datetime = explode(" ", $row['dt']);
			$temptime = explode(":", $datetime[4]);
			$time = $temptime[0].":".$temptime[1];

			$timeelapsed = "";

			if($datetime[1] === date("M") && $datetime[2] === date("d") && $datetime[3] === date("Y")){
				$timeelapsed = $time;
			}else{
				$timeelapsed = $row['dt'];
			}

			echo '<a href="students.php?view='.$row['member_id'].'"><div class="single-review-st-text">
      			<img src="'.$profileImg.'" alt="" style="border-radius:50%;">
      			<div class="review-ctn-hf">
        			<h3>'.$name.'</h3>
        			<p>'.ucfirst($row['status']).'</p>
      			</div>
      			<div class="review-item-rating">
       				<p>'.time_elapsed_string($row['dt']).'</p>
      			</div>
   			</div></a>';

   			$hasupdates = true;
		}

		if(!$hasupdates) echo "<p class='text-center'>No updates available</p>";

	}

	function Wizards(){

		$conn = mysqli_connect("localhost", "root", "", "cai_it4");
		
  		$sql = "SELECT * FROM grades WHERE grade = 100";
  		$res = $conn->query($sql);

  		$wizards = "";
  		$wizardquiz = "";
  		$wizardname = "";
  		$wimage = "";
  		$wtype = "";

  		while($row = $res->fetch_assoc()){

    		$userid = $row['stud_id'];
    		$sqlx = "SELECT * FROM members WHERE member_id='$userid'";
    		$resx = $conn->query($sqlx);
    		while($rowx = $resx->fetch_assoc()){ 
    			$wizardname = $rowx['firstname']." ".$rowx['lastname'];
    			$wimage=$rowx['image'];
    			$wtype = $rowx['type'];
    		}

    		$quizid = $row['quiz_id'];
    		$sqlx = "SELECT * FROM quiz WHERE quiz_id='$quizid'";
    		$resx = $conn->query($sqlx);
    		while($rowx = $resx->fetch_assoc()){ $wizardquiz = $rowx['quiz_title']; }
    
    		$stars = "";

    		for($i=0;$i<5;$i++){
      			$stars .= '<i class="educate-icon educate-star"></i>';
    		}

    		$wizards .= '
    			<div class="single-review-st-text">
      				<img src="'.$wimage.'" alt="">
      					<div class="review-ctn-hf">
        					<h3>'.$wizardname.'</h3>
        					<p>'.$wizardquiz.'</p>
      					</div>
      				<div class="review-item-rating">'.$stars.'</div>
    			</div>';
  		}
  		
  		if($wizards == "" && $wtype == "Student"){
  			return "<br>No one has scored 100% in their quiz yet. Be the first!<br><br>";
  		}else if($wizards == "" && $wtype == "Faculty"){
			return "<br>No student has scored 100% in their quizes so far.<br><br>";
  		}else{
  			return $wizards;
  		}

	}

	function UploadImage($image, $send, $id){

		$currentDir = getcwd();

		$errors = array();
		$result = array();

		$fileExtensions = array('jpeg','jpg','png');

		$filename = $image['name'];
		$filesize = $image['size'];
		$fileTmpName = $image['tmp_name'];
		$fileType = $image['type'];
		$temp = explode('.', $filename);
		$fileExtension = strtolower(end($temp));

		$uploadPath = $currentDir."/uploads/".basename($id.".".$fileExtension);

		if($send){

			if(!in_array($fileExtension, $fileExtensions)){
				$errors[] = "The image file extension is not allowed. Please upload a JPEG or PNG file";
			}

			if($filesize > 50000000){	//50mb
				$errors[] = "Thie image file is more than 2MB. Sorry it has to be less than or equal to 50MB";
			}

			if(empty($errors)){

				$didupload = move_uploaded_file($fileTmpName, $uploadPath);

				if($didupload){
					//echo "uploaded!";
					//return true;
					$result[] = $id.".".$fileExtension;
					$result[] = $uploadPath;
					return $result;

				}else{
					//echo "An error occured.";
					return false;
				}

			}else{

				$result[0] = false;

				foreach ($errors as $error) {
					$result[1][] = $error;
				}

				return $result;

			}
		}
	}

	function LoadTutorials(){

    	$conn = mysqli_connect("localhost", "root", "", "cai_it4");
      $sql = "SELECT * FROM tutorials";
      $res = $conn->query($sql);

      $div = "";
      while($row = $res->fetch_assoc()){
        //$div .= "<a href='tutorial-play2.php?source=".$row['_path']."'><div class='col-lg-3 thumbnail'>";
        //$div .= "<video src='admin/".$row['_path']."' width='120' height='150' ></video><br>";
        //$div .= "<label>".$row['title']."</label>";
        //$div .= "</div></a>";
        $div .= '<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 thumbnail">
        <a href="tutorial-play2.php?source='.$row['_path'].'">
        <div class="courses-inner res-mg-b-30">
          <div class="courses-title">
            <video src="admin/'.$row['_path'].'" width="120" height="150" ></video>
            <br><br>
            <h2>'.$row['title'].'</h2>
          </div>
          <div class="product-buttons">
            <button type="button" class="button-default cart-btn">Watch</button>
          </div>
        </div></a>
      </div>';
    }

      return $div;

    }

    function LoadLessons(){

		  $conn = mysqli_connect("localhost", "root", "", "cai_it4");
      $sql = "SELECT * FROM lessons";
      $res = $conn->query($sql);

      $div = "";
      while($row = $res->fetch_assoc()){
        //$div .= "<a href='admin/".$row['_path']."'><div class='col-lg-2x thumbnail2'>";
        //$div .= "<span><i class='fas fa-book-open fa-8x' style='color:lightblue;'></i></span><br>";
        //$div .= "<label>".$row['title']."</label>";
        //$div .= "</div></a>";
        $div .= '<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
        <a href="admin/'.$row['_path'].'">
        <div class="courses-inner res-mg-b-30">
          <div class="courses-title">
            <img src="images/lesson.png" alt="">
            <br><br>
            <h2>'.ucfirst(strtolower($row['title'])).'</h2>
          </div>
          <div class="product-buttons">
            <button type="button" class="button-default cart-btn">Read More</button>
          </div>
        </div></a>
      </div>';

      }

      return $div;

    }

?>


<?php

  date_default_timezone_set("Asia/Manila");
  
  $user = $_SESSION['log']['username'];
  $query = mysql_query("SELECT * FROM members WHERE username = '$user'") or die (mysql_error()); 
  $display = mysql_fetch_array($query);

  /////////////////////////////////////////////////////////////////////////FACULTY
  $notifCount = 0;
  $updateCount = 0;
  $notifier = "";
  $updater = "";

  //LOGS
  $sql = "SELECT * FROM logs WHERE gkey='$gkey' ORDER BY id DESC LIMIT 5";
  $res = $conn->query($sql);
  $logs = "";
  $updates = "";
  while($row = $res->fetch_assoc()){

  	$loggerid = $row['memberid'];

  	if($loggerid != $display['member_id']){

    	$sqlx = "SELECT * FROM members WHERE member_id='$loggerid' ";
    	$resx = $conn->query($sqlx);

    	$Lname = "";
    	$Limg = "";

    	while($rowx = $resx->fetch_assoc()){$Lname=$rowx['firstname']." ".$rowx['lastname']; $Limg=$rowx['image'];}

    	$time = explode(" ", $row['timein']);

      	$logs .= '<li>
                  <a href="#">
                    <div class="notification-icon">
                      <img style="border-radius:50%;" src="'.$Limg.'">
                    </div>
                    <div class="notification-content">
                      <span class="notification-date">'.$row['datein'].'</span>
                      <h2>'.$Lname.'</h2>
                      <p>Has logged in to the system. <span style="color:white;">.....</span>
                      <i>'.time_elapsed_string($time[0]).'</i>
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    </div>
                  </a>
               </li>';
    	$notifCount++;

    }
  }

    	$sql3 = "SELECT * FROM updates WHERE friend='$gkey' ORDER BY update_id DESC";
    	$res3 = $conn->query($sql3);

    	while($row2 = $res3->fetch_assoc()){
    		
    		$sqlx2 = "SELECT * FROM members WHERE member_id=".$row2['member_id'];
    		$resx2 = $conn->query($sqlx2);

    		while($rowx2 = $resx2->fetch_assoc()){$Lname2=$rowx2['firstname']." ".$rowx2['lastname']; $Limg2=$rowx2['image'];}

    			$datetime = explode(" ", $row2['dt']);
    			$d = $datetime[1];
    			$D = $datetime[2];

    		$time = $datetime[4];

    		$timeelapsed = "";

    		if($d === date("M") && $D === date("d") && $datetime[3] === date("Y")){
				$timeelapsed = $time;
			}else{
				$timeelapsed = $row2['dt'];
			}

    		$spacer = "....................";
			if($row2['status'] == "Has taken a quiz" || $row2['status'] == "Added a new quiz") $spacer = "_________......";

			$link = "#";

			if($row2['status'] == "Added a new lesson") $link = "lessons.php?pos=".$row2['image'];
    		
    		$updates .= '<li>
                  <a href="'.$link.'">
                    <div class="notification-icon">
                      <img style="border-radius:50%;" src="'.$Limg2.'">
                    </div>
                    <div class="notification-content">
                      <span class="notification-date">'.$d." ".$D.'</span>
                      <h2>'.$Lname2.'</h2>
                      <p>'.$row2['status'].' <span style="color:white;">'.$spacer.'</span>
                      <i>'.time_elapsed_string($timeelapsed).'</i>
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                    </div>
                  </a>
               </li>';

    		$updateCount++;

    	}


  $notifier = '<span class="indicator-ms"><span class="badge">'.$notifCount.'</span></span>';
  $updater = '<span class="indicator-ms"><span class="badge">'.$updateCount.'</span></span>';

  if($notifCount == 0) $logs = "<p class='text-center'>No new notifications</p>";
  if($updateCount == 0) $updates = "<p class='text-center'>No new notifications</p>";

  /////////////////////////////////////////////////////////////////////////MESSAGES

  	function GetMessages($email, $type, $limit, $dateSpicifier){
  		
  		$conn = mysqli_connect("localhost", "root", "", "cai_it4");

if($type == "all"){
  		
$sql = "SELECT * FROM messages WHERE recipient='$email' AND status != 'deleted' ORDER BY message_id DESC LIMIT $limit ";
  		
}else if($type == "sent"){
  		
$sql = "SELECT * FROM messages WHERE sender='$email' AND status != 'deleted' ORDER BY message_id DESC LIMIT $limit ";
  		
}else if($type == "trash"){
  		
$sql = "SELECT * FROM messages WHERE sender='$email' AND status='deleted' ORDER BY message_id DESC LIMIT $limit ";
  		
}else{
  	$sql = "SELECT * FROM messages WHERE recipient='$email' AND status='$type' LIMIT $limit ";
}
  		
  		$res = $conn->query($sql);

  		$messages = Array();

  		while($row = $res->fetch_assoc()){
  			
  			$list = Array();
  			$list[] = $row["message_id"];
  			$list[] = $row["sender"];
  			$list[] = $row["recipient"];
  			$list[] = $row["content"];

  			if($dateSpicifier == "d"){
  				$dt = explode(" ", $row["date_sent"]);
  				$list[] = $dt[0];
  			}else if($dateSpicifier == "m"){
  				$dt = explode(" ", $row["date_sent"]);
  				$list[] = $dt[1];
  			}else if($dateSpicifier == "y"){
  				$dt = explode(" ", $row["date_sent"]);
  				$list[] = $dt[2];
  			}else if($dateSpicifier == "time"){
  				$dt = explode(" ", $row["date_sent"]);
  				$list[] = $dt[3];
  			}else{
  				$list[] = $row['date_sent'];
  			}

  			$list[] = $row["status"];

  			$messages[] = $list;
  			
  		}

  		return $messages;

  	}

  	function GetMemberImageByName($name){

  		//echo $name;

  		$conn = mysqli_connect("localhost", "root", "", "cai_it4");
  		$namex = explode(" ", $name);
  		$firstname = $namex[0];
  		$lastname = $namex[1];
  		$sql = "SELECT * FROM members WHERE firstname='$firstname' AND lastname='$lastname' ";
  		$res = $conn->query($sql);

  		$image = "";

  		while($row = $res->fetch_assoc()){
  			$image = $row["image"];
  		}

  		return $image;
  	}

    function GetMemberEmailByName($name){

      //echo $name;

      $conn = mysqli_connect("localhost", "root", "", "cai_it4");
      $namex = explode(" ", $name);
      $firstname = $namex[0];
      $lastname = $namex[1];
      $sql = "SELECT * FROM members WHERE firstname='$firstname' AND lastname='$lastname' ";
      $res = $conn->query($sql);

      $image = "";

      while($row = $res->fetch_assoc()){
        $image = $row["email"];
      }

      return $image;
    }

  	function time_elapsed_string($datetime, $full = false) {

    	$now = new DateTime;
    	$ago = new DateTime($datetime);
    	$diff = $now->diff($ago);

    	$diff->w = floor($diff->d / 7);
    	$diff->d -= $diff->w * 7;

    	$string = array(
        	'y' => 'year',
        	'm' => 'month',
        	'w' => 'week',
        	'd' => 'day',
        	'h' => 'hour',
        	'i' => 'minute',
        	's' => 'second',
    	);
    	foreach ($string as $k => &$v) {
        	if ($diff->$k) {
            	$v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        	} else {
            	unset($string[$k]);
        	}
    	}

    	if (!$full) $string = array_slice($string, 0, 1);
    	return $string ? implode(', ', $string) . ' ago' : 'just now';
	}

	function Security($task, $session){

		$conn = mysqli_connect("localhost", "root", "", "cai_it4");

		if($task == "set"){
		
			if($session == "quiz"){
				$sql = "UPDATE session SET quiz = 'active' WHERE id='1'";
			}else if($session == "lesson"){
				$sql = "UPDATE session SET lesson='active' WHERE id='1'";
			}else if($session == "tutorial"){
				$sql = "UPDATE session SET tutorial='active' WHERE id='1'";
			}

			$res = $conn->query($sql);
		
		}else if($task == "unset"){

			if($session == "quiz"){
				$sql = "UPDATE session SET quiz = 'inactive' WHERE id='1'";
			}else if($session == "lesson"){
				$sql = "UPDATE session SET lesson='inactive' WHERE id='1'";
			}else if($session == "tutorial"){
				$sql = "UPDATE session SET tutorial='inactive' WHERE id='1'";
			}

			$res = $conn->query($sql);
		
		}else if($task == "get"){
			$sql = "SELECT * FROM session";
			$res = $conn->query($sql);
			while($row = $res->fetch_assoc()){
				if($row[$session] == "active"){
					return true;
				}else{
					return false;
				}
			}
		}


	}
  
?>