<?php

// Database Constants
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "cai_it4");

date_default_timezone_set("Asia/Manila");

?>
