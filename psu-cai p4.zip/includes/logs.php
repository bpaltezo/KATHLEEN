<?php 

	$conn = mysqli_connect("localhost", "root", "", "cai_it4");

	$id = "";
	$limit = 5;

	if(isset($_POST["id"])){
		$id = $_POST["id"];
	}else{
		$id = $display["member_id"];
	}

	if(isset($_POST["limit"])){
		$limit = $_POST["limit"];
	}

	$sql = "SELECT * FROM logs WHERE memberid != '$id' AND timein != '' ORDER BY id DESC LIMIT ".$limit;
	$res = $conn->query($sql);

	$result = "";

	while($row = $res->fetch_assoc()){

		$sqlx = "SELECT * FROM members WHERE member_Id=".$row['memberid'];
		$resx = $conn->query($sqlx);

		$name = "";
		$memberid = $row["memberid"];
		$datein = $row["datein"];

		while($row2 = $resx->fetch_assoc()){
			$name = $row2["firstname"]." ".$row2["lastname"];
		}

		$result .= "<tr>";
		$result .= "<td></td>";
		$result .= "<td>".$name."</td>";
		$result .= "<td>".$datein."</td>";
		$result .= "<td>".$row["timein"]."</td>";

		$sqlx2 = "SELECT * FROM logs WHERE memberid='$memberid' AND dateout='$datein'";
		$resx2 = $conn->query($sqlx2);
		$logout = "";
		while($row3 = $resx2->fetch_assoc()){
			$logout = $row3["logout"];
		}
		$result .= "<td>".$logout."</td>";
		$result .= "</tr>";

	}	

	echo $result;

?>